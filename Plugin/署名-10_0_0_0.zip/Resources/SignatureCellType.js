var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Forguncy;
(function (Forguncy) {
    var SignatureCellType;
    (function (SignatureCellType_1) {
        var SignatureCellType = /** @class */ (function (_super) {
            __extends(SignatureCellType, _super);
            function SignatureCellType() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            SignatureCellType.prototype.createContent = function () {
                var self = this;
                var element = this.CellElement;
                var cellTypeMetaData = element.CellType;
                var container = $("<div id='" + this.ID + "'></div>");
                this.clearButtonHeight = this.measureButtonHeight(cellTypeMetaData.ClearButtonText);
                var canvasDiv = $("<div></div>");
                canvasDiv.css("position", "absolute");
                canvasDiv.css("left", "0px");
                canvasDiv.css("top", "0px");
                canvasDiv.css("right", "0px");
                canvasDiv.css("bottom", this.clearButtonHeight + "px");
                canvasDiv.css("border", "1px solid #D4D4D4");
                canvasDiv.css("user-select", "none");
                canvasDiv.css("overflow", "hidden");
                var canvas = $("<canvas style='touch-action: none;'></canvas>");
                canvas[0].width = element.Width;
                canvas[0].height = element.Height - this.clearButtonHeight;
                canvasDiv.append(canvas);
                this.signaturePad = new SignaturePad(canvas[0]);
                var options = this.getOptions(cellTypeMetaData, element.StyleInfo);
                this.signaturePad.dotSize = options.dotSize;
                this.signaturePad.minWidth = options.minWidth;
                this.signaturePad.maxWidth = options.maxWidth;
                this.signaturePad.penColor = options.penColor;
                this.signaturePad.onBegin = function () {
                    var _a;
                    //在手机里，点击签名其他input不会失焦点，因此，主动调一下blur方法
                    var targetTagNames = ['INPUT', 'TEXTAREA', 'SELECT'];
                    if (targetTagNames.indexOf((_a = document.activeElement) === null || _a === void 0 ? void 0 : _a.tagName) >= 0) {
                        $(document.activeElement).blur();
                    }
                };
                var footerDiv = $("<div></div>");
                footerDiv.css("overflow", "hidden");
                footerDiv.css("position", "absolute");
                footerDiv.css("left", "0px");
                footerDiv.css("right", "0px");
                footerDiv.css("bottom", "0px");
                footerDiv.css("max-height", this.clearButtonHeight + "px");
                footerDiv.css("height", "100%");
                footerDiv.css("background", "white");
                this.clearButton = this.getClearButton(cellTypeMetaData.ClearButtonText);
                this.clearButton.on("click", function () {
                    self.signaturePad.clear();
                    self.commitValue();
                });
                footerDiv.append(this.clearButton);
                container.append(canvasDiv);
                container.append(footerDiv);
                this.onDocumentClick = function (e) {
                    if (self.isDisabled() || self.isReadOnly()) {
                        self.isClicked = false;
                        return;
                    }
                    var mousePoint = self.getMousePosition((e || window.event));
                    var offset = canvas.offset();
                    var w = canvas.width();
                    var h = canvas.height();
                    if (mousePoint.y < offset.top || mousePoint.y > offset.top + h ||
                        mousePoint.x < offset.left || mousePoint.x > offset.left + w) {
                        /* fix FORGUNCY-16205 Should not show error message when leave page if have signature
                         * 修复之前，签名在点击页面时提交数据。但是这个demo里签名已有的一个数据可能是老版本存的，再次提交时，会生成不同的数据
                         * 因此，在点击cancel按钮时，看起来没有操作签名，但是数据变了
                         * 现在改成至少点击过签名插件，才会提交数据
                         */
                        if (self.isClicked) {
                            self.isClicked = false;
                            self.commitValue();
                        }
                    }
                    else {
                        self.isClicked = true;
                    }
                };
                $(document).on("mousedown touchstart", this.onDocumentClick);
                return container;
            };
            SignatureCellType.prototype.onWindowResized = function () {
                //Fix bug FORGUNCY-1638:[Signature]Signature image can not show in repeater
                //It will trigger window resize event on onload, so here remove commitValue method.
                //commit first
                //this.commitValue();
                var oldValue = this.getValueFromElement();
                //find parent div
                var parentDiv = this.getContainer();
                //find canvas
                var canvas = $(parentDiv.find("canvas")[0]);
                //resize
                var newWidth = parentDiv.width();
                //Fix bug FORGUNCY-1634: [Signature]Display of signature value is not good after changed page stretch.
                var newHeight = parentDiv.height() - this.clearButtonHeight;
                canvas.attr("width", newWidth);
                canvas.attr("height", newHeight);
                //Fix bug FORGUNCY-2216: [Signature]Failed to preview signature value after maximize or minimize browser window.
                //reset value
                this.setValueToElement(undefined, oldValue);
            };
            SignatureCellType.prototype.getMousePosition = function (ev) {
                if (ev.pageX || ev.pageY) {
                    return { x: ev.pageX, y: ev.pageY };
                }
                return {
                    x: ev.clientX + document.body.scrollLeft - document.body.clientLeft,
                    y: ev.clientY + document.body.scrollTop - document.body.clientTop
                };
            };
            SignatureCellType.prototype.getClearButton = function (clearButtonText) {
                var clearButton = $("<button type='button' class='button clear' data-action='clear'>" + clearButtonText + "</button>");
                clearButton.css("margin-top", "5px");
                var fontFamily = "";
                if (this.CellElement.StyleInfo && this.CellElement.StyleInfo.FontFamily) {
                    fontFamily = this.CellElement.StyleInfo.FontFamily;
                }
                clearButton.css("font-family", fontFamily);
                clearButton.css("font-size", "14px");
                return clearButton;
            };
            SignatureCellType.prototype.measureButtonHeight = function (clearButtonText) {
                var clearButton = this.getClearButton(clearButtonText);
                clearButton.css("opacity", 0);
                $(window.document.body).append(clearButton);
                var height = clearButton.outerHeight(true);
                clearButton.remove();
                return height;
            };
            SignatureCellType.prototype.destroy = function () {
                $(document).off("mousedown touchstart", this.onDocumentClick);
                this.signaturePad = null;
                this.clearButton = null;
                this.onDocumentClick = null;
            };
            SignatureCellType.prototype.getOptions = function (cellTypeMetaData, styleInfo) {
                var dotSize = 1;
                if (cellTypeMetaData.DotSize > 0) {
                    dotSize = cellTypeMetaData.DotSize;
                }
                var minWidth = 0.5;
                if (cellTypeMetaData.LineMinWidth > 0) {
                    minWidth = cellTypeMetaData.LineMinWidth;
                }
                var maxWidth = 1.5;
                if (cellTypeMetaData.LineMaxWidth > 0) {
                    maxWidth = cellTypeMetaData.LineMaxWidth;
                }
                var penColor = "black";
                if (styleInfo && styleInfo.Foreground && styleInfo.Foreground !== "") {
                    penColor = Forguncy.ConvertToCssColor(styleInfo.Foreground);
                }
                return {
                    dotSize: dotSize,
                    minWidth: minWidth,
                    maxWidth: maxWidth,
                    penColor: penColor
                };
            };
            SignatureCellType.prototype.getValueFromElement = function () {
                if (this.signaturePad.isEmpty()) {
                    return null;
                }
                return this.signaturePad.toDataURL();
            };
            SignatureCellType.prototype.setValueToElement = function (jelement, value) {
                this.signaturePad.clear();
                if (value) {
                    this.signaturePad.fromDataURL(value);
                }
                this.signaturePad._isEmpty = value === null ? true : false;
            };
            SignatureCellType.prototype.disable = function () {
                _super.prototype.disable.call(this);
                this.onIsDisabeldChanged();
            };
            SignatureCellType.prototype.enable = function () {
                _super.prototype.enable.call(this);
                this.onIsDisabeldChanged();
            };
            SignatureCellType.prototype.onIsDisabeldChanged = function () {
                if (this.isDisabled()) {
                    this.signaturePad.off();
                    this.clearButton.css("display", "none");
                }
                else {
                    this.signaturePad.on();
                    this.clearButton.css("display", "");
                }
            };
            return SignatureCellType;
        }(Forguncy.Plugin.CellTypeBase));
        SignatureCellType_1.SignatureCellType = SignatureCellType;
    })(SignatureCellType = Forguncy.SignatureCellType || (Forguncy.SignatureCellType = {}));
})(Forguncy || (Forguncy = {}));
// Key format is "Namespace.ClassName, AssemblyName"
Forguncy.Plugin.CellTypeHelper.registerCellType("SignatureCellType.SignatureCellType, SignatureCellType", Forguncy.SignatureCellType.SignatureCellType);
