var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var ImageEditor;
(function (ImageEditor) {
    var ImageEditorCellType = /** @class */ (function (_super) {
        __extends(ImageEditorCellType, _super);
        function ImageEditorCellType() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this._menu = [];
            _this._uid = ImageEditor.BaseHelper.generateID();
            _this._languageResource = window.ImageEditorResource.Language[Forguncy.RS.Culture];
            _this._fileCacheMap = new Map();
            _this._listeners = {
                mousedown: [],
                touchstart: []
            };
            _this._isEmpty = true;
            return _this;
        }
        ImageEditorCellType.prototype.createContent = function () {
            return $("<div id=\"".concat(this._uid, "\" class=\"fgc-image-editor\" ><input type=\"file\" class=\"fgc-image-editor-input\" accept=\"image/*,.jpeg\"><div id=\"").concat(this._uid, "_tui-container\" /></div>"));
        };
        ImageEditorCellType.prototype.onPageLoaded = function () {
            var _this = this;
            this.initCellTypeParam();
            return new Promise(function (resolve) { return __awaiter(_this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.loadTheme()];
                        case 1:
                            _a.sent();
                            return [4 /*yield*/, this.internalOnPageLoaded()];
                        case 2:
                            _a.sent();
                            resolve(null);
                            return [2 /*return*/];
                    }
                });
            }); });
        };
        ImageEditorCellType.prototype.initCellTypeParam = function () {
            if (!window.ImageEditorResource.Theme) {
                window.ImageEditorResource.Theme = {};
            }
            this._cellTypeParam = this.CellElement.CellType;
            var _a = this._cellTypeParam, InitMenu = _a.InitMenu, Menu = _a.Menu, DefaultImageValue = _a.DefaultImageValue;
            this._initMenu = ImageEditor.ImageEditorExtension.getMenuNameByEnum(InitMenu);
            var menu = Menu.map(function (item) { return ImageEditor.ImageEditorExtension.getMenuNameByEnum(item.Name); });
            if (this._initMenu && !menu.includes(this._initMenu)) {
                menu.push(this._initMenu);
            }
            this._menu = menu;
            if (DefaultImageValue === null || DefaultImageValue === void 0 ? void 0 : DefaultImageValue.Name) {
                this._imageName = DefaultImageValue.Name;
                this._imagePath = Forguncy.Helper.SpecialPath.getImageEditorUploadImageFolderPath() + DefaultImageValue.Name;
            }
        };
        ImageEditorCellType.prototype.internalOnPageLoaded = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            if (this.menuBarPositionIsLeftOrRight()) {
                                $("#".concat(this._uid)).addClass("tui-image-editor-menu-is-up-or-down");
                            }
                            return [4 /*yield*/, this.createImageEditorInstance(true)];
                        case 1:
                            _a.sent();
                            return [2 /*return*/];
                    }
                });
            });
        };
        ImageEditorCellType.prototype.menuBarPositionIsLeftOrRight = function () {
            return this._cellTypeParam.MenuBarPosition === ImageEditor.MenuBarPositionEnum.left ||
                this._cellTypeParam.MenuBarPosition === ImageEditor.MenuBarPositionEnum.right;
        };
        ImageEditorCellType.prototype.setValueToElement = function (jElement, value) {
            this.evaluateFormulaImagePath(value);
            if (this._cellValue === value) {
                return;
            }
            this._cellValue = value;
            this.createImageEditorInstance(true);
        };
        ImageEditorCellType.prototype.evaluateFormulaImagePath = function (imagPath) {
            var fileInfo = ImageEditor.BaseHelper.getFileInfo(imagPath);
            this._imagePath = fileInfo === null || fileInfo === void 0 ? void 0 : fileInfo.url;
            this._imageName = (fileInfo === null || fileInfo === void 0 ? void 0 : fileInfo.name) || "image";
        };
        ImageEditorCellType.prototype.loadTheme = function () {
            var _this = this;
            return new Promise(function (resolve) { return __awaiter(_this, void 0, void 0, function () {
                var themeName;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            themeName = ImageEditor.ThemeEnum[this._cellTypeParam.Theme];
                            if (!!window.ImageEditorResource.Theme[themeName]) return [3 /*break*/, 2];
                            return [4 /*yield*/, ImageEditor.BaseHelper.loadScript("scripts/themes/".concat(themeName, ".js"))];
                        case 1:
                            _a.sent();
                            _a.label = 2;
                        case 2:
                            this._themeResource = window.ImageEditorResource.Theme[themeName];
                            if (this._cellTypeParam.Theme === ImageEditor.ThemeEnum.light) {
                                this.getContainer().addClass("fgc-tui-image-editor-light");
                            }
                            resolve(null);
                            return [2 /*return*/];
                    }
                });
            }); });
        };
        ImageEditorCellType.prototype.getJqueryElement = function (selector) {
            return $(selector, "#".concat(this._uid));
        };
        ImageEditorCellType.prototype.resizeCanvasDimension = function () {
            this._imageEditor.resizeCanvasDimension(this.getMaxWidthAndMaxHeight());
        };
        ImageEditorCellType.prototype.waitDomDisplay = function (imagePath) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            if (!!$("#".concat(this._uid)).is(":visible")) return [3 /*break*/, 2];
                            return [4 /*yield*/, ImageEditor.BaseHelper.sleep(50)];
                        case 1:
                            _a.sent();
                            return [3 /*break*/, 0];
                        case 2: return [2 /*return*/, this._imagePath === imagePath];
                    }
                });
            });
        };
        ImageEditorCellType.prototype.createImageEditorInstance = function (updateCellValueBase64Str) {
            return __awaiter(this, void 0, void 0, function () {
                var _this = this;
                return __generator(this, function (_a) {
                    return [2 /*return*/, new Promise(function (resolve) { return __awaiter(_this, void 0, void 0, function () {
                            var MenuBarPosition, _a, maxWidth, maxHeight, imagePath, res, e_1, option, _b;
                            var _this = this;
                            var _c;
                            return __generator(this, function (_d) {
                                switch (_d.label) {
                                    case 0:
                                        // 重新创建实例时，如果直接把旧实例销毁，图片又是异步加载上来的，页面会闪框，体验不太好，
                                        // 在这里，只把旧的图片销毁。这样切换效果比较好
                                        (_c = this._imageEditor) === null || _c === void 0 ? void 0 : _c.ui._actions.main.load(new File([], 'empty'));
                                        if (!(this._imagePath != undefined)) return [3 /*break*/, 2];
                                        return [4 /*yield*/, this.waitDomDisplay(this._imagePath)];
                                    case 1:
                                        if (!(_d.sent())) {
                                            return [2 /*return*/, resolve(null)];
                                        }
                                        _d.label = 2;
                                    case 2:
                                        MenuBarPosition = this._cellTypeParam.MenuBarPosition;
                                        _a = this.getMaxWidthAndMaxHeight(), maxWidth = _a.maxWidth, maxHeight = _a.maxHeight;
                                        this._isEmpty = true;
                                        imagePath = this._imagePath;
                                        if (!(typeof imagePath === 'string' && !(imagePath === null || imagePath === void 0 ? void 0 : imagePath.startsWith('data:image/')))) return [3 /*break*/, 6];
                                        _d.label = 3;
                                    case 3:
                                        _d.trys.push([3, 5, , 6]);
                                        return [4 /*yield*/, $.ajax({
                                                url: this._imagePath,
                                                cache: false,
                                            })];
                                    case 4:
                                        res = _d.sent();
                                        if (res.status && res.status !== 200) {
                                            imagePath = null;
                                        }
                                        return [3 /*break*/, 6];
                                    case 5:
                                        e_1 = _d.sent();
                                        imagePath = null;
                                        return [3 /*break*/, 6];
                                    case 6:
                                        option = {
                                            includeUI: {
                                                menu: ImageEditor.BaseHelper.uniq(this._menu),
                                                menuBarPosition: ImageEditor.MenuBarPositionEnum[MenuBarPosition],
                                                locale: this._languageResource,
                                                theme: this._themeResource,
                                                loadImage: {
                                                    path: imagePath,
                                                    name: this._imageName,
                                                },
                                            },
                                            cssMaxWidth: maxWidth,
                                            cssMaxHeight: maxHeight,
                                            usageStatistics: false,
                                            selectionStyle: {
                                                cornerStyle: 'circle',
                                                cornerSize: 16,
                                                cornerColor: '#fff',
                                                cornerStrokeColor: 'black',
                                                transparentCorners: false,
                                                lineWidth: 2,
                                                borderColor: 'black',
                                            },
                                        };
                                        this._imageEditor = new window.tui.ImageEditor("#".concat(this._uid, "_tui-container"), option);
                                        this._imageEditorExtension = new ImageEditor.ImageEditorExtension(this._imageEditor);
                                        this.createControlButtons();
                                        this.addDragAndDropUpload();
                                        _b = !imagePath;
                                        if (_b) return [3 /*break*/, 8];
                                        return [4 /*yield*/, this.getLoadResultsAsync(this._imagePath)];
                                    case 7:
                                        _b = !(_d.sent());
                                        _d.label = 8;
                                    case 8:
                                        if (_b) {
                                            if (updateCellValueBase64Str) {
                                                this._cellValueBase64Str = null;
                                            }
                                            return [2 /*return*/, resolve(null)];
                                        }
                                        this._isEmpty = false;
                                        this.enhancedHelpMenu();
                                        this.enhancedMenu();
                                        this.updateAllDefaultValue();
                                        if (ImageEditor.BaseHelper.isMobile()) {
                                            this.updatePointerStyle();
                                        }
                                        this._enhancedFinish = true;
                                        /**
                                         * 主要解决 调用 this.getImageBase64Str() 时，会导致图片加载不出来的问题（白屏）
                                         * 所以，这里使用 setTimeout可以解决一定程度的问题，但是仍然还有几率白屏
                                         * 如果还是出现了白屏，经过测试，任意点击一下，就可以解决了
                                         * 所以这里连续点击两次当前初始化的按钮，就可以解决白屏问题 并且用户感知不到。UI也不会有变化，或者闪烁等情况。
                                         *
                                         * 后期修复其它问题的时候，需要改动源码时，
                                         * 可以考虑增加一个事件，在图片加载完成后，触发一个事件， 然后在这个事件的回调中，调用 this.getImageBase64Str() 来获取图片的base64
                                         */
                                        if (updateCellValueBase64Str) {
                                            setTimeout(function () {
                                                _this._cellValueBase64Str = _this.getImageBase64Str();
                                                var el = $('.tui-image-editor-item.normal.active');
                                                el.click().click();
                                                resolve(null);
                                            });
                                        }
                                        else {
                                            resolve(null);
                                        }
                                        return [2 /*return*/];
                                }
                            });
                        }); })];
                });
            });
        };
        ImageEditorCellType.prototype.getMaxWidthAndMaxHeight = function () {
            var menuWidth = 64;
            var headerMenuWidth = 40;
            var menuDrawWidth = 248;
            var menuDrawHeight = 150;
            var root = $("#".concat(this._uid));
            var maxWidth = root.width();
            var maxHeight = root.height();
            /**
             * 90和20px 是因为中间的画布是定位上去的，有一些位置上的偏移，该值是经过试验，觉得比较好的一个位置
             * 10px 是增加边距，以免出现滚动条
             */
            if (this.menuBarPositionIsLeftOrRight()) {
                maxWidth -= (menuWidth + headerMenuWidth + menuDrawWidth + 90);
                maxHeight -= 10;
            }
            else {
                maxHeight -= (menuWidth + headerMenuWidth + +menuDrawHeight + 20);
                maxWidth -= 10;
                if (this._cellTypeParam.MenuBarPosition === ImageEditor.MenuBarPositionEnum.top) {
                    this.getJqueryElement("canvas,.tui-image-editor-grid-visual").css("top", "-30px");
                }
            }
            return { maxWidth: maxWidth, maxHeight: maxHeight };
        };
        ImageEditorCellType.prototype.showMask = function () {
            Forguncy.PageBuilder.showPageLoadingCover("rgba(0,0,0,0.4)");
        };
        ImageEditorCellType.prototype.hideMask = function () {
            Forguncy.PageBuilder.hidePageLoadingCover();
        };
        ImageEditorCellType.prototype.cancelActiveMenuItem = function () {
            this.getJqueryElement(".tui-image-editor-item.active").click();
        };
        ImageEditorCellType.prototype.helpMenuHasClass = function (target, className) {
            var targetJelement = $(target);
            return targetJelement.hasClass(className) ||
                targetJelement.parent("li").hasClass(className);
        };
        ImageEditorCellType.prototype.enhancedHelpMenu = function () {
            var _this = this;
            var menuElem = this.getJqueryElement(".tui-image-editor-help-menu");
            var closeActiveHelpMenuItem = function () {
                $('.on', menuElem).click();
                $('.opened', menuElem).click();
            };
            var isHistoryPanel = function (target) {
                var jqel = $(target);
                return jqel.hasClass("tie-panel-history") || jqel.parents(".tie-panel-history").length;
            };
            menuElem.children().click(function (e) {
                var hasClass = _this.helpMenuHasClass.bind(_this, e.target);
                if (hasClass("on") || hasClass("opened")) {
                    return;
                }
                if (isHistoryPanel(e.target)) {
                    return;
                }
                closeActiveHelpMenuItem();
            });
            var listener = function (e) {
                var isHistoryButton = _this.helpMenuHasClass(e.target, "tie-btn-history");
                var historyOpened = $(".tie-btn-history.opened").length;
                if (isHistoryPanel(e.target)) {
                    return;
                }
                if (isHistoryButton) {
                    $(".on").click();
                    return;
                }
                if (historyOpened) {
                    closeActiveHelpMenuItem();
                }
            };
            this._listeners.mousedown.push(listener);
            this._listeners.touchstart.push(listener);
            document.addEventListener("touchstart", listener);
            document.addEventListener("mousedown", listener);
        };
        ImageEditorCellType.prototype.enhancedMenu = function () {
            $(".tui-image-editor-menu-draw .tui-image-editor-newline.tui-image-editor-range-wrap label")
                .text(this._languageResource.Draw_Range);
            $(".tui-image-editor-menu-rotate .tui-image-editor-newline.tui-image-editor-range-wrap label")
                .text(this._languageResource.Rotate_Range);
        };
        ImageEditorCellType.prototype.uploadFile = function (base64String) {
            var _this = this;
            return new Promise(function (resolve, reject) { return __awaiter(_this, void 0, void 0, function () {
                var root, uploadPath, blob, formData;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            root = Forguncy.Helper.SpecialPath.getBaseUrl();
                            uploadPath = root + "FileDownloadUpload/Upload";
                            return [4 /*yield*/, ImageEditor.BaseHelper.convertBase64ToBlob(base64String, this._cellTypeParam.AutoCompress, this._cellTypeParam.Clarity)];
                        case 1:
                            blob = _a.sent();
                            formData = new FormData();
                            formData.append("file", blob, ImageEditor.BaseHelper.getFileFullName(this._imageName));
                            formData.append("uploadLimitId", this.CellElement.ServerPropertiesId.UploadLimit);
                            $.ajax({
                                url: uploadPath,
                                type: 'POST',
                                data: formData,
                                cache: false,
                                contentType: false,
                                processData: false,
                                success: resolve,
                                error: reject,
                                headers: {
                                    "Accept": "application/json"
                                }
                            });
                            return [2 /*return*/];
                    }
                });
            }); });
        };
        ImageEditorCellType.prototype.getDownloadElement = function () {
            var _a;
            return (_a = this.getJqueryElement(".tui-image-editor-download-btn")) === null || _a === void 0 ? void 0 : _a.first();
        };
        ImageEditorCellType.prototype.getSaveElement = function () {
            return this.getJqueryElement(".fgc-image-editor-input");
        };
        ImageEditorCellType.prototype.internalSave = function () {
            return __awaiter(this, void 0, void 0, function () {
                var startTime, base64String, hasCache, data, _a, endTime, e_2;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            _b.trys.push([0, 5, 6, 7]);
                            if (this._saving) {
                                return [2 /*return*/];
                            }
                            if (!this._imagePath) {
                                return [2 /*return*/];
                            }
                            this._saving = true;
                            this.hideValidateTooltip();
                            this.cancelActiveMenuItem();
                            this.showMask();
                            startTime = new Date().getTime();
                            base64String = this._imageEditor.toDataURL();
                            /**
                             *  Fix Bug
                             *  FORGUNCY-8603 In ipad and mobile, If the image comes from the camera or select a file,it will display error after clicking save
                             *  部分IOS手机下,快速点击保存, 某些情况下 toDataURL() 的结果为空串
                             */
                            if (!base64String) {
                                return [2 /*return*/];
                            }
                            hasCache = this._fileCacheMap.has(base64String);
                            if (!hasCache) return [3 /*break*/, 1];
                            _a = this._fileCacheMap.get(base64String);
                            return [3 /*break*/, 3];
                        case 1: return [4 /*yield*/, this.uploadFile(base64String)];
                        case 2:
                            _a = _b.sent();
                            _b.label = 3;
                        case 3:
                            data = _a;
                            if (!hasCache) {
                                this._fileCacheMap.set(base64String, data);
                            }
                            this._cellValue = data;
                            this._cellValueBase64Str = base64String;
                            this._isEmpty = false;
                            this.commitValue();
                            this.executeCustomCommandObject(this._cellTypeParam.SaveCommand, null, "AfterSave");
                            endTime = new Date().getTime();
                            return [4 /*yield*/, ImageEditor.BaseHelper.sleep(1000 - (endTime - startTime))];
                        case 4:
                            _b.sent();
                            return [3 /*break*/, 7];
                        case 5:
                            e_2 = _b.sent();
                            alert(e_2);
                            return [3 /*break*/, 7];
                        case 6:
                            this.hideMask();
                            this._saving = false;
                            return [7 /*endfinally*/];
                        case 7: return [2 /*return*/];
                    }
                });
            });
        };
        ImageEditorCellType.prototype.internalDownload = function () {
            return __awaiter(this, void 0, void 0, function () {
                var base64String, blob;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            this.cancelActiveMenuItem();
                            base64String = this._imageEditor.toDataURL();
                            return [4 /*yield*/, ImageEditor.BaseHelper.convertBase64ToBlob(base64String, this._cellTypeParam.AutoCompress, this._cellTypeParam.Clarity)];
                        case 1:
                            blob = _a.sent();
                            ImageEditor.BaseHelper.downloadFile(blob, this._imageName);
                            return [2 /*return*/];
                    }
                });
            });
        };
        ImageEditorCellType.prototype.internalUpload = function () {
            var _a;
            (_a = this.getSaveElement()) === null || _a === void 0 ? void 0 : _a.click();
        };
        ImageEditorCellType.prototype.createControlButtons = function () {
            var _this = this;
            var saveElement = this.getSaveElement();
            saveElement.on("change", function (e) {
                var files = e.target.files;
                if (!files.length) {
                    return;
                }
                var file = files[0];
                if (!file.type.startsWith("image/")) {
                    alert(ImageEditor.StringHelper.format(_this._languageResource.Error_IncorrectFileType, file.name));
                    return;
                }
                _this.loadImageFromFile(file);
                saveElement.val("");
            });
            var menu = this.getJqueryElement('.tui-image-editor-menu');
            var menus = menu.children("li");
            if (this._cellTypeParam.ControlButtons.length) {
                menu.append(this.getJqueryElement(".tui-image-editor-icpartition").first().parent().clone());
            }
            var createMenuItem = function (svgString, toolTioContent, onClick) {
                var newMenuItem = menus.last().clone();
                newMenuItem.addClass("fgc-image-editor-menu-item");
                newMenuItem.html(svgString);
                newMenuItem.attr('tooltip-content', toolTioContent);
                newMenuItem.click(onClick);
                menu.append(newMenuItem);
            };
            var createdSet = new Set();
            this._cellTypeParam.ControlButtons.forEach(function (_a) {
                var Name = _a.Name;
                if (createdSet.has(Name)) {
                    return;
                }
                createdSet.add(Name);
                switch (Name) {
                    case ImageEditor.ControlButtonEnum.Save:
                        return createMenuItem(ImageEditor.BaseHelper.SaveSvg, _this._languageResource.Save, _this.internalSave.bind(_this));
                    case ImageEditor.ControlButtonEnum.Upload:
                        return createMenuItem(ImageEditor.BaseHelper.UploadSvg, _this._languageResource.Upload, _this.internalUpload.bind(_this));
                    case ImageEditor.ControlButtonEnum.Download:
                        return createMenuItem(ImageEditor.BaseHelper.DownloadSvg, _this._languageResource.Download, _this.internalDownload.bind(_this));
                }
            });
            this.getJqueryElement("button").attr("type", "button");
        };
        ImageEditorCellType.prototype.getLoadResultsAsync = function (imagePath) {
            var _a;
            return __awaiter(this, void 0, void 0, function () {
                var retryTime, isSameImagePath;
                var _this = this;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            retryTime = 0;
                            isSameImagePath = function () { return imagePath === _this._imagePath; };
                            _b.label = 1;
                        case 1:
                            if (!true) return [3 /*break*/, 3];
                            if (!isSameImagePath()) {
                                return [2 /*return*/, false];
                            }
                            // 10s
                            if (retryTime === 1000) {
                                return [2 /*return*/, false];
                            }
                            retryTime++;
                            return [4 /*yield*/, ImageEditor.BaseHelper.sleep(10)];
                        case 2:
                            _b.sent();
                            if (((_a = this._imageEditor.getCanvasSize()) === null || _a === void 0 ? void 0 : _a.width) !== 0) {
                                return [2 /*return*/, isSameImagePath()];
                            }
                            return [3 /*break*/, 1];
                        case 3: return [2 /*return*/];
                    }
                });
            });
        };
        ImageEditorCellType.prototype.updateAllDefaultValue = function () {
            var DefaultValueSettings = this._cellTypeParam.DefaultValueSettings;
            this._imageEditorExtension
                .setDrawColor(DefaultValueSettings.DrawColor)
                .setDrawRangValue(DefaultValueSettings.DrawThickness)
                .setShapeColor(DefaultValueSettings.ShapeColor)
                .setShapeRangValue(DefaultValueSettings.ShapeThickness)
                .setTextColor(DefaultValueSettings.TextColor)
                .setTextRangValue(DefaultValueSettings.TextSize)
                .setIconColor(DefaultValueSettings.IconColor)
                .setRangeInputTimeout()
                .setMenu(this._initMenu);
        };
        ImageEditorCellType.prototype.updatePointerStyle = function () {
            this.getJqueryElement(".tui-image-editor-virtual-range-pointer")
                .css("width", "20px")
                .css("height", "20px")
                .css("top", "-8px");
        };
        ImageEditorCellType.prototype.loadImageFromFile = function (file) {
            if (!file.type.includes("image")) {
                return;
            }
            var self = this;
            var reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = function () {
                self._imagePath = this.result;
                self._imageName = file.name.substring(0, file.name.lastIndexOf('.'));
                if (self._enhancedFinish) {
                    /**
                     * 踩过的一些坑
                     * 1. imageEditor.loadImageFromFile  存在的问题有 undo history 未被重置，导致Reset结果异常
                     * 2. 重新创建整个实例 存在的问题有 性能问题，内存上升比较快，释放的很慢，在手机上，
                     *    特别是IOS上，会报一个关于内存的错，导致页面空白。
                     */
                    self._imageEditor.ui._actions.main.load(file);
                    self._isEmpty = false;
                    self.resizeCanvasDimension();
                }
                else {
                    self.createImageEditorInstance(false);
                }
            };
        };
        ImageEditorCellType.prototype.addDragAndDropUpload = function () {
            var _this = this;
            var container = this.getJqueryElement(".tui-image-editor-main").get(0);
            var _a = this.getMaxWidthAndMaxHeight(), maxWidth = _a.maxWidth, maxHeight = _a.maxHeight;
            container.ondragover = function (e) { return e.preventDefault(); };
            container.ondragenter = function () {
                _this.cancelActiveMenuItem();
                if (!_this.getJqueryElement(".fgc-image-editor-drag-container").length) {
                    _this.getJqueryElement(".tui-image-editor-main")
                        .append("<div class='fgc-image-editor-drag-container'><div style=\"width: ".concat(maxWidth, "px;height: ").concat(maxHeight + 6, "px;border: 3px solid ").concat(Forguncy.ConvertToCssColor("Accent 1"), ";\" /></div>"));
                }
            };
            container.ondragend = function () {
                _this.getJqueryElement(".fgc-image-editor-drag-container").remove();
            };
            var self = this;
            container.ondrop = function (e) {
                e.preventDefault();
                self.getJqueryElement(".fgc-image-editor-drag-container").remove();
                var files = e.dataTransfer.files;
                if (!files.length) {
                    return;
                }
                self.loadImageFromFile(files[0]);
            };
        };
        ImageEditorCellType.prototype.Upload = function () {
            this.internalUpload();
        };
        ImageEditorCellType.prototype.Download = function () {
            this.internalDownload();
        };
        ImageEditorCellType.prototype.Save = function () {
            return this.internalSave();
        };
        ImageEditorCellType.prototype.getValueFromElement = function () {
            return this._cellValue;
        };
        ImageEditorCellType.prototype.destroy = function () {
            var _this = this;
            _super.prototype.destroy.call(this);
            Object.keys(this._listeners).forEach(function (type) {
                _this._listeners[type].forEach(function (listener) {
                    document.removeEventListener(type, listener);
                });
            });
            if (this._imageEditor) {
                this._imageEditor.destroy();
                this._imageEditor = null;
            }
        };
        ImageEditorCellType.prototype.getImageBase64Str = function () {
            return this._isEmpty ? null : this._imageEditor.toDataURL();
        };
        ImageEditorCellType.prototype.isDirty = function (dirtyInfo) {
            var imageStr = this.getImageBase64Str();
            if (this._ignoreDirtyValue !== undefined && this.isEqual(this._ignoreDirtyValue, imageStr)) {
                return false;
            }
            return !this.isEqual(dirtyInfo.currentValue, dirtyInfo.defaultValue) ||
                !this.isEqual(this._cellValueBase64Str, imageStr);
        };
        ImageEditorCellType.prototype.ignoreDirty = function (dirtyInfo) {
            this._ignoreDirtyValue = this.getImageBase64Str();
        };
        ImageEditorCellType.prototype.customValidate = function () {
            var imageStr = this.getImageBase64Str();
            if (!this.isEqual(this._cellValueBase64Str, imageStr)) {
                return this._languageResource.Error_DonotSave;
            }
        };
        ImageEditorCellType.prototype.isEqual = function (val1, val2) {
            return (this.isEmpty(val1) && this.isEmpty(val2)) ||
                val1 === val2;
        };
        ImageEditorCellType.prototype.isEmpty = function (obj) {
            if (obj === null || obj === '' || obj === undefined) {
                return true;
            }
            return false;
        };
        return ImageEditorCellType;
    }(Forguncy.Plugin.CellTypeBase));
    ImageEditor.ImageEditorCellType = ImageEditorCellType;
    Forguncy.Plugin.CellTypeHelper.registerCellType("ImageEditor.ImageEditor, ImageEditor", ImageEditor.ImageEditorCellType);
})(ImageEditor || (ImageEditor = {}));
var ImageEditor;
(function (ImageEditor) {
    var ImageEditorExtension = /** @class */ (function () {
        function ImageEditorExtension(imageEditorInstance) {
            this._instance = imageEditorInstance;
            this._ui = this._instance.ui;
        }
        ImageEditorExtension.getMenuNameByEnum = function (menu) {
            return ImageEditor.MenuEnum[menu].toLocaleLowerCase();
        };
        ImageEditorExtension.prototype._setColorPickerColor = function (menu, color, colorPropertyName) {
            var _a;
            var menuName = ImageEditorExtension.getMenuNameByEnum(menu);
            (_a = this._ui[menuName]) === null || _a === void 0 ? void 0 : _a._els[colorPropertyName || "".concat(menuName, "Colorpicker")].changeColor(Forguncy.ConvertToCssColor(color));
            return this;
        };
        ImageEditorExtension.prototype._getRangeInstance = function (menu, rangeValuePropertyName) {
            var _a;
            var menuName = ImageEditorExtension.getMenuNameByEnum(menu);
            return (_a = this._ui[menuName]) === null || _a === void 0 ? void 0 : _a._els[rangeValuePropertyName || "".concat(menuName, "Range")];
        };
        ImageEditorExtension.prototype._setRangeValue = function (menu, value, rangeValuePropertyName) {
            var _a;
            (_a = this._getRangeInstance(menu, rangeValuePropertyName)) === null || _a === void 0 ? void 0 : _a._inputSetValue(value);
            return this;
        };
        ImageEditorExtension.prototype._setRangeInputTimeout = function (menu, rangeValuePropertyName) {
            var rangeInstance = this._getRangeInstance(menu, rangeValuePropertyName);
            if (rangeInstance) {
                rangeInstance.changeInputTimeout = 1500;
            }
            return this;
        };
        ImageEditorExtension.prototype.setRangeValue = function (menu, value) {
            switch (menu) {
                case ImageEditor.MenuEnum.Draw:
                    return this.setDrawRangValue(value);
                case ImageEditor.MenuEnum.Text:
                    return this.setTextRangValue(value);
                case ImageEditor.MenuEnum.Shape:
                    return this.setShapeRangValue(value);
            }
        };
        ImageEditorExtension.prototype.setTextRangValue = function (value) {
            return this._setRangeValue(ImageEditor.MenuEnum.Text, value);
        };
        ImageEditorExtension.prototype.setDrawRangValue = function (value) {
            return this._setRangeValue(ImageEditor.MenuEnum.Draw, value);
        };
        ImageEditorExtension.prototype.setShapeRangValue = function (value) {
            return this._setRangeValue(ImageEditor.MenuEnum.Shape, value, "strokeRange");
        };
        ImageEditorExtension.prototype.setDrawColor = function (color) {
            return this._setColorPickerColor(ImageEditor.MenuEnum.Draw, color, "drawColorPicker");
        };
        ImageEditorExtension.prototype.setShapeColor = function (color) {
            return this._setColorPickerColor(ImageEditor.MenuEnum.Shape, color, "strokeColorpicker");
        };
        ;
        ImageEditorExtension.prototype.setIconColor = function (color) {
            return this._setColorPickerColor(ImageEditor.MenuEnum.Icon, color);
        };
        ;
        ImageEditorExtension.prototype.setTextColor = function (color) {
            return this._setColorPickerColor(ImageEditor.MenuEnum.Text, color);
        };
        ;
        ImageEditorExtension.prototype.setMenu = function (menu) {
            return this._ui.changeMenu(menu);
        };
        ImageEditorExtension.prototype.setRangeInputTimeout = function () {
            this._setRangeInputTimeout(ImageEditor.MenuEnum.Rotate);
            this._setRangeInputTimeout(ImageEditor.MenuEnum.Draw);
            this._setRangeInputTimeout(ImageEditor.MenuEnum.Shape, "strokeRange");
            this._setRangeInputTimeout(ImageEditor.MenuEnum.Text);
            return this;
        };
        return ImageEditorExtension;
    }());
    ImageEditor.ImageEditorExtension = ImageEditorExtension;
})(ImageEditor || (ImageEditor = {}));
var ImageEditor;
(function (ImageEditor) {
    var MenuEnum;
    (function (MenuEnum) {
        MenuEnum[MenuEnum["Crop"] = 0] = "Crop";
        MenuEnum[MenuEnum["Flip"] = 1] = "Flip";
        MenuEnum[MenuEnum["Rotate"] = 2] = "Rotate";
        MenuEnum[MenuEnum["Draw"] = 3] = "Draw";
        MenuEnum[MenuEnum["Shape"] = 4] = "Shape";
        MenuEnum[MenuEnum["Icon"] = 5] = "Icon";
        MenuEnum[MenuEnum["Text"] = 6] = "Text";
    })(MenuEnum = ImageEditor.MenuEnum || (ImageEditor.MenuEnum = {}));
    var ThemeEnum;
    (function (ThemeEnum) {
        ThemeEnum[ThemeEnum["dark"] = 0] = "dark";
        ThemeEnum[ThemeEnum["light"] = 1] = "light";
    })(ThemeEnum = ImageEditor.ThemeEnum || (ImageEditor.ThemeEnum = {}));
    var MenuBarPositionEnum;
    (function (MenuBarPositionEnum) {
        MenuBarPositionEnum[MenuBarPositionEnum["top"] = 0] = "top";
        MenuBarPositionEnum[MenuBarPositionEnum["bottom"] = 1] = "bottom";
        MenuBarPositionEnum[MenuBarPositionEnum["left"] = 2] = "left";
        MenuBarPositionEnum[MenuBarPositionEnum["right"] = 3] = "right";
    })(MenuBarPositionEnum = ImageEditor.MenuBarPositionEnum || (ImageEditor.MenuBarPositionEnum = {}));
    var ControlButtonEnum;
    (function (ControlButtonEnum) {
        ControlButtonEnum[ControlButtonEnum["Upload"] = 0] = "Upload";
        ControlButtonEnum[ControlButtonEnum["Download"] = 1] = "Download";
        ControlButtonEnum[ControlButtonEnum["Save"] = 2] = "Save";
    })(ControlButtonEnum = ImageEditor.ControlButtonEnum || (ImageEditor.ControlButtonEnum = {}));
})(ImageEditor || (ImageEditor = {}));
var ImageEditor;
(function (ImageEditor) {
    var BaseHelper = /** @class */ (function () {
        function BaseHelper() {
        }
        BaseHelper.preventDefault = function (e) {
            e.preventDefault();
        };
        BaseHelper.loadScript = function (url) {
            return new Promise(function (resolve) {
                var script = document.createElement("script");
                script.type = "text/javascript";
                script.src = "".concat(BaseHelper._scriptBaseUrl, "/").concat(url);
                document.body.appendChild(script);
                script.onload = function () { return resolve(null); };
            });
        };
        BaseHelper.generateID = function (prefix) {
            if (prefix === void 0) { prefix = "fgc-image-editor"; }
            return "".concat(prefix, "-").concat(new Date().getTime().toString(36), "-").concat(Math.random().toString(36).slice(2));
        };
        BaseHelper.isGuid = function (string) {
            return new RegExp(/^[0-9a-zA-Z]{8}-[0-9a-zA-Z]{4}-[0-9a-zA-Z]{4}-[0-9a-zA-Z]{4}-[0-9a-zA-Z]{12}$/).test(string);
        };
        BaseHelper.getFileNameByFileUrl = function (filePath) {
            var fileName = filePath.split("?")[0].split('/').pop();
            return fileName.substring(0, fileName.lastIndexOf('.'));
        };
        BaseHelper.getFileInfo = function (filePath) {
            if (!filePath) {
                return null;
            }
            var fileName = BaseHelper.getFileNameByFileUrl(filePath);
            if (Forguncy.Common.isForguncyFile(filePath)) {
                return {
                    name: fileName.substring(37),
                    url: Forguncy.Helper.SpecialPath.getFileDownloadUrl(filePath),
                };
            }
            return {
                name: fileName,
                url: filePath
            };
        };
        BaseHelper.convertBase64ToBlob = function (base64String, autoCompress, clarity) {
            return new Promise(function (resolve) {
                var data = window.atob(base64String.split(",")[1]);
                var uint8Array = new Uint8Array(data.length);
                for (var i = 0; i < data.length; i++) {
                    uint8Array[i] = data.charCodeAt(i);
                }
                var blob = new Blob([uint8Array], { type: "image/png" });
                if (autoCompress) {
                    new window.Compressor(blob, {
                        quality: clarity / 100,
                        success: function (result) {
                            resolve(result);
                        },
                        error: function (err) {
                            console.log("Compression failed!", err.message);
                            resolve(blob);
                        },
                    });
                }
                else {
                    resolve(blob);
                }
            });
        };
        BaseHelper.getFileFullName = function (fileName) {
            var newFileName = fileName;
            var decimalPointIndex = fileName.lastIndexOf(".");
            if (decimalPointIndex !== -1) {
                var extension = fileName.substring(decimalPointIndex);
                newFileName = fileName.substring(0, fileName.length - extension.length);
            }
            return newFileName + ".png";
        };
        BaseHelper.downloadFile = function (blob, fileName) {
            var link = document.createElement('a');
            link.href = window.URL.createObjectURL(blob);
            link.download = BaseHelper.getFileFullName(fileName);
            link.click();
        };
        BaseHelper.uniq = function (array) {
            var result = [];
            array.forEach(function (item) {
                if (!result.includes(item)) {
                    result.push(item);
                }
            });
            return result;
        };
        BaseHelper.sleep = function (ms) {
            return new Promise(function (r) { return setTimeout(r, ms); });
        };
        BaseHelper.isMobile = function () {
            return window.navigator.userAgent.match(/(phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|IEMobile|MQQBrowser|JUC|Fennec|wOSBrowser|BrowserNG|WebOS|Symbian|Windows Phone)/i);
        };
        BaseHelper._scriptBaseUrl = Forguncy.Helper.SpecialPath.getPluginRootPath("7B86EC35-F3C6-4BBA-9E0B-6A9FC29B6721") + "Resources";
        BaseHelper.SaveSvg = '<?xml version="1.0" encoding="UTF-8"?><svg viewBox="0 0 24 24" version="1.1" class="fgc-image-editor-svg"><path d="M19.0666809,21.933325 L21.9333325,21.933325 L21.9333325,5.58665 L18.4133325,2.06665 L2.0666575,2.06665 L2.0666575,21.933325 L5.07096678,21.933325 L5.07096678,15.0026571 L6.13763428,15.0026571 L6.13763428,21.933325 L18.0000134,21.933325 L18.0000134,16.0693321 L6.13763428,16.0693321 L6.13763428,15.0026646 L19.0666575,15.0026646 L19.0666575,16.0693321 L19.0666809,21.933325 Z M18.84,1 L23,5.16 L23,23 L1,23 L1,1 L18.84,1 Z M5,4 L15,4 L15,5 L5,5 L5,4 Z M5,7 L15,7 L15,8 L5,8 L5,7 Z M9,18 L9,20 L8,20 L8,18 L9,18 Z" id="形状备份-4" fill="#8A8A8A" fill-rule="nonzero"></path></svg>';
        BaseHelper.UploadSvg = '<?xml version="1.0" encoding="UTF-8"?><svg viewBox="0 0 24 24" version="1.1" class="fgc-image-editor-svg"><path d="M4.88370461,7.83597205 L11.1094034,1.72909624 L11.1094034,19.1067665 C11.1094034,19.3935366 11.3418634,19.625996 11.6286329,19.625996 C11.9154029,19.625996 12.1478623,19.393536 12.1478623,19.1067665 L12.1478623,1.74919939 L18.2571505,7.74012024 C18.3583082,7.83979701 18.4899123,7.88949815 18.6215429,7.88949815 C18.7556976,7.88949815 18.8897966,7.83782207 18.9913952,7.73471678 C19.1926685,7.53045379 19.1902548,7.201718 18.9859917,7.00044528 L12.0050311,0.150557138 C11.9151191,0.0619344211 11.8010972,0.0129189261 11.6844153,0.00309947653 C11.6660654,0.00112459689 11.6474687,0 11.6286248,0 C11.6198201,0 11.6112349,0.000877730238 11.6025125,0.00131659536 C11.4687692,-0.000329128736 11.3344223,0.0492623349 11.2316201,0.150584612 L4.15475404,7.09635137 C3.95051839,7.29762462 3.94813201,7.62638829 4.1494054,7.83062287 C4.25100215,7.93372816 4.3850746,7.98537663 4.51922827,7.98537663 C4.65085977,7.9853773 4.78257345,7.93564881 4.88370461,7.83597205 Z M19.8980793,15.8930497 L19.8980793,22.3269463 C19.8980793,22.6768832 19.6133946,22.9615679 19.2634578,22.9615679 L3.67308043,22.9615679 C3.3231436,22.9615679 3.0384589,22.6768832 3.0384589,22.3269463 L3.03845893,15.8930497 C3.03845893,15.6062796 2.80599899,15.3738202 2.51922946,15.3738202 C2.2324594,15.3738202 2,15.6062801 2,15.8930497 L2,22.3269463 C2,23.2494905 2.75053628,24 3.67305365,24 L19.263431,24 C20.1859752,24 20.9364847,23.2494905 20.9364847,22.3269463 L20.9364847,15.8930497 C20.9364847,15.6062796 20.7040797,15.3738202 20.4173115,15.3738202 C20.1305387,15.3738202 19.8980793,15.6062801 19.8980793,15.8930497 Z" id="形状备份-2" fill="#8A8A8A" fill-rule="nonzero"></path></svg>';
        BaseHelper.DownloadSvg = '<?xml version="1.0" encoding="UTF-8"?><svg viewBox="0 0 24 24" version="1.1" class="fgc-image-editor-svg"><path d="M4.88370461,11.7900239 L11.1094034,17.8968997 L11.1094034,0.519229463 C11.1094034,0.232459399 11.3418634,0 11.6286329,0 C11.9154029,0 12.1478623,0.232459935 12.1478623,0.519229463 L12.1478623,17.8767966 L18.2571505,11.8858757 C18.3583082,11.786199 18.4899123,11.7364978 18.6215429,11.7364978 C18.7556976,11.7364978 18.8897966,11.7881739 18.9913952,11.8912792 C19.1926685,12.0955422 19.1902548,12.424278 18.9859917,12.6255507 L12.0050311,19.4754388 C11.9151191,19.5640615 11.8010972,19.613077 11.6844153,19.6228965 C11.6660654,19.6248714 11.6474687,19.625996 11.6286248,19.625996 C11.6198201,19.625996 11.6112349,19.6251182 11.6025125,19.6246794 C11.4687692,19.6263251 11.3344223,19.5767336 11.2316201,19.4754114 L4.15475404,12.5296446 C3.95051839,12.3283713 3.94813201,11.9996077 4.1494054,11.7953731 C4.25100215,11.6922678 4.3850746,11.6406193 4.51922827,11.6406193 C4.65085977,11.6406187 4.78257345,11.6903471 4.88370461,11.7900239 Z M19.8980793,15.8930497 L19.8980793,22.3269463 C19.8980793,22.6768832 19.6133946,22.9615679 19.2634578,22.9615679 L3.67308043,22.9615679 C3.3231436,22.9615679 3.0384589,22.6768832 3.0384589,22.3269463 L3.03845893,15.8930497 C3.03845893,15.6062796 2.80599899,15.3738202 2.51922946,15.3738202 C2.2324594,15.3738202 2,15.6062801 2,15.8930497 L2,22.3269463 C2,23.2494905 2.75053628,24 3.67305365,24 L19.263431,24 C20.1859752,24 20.9364847,23.2494905 20.9364847,22.3269463 L20.9364847,15.8930497 C20.9364847,15.6062796 20.7040797,15.3738202 20.4173115,15.3738202 C20.1305387,15.3738202 19.8980793,15.6062801 19.8980793,15.8930497 Z" id="形状备份-3" fill="#8A8A8A" fill-rule="nonzero"></path></svg>';
        return BaseHelper;
    }());
    ImageEditor.BaseHelper = BaseHelper;
})(ImageEditor || (ImageEditor = {}));
var ImageEditor;
(function (ImageEditor) {
    var CellHelper = /** @class */ (function () {
        function CellHelper() {
        }
        CellHelper.setValueToCell = function (context, cellLocationFormula, value) {
            if (!cellLocationFormula) {
                return;
            }
            var cellLocation = Forguncy.Helper.getCellLocation(cellLocationFormula, context);
            var cell = Forguncy.Page.getCellByLocation(cellLocation);
            if (cell) {
                cell.setValue(value);
            }
            else {
                Forguncy.CommandHelper.setVariableValue(cellLocationFormula, value);
            }
        };
        return CellHelper;
    }());
    ImageEditor.CellHelper = CellHelper;
})(ImageEditor || (ImageEditor = {}));
var ImageEditor;
(function (ImageEditor) {
    var StringHelper = /** @class */ (function () {
        function StringHelper() {
        }
        StringHelper.isNullOrEmpty = function (value) {
            return value === undefined || value === null || value === "";
        };
        StringHelper.endsWith = function (value, search) {
            return value.indexOf(search, value.length - search.length) !== -1;
        };
        StringHelper.format = function (s) {
            var args = [];
            for (var _i = 1; _i < arguments.length; _i++) {
                args[_i - 1] = arguments[_i];
            }
            if (args.length === 0) {
                return s;
            }
            else if (args.length === 1 && typeof args[0] === "object") {
                var reg = /{([^{}]+)}/gm;
                return s.replace(reg, function (match, name) {
                    return args[0][name];
                });
            }
            else {
                var reg = /{(\d+)}/gm;
                return s.replace(reg, function (match, name) {
                    return args[~~name];
                });
            }
        };
        return StringHelper;
    }());
    ImageEditor.StringHelper = StringHelper;
})(ImageEditor || (ImageEditor = {}));
