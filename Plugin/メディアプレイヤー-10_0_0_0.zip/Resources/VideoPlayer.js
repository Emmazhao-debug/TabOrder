var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Player;
(function (Player) {
    var Preload;
    (function (Preload) {
        Preload[Preload["Auto"] = 0] = "Auto";
        Preload[Preload["Metadata"] = 1] = "Metadata";
        Preload[Preload["None"] = 2] = "None";
    })(Preload || (Preload = {}));
    var PlayerBase = /** @class */ (function (_super) {
        __extends(PlayerBase, _super);
        function PlayerBase() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        PlayerBase.prototype.getTagName = function () {
            return null;
        };
        PlayerBase.prototype.createContent = function () {
            var _this = this;
            var element = this.CellElement;
            var cellTypeMetaData = element.CellType;
            var videoInfo = cellTypeMetaData.VideoInfos;
            var controls = cellTypeMetaData.Controls;
            var autoplay = cellTypeMetaData.Autoplay;
            var loop = cellTypeMetaData.Loop;
            var notAllowDownload = cellTypeMetaData.NotAllowDownload;
            var notAllowFullScreen = cellTypeMetaData.NotAllowFullScreen;
            var disablePictureInPicture = cellTypeMetaData.DisablePictureInPicture;
            if (!videoInfo || videoInfo.length <= 0) {
                return $("<div id=" + this.ID + "></div>");
            }
            var tagName = this.getTagName();
            var VideoDiv = $("<div id='" + this.ID + tagName + "_container' style='width:100%;height:100%;align-items:center;justify-content:center;display:flex;'></div>");
            var video = $("<" + tagName + " id='" + this.ID + "_" + tagName + "' width='100%' height='100%'></" + tagName + ">");
            this._video = video;
            this._PreSrc = '';
            if (Forguncy.Platform.isIE()) {
                if (this._video[0]) {
                    var video_1 = this._video[0];
                    video_1.onended = function () {
                        video_1.pause();
                    };
                }
            }
            if (controls) {
                video.attr("controls", "controls");
            }
            if (autoplay) {
                video.attr("autoplay", "autoplay");
            }
            if (loop) {
                video.attr("loop", "loop");
            }
            if (disablePictureInPicture) {
                video.attr("disablePictureInPicture", "disablePictureInPicture");
            }
            if (notAllowDownload || notAllowFullScreen) {
                video.attr("controlslist", [notAllowDownload ? "nodownload" : null, notAllowFullScreen ? "nofullscreen " : null].join(" "));
            }
            switch (cellTypeMetaData.Preload) {
                case Preload.Metadata:
                    video.attr("preload", "metadata");
                    break;
                case Preload.None:
                    video.attr("preload", "none");
                    break;
                default:
                    video.attr("preload", "auto");
            }
            //FORGUNCY-6965
            this.onDependenceCellValueChanged(function () {
                _this.updateAttributes();
                //@ts-ignore
                if (document.pictureInPictureEnabled) {
                    //@ts-ignore
                    if (document.pictureInPictureElement) {
                        //@ts-ignore
                        document.exitPictureInPicture && document.exitPictureInPicture();
                    }
                }
            });
            VideoDiv.append(video);
            return VideoDiv;
        };
        PlayerBase.prototype.onPageLoaded = function (info) {
            this.updateAttributes();
        };
        PlayerBase.prototype.destroy = function () {
            this._video = null;
        };
        PlayerBase.prototype.updateAttributes = function () {
            this.updateVideoSrc();
            this.updatePoserSrc();
        };
        PlayerBase.prototype.updatePoserSrc = function () {
            var element = this.CellElement;
            var cellTypeMetaData = element.CellType;
            var videoInfo = cellTypeMetaData.VideoInfos;
            if (!videoInfo) {
                return;
            }
            var coverPath = videoInfo[0].ExternalCoverPathFormula;
            var posterSrc = this.getCoverPath(coverPath);
            if (posterSrc) {
                this._video.attr('poster', posterSrc);
            }
            else {
                this._video[0].removeAttribute('poster');
            }
        };
        PlayerBase.prototype.updateVideoSrc = function () {
            var element = this.CellElement;
            var cellTypeMetaData = element.CellType;
            var videoInfo = cellTypeMetaData.VideoInfos;
            if (!videoInfo) {
                return;
            }
            var externalPath = videoInfo[0].ExternalVideoPathFormula;
            var src;
            if (externalPath !== "" && externalPath !== null && externalPath !== undefined) {
                src = this.getExternalPath(externalPath).path;
            }
            else {
                src = this.getVideoPath(videoInfo[0].VideoPath);
            }
            if (this._PreSrc === src) {
                return;
            }
            this._PreSrc = src;
            if (!src) { //点到空行的时候停止播放 trick
                var videoDom = this._video[0];
                videoDom.pause();
                videoDom.removeAttribute('src');
                videoDom.load();
            }
            else {
                if (Forguncy.Platform.isIOSDevice()) {
                    src = src += '#t=0.03'; //不能给0.01 太短了也没封面
                }
                this._video.attr('src', src);
            }
        };
        PlayerBase.prototype.getExternalPath = function (externalPath) {
            var originPath = this.evaluateFormula(externalPath);
            var path = typeof originPath === 'string' ? originPath : '';
            if (this.isAttachment(path)) {
                path = this.getAttachmentUrl(path);
            }
            return { path: path, isAttachment: this.isAttachment(originPath) };
        };
        PlayerBase.prototype.getAttachmentUrl = function (src) {
            var urls = src.split("|");
            if (urls.length === 0) {
                return src;
            }
            var url = urls[0];
            var fileUrl = Forguncy.Helper.SpecialPath.getBaseUrl() + Forguncy.ModuleLoader.getCdnUrl("Upload/" + url);
            return fileUrl;
        };
        PlayerBase.prototype.isAttachment = function (src) {
            if (typeof src !== "string") {
                return false;
            }
            src = src.toLowerCase();
            if (src.indexOf("http") === 0) {
                return false;
            }
            if (src.length < 37 || src[36] !== "_") {
                return false;
            }
            // FORGUNCY-5372 [VideoPlayer]External video set as the FilePreviewer cell, the video cannot play in runtime
            //if (src[src.length - 1] !== "|") {
            //    return false;
            //}
            // ---------------------
            return true;
        };
        PlayerBase.prototype.getCoverPath = function (cover) {
            if (!cover) {
                return null;
            }
            var _a = this.getExternalPath(cover), externalPathValue = _a.path, isAttachment = _a.isAttachment;
            if (externalPathValue) {
                if (isAttachment) {
                    return externalPathValue;
                }
                if (externalPathValue.indexOf("http://") === 0 || externalPathValue.indexOf("https://") === 0) {
                    return externalPathValue;
                }
                if (externalPathValue.indexOf("GeneratedResources/Images/GenerateImages/ImageCellType/") > -1) {
                    return externalPathValue;
                }
                return Forguncy.Helper.SpecialPath.getBaseUrl() + "Upload/" + externalPathValue;
            }
            else {
                return null;
            }
        };
        PlayerBase.prototype.getVideoPath = function (video) {
            if (video) {
                return Forguncy.Helper.SpecialPath.getUploadFileFolderPathInDesigner() + "VideoPlayer/Videos/" + video;
            }
        };
        PlayerBase.prototype.getValueFromElement = function () {
            return null;
        };
        PlayerBase.prototype.setValueToElement = function () {
            // Can't edit
        };
        PlayerBase.prototype.ChangePlaySpeed = function (speed) {
            var targetSpeed = Number(speed);
            this._video[0].playbackRate = targetSpeed;
            if (Forguncy.Platform.isIE()) { //FORGUNCY-8315
                if (this._video[0]) {
                    var video = this._video[0];
                    video.setAttribute("data-playbackRate", speed);
                }
            }
        };
        PlayerBase.prototype.PlayPause = function () {
            var mediaDom = this._video[0];
            if (mediaDom.paused) {
                this.Play();
            }
            else {
                this.Pause();
            }
        };
        PlayerBase.prototype.Stop = function () {
            var mediaDom = this._video[0];
            mediaDom.pause();
            if (!isNaN(mediaDom.duration)) {
                mediaDom.currentTime = 0;
            }
        };
        PlayerBase.prototype.Play = function () {
            var mediaDom = this._video[0];
            mediaDom.play();
            if (Forguncy.Platform.isIE()) { //FORGUNCY-8315
                if (this._video[0]) {
                    var video = this._video[0];
                    var playbackRate = video.getAttribute("data-playbackRate");
                    if (playbackRate) {
                        video.playbackRate = Number(playbackRate);
                    }
                }
            }
        };
        PlayerBase.prototype.Pause = function () {
            var mediaDom = this._video[0];
            mediaDom.pause();
        };
        PlayerBase.prototype.GetPlayState = function () {
            var mediaDom = this._video[0];
            return {
                PlayState: mediaDom.paused ? 'paused' : 'playing'
            };
        };
        return PlayerBase;
    }(Forguncy.Plugin.CellTypeBase));
    Player.PlayerBase = PlayerBase;
    var VideoPlayer = /** @class */ (function (_super) {
        __extends(VideoPlayer, _super);
        function VideoPlayer() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        VideoPlayer.prototype.getTagName = function () {
            return "video";
        };
        return VideoPlayer;
    }(PlayerBase));
    Player.VideoPlayer = VideoPlayer;
    var AudioPlayer = /** @class */ (function (_super) {
        __extends(AudioPlayer, _super);
        function AudioPlayer() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        AudioPlayer.prototype.getTagName = function () {
            return "audio";
        };
        return AudioPlayer;
    }(PlayerBase));
    Player.AudioPlayer = AudioPlayer;
})(Player || (Player = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("VideoPlayer.VideoPlayer, VideoPlayer", Player.VideoPlayer);
Forguncy.Plugin.CellTypeHelper.registerCellType("VideoPlayer.AudioPlayer, VideoPlayer", Player.AudioPlayer);
