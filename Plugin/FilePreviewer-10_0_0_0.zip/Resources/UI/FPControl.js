var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var FilePreviewer;
(function (FilePreviewer) {
    var FPControl = /** @class */ (function (_super) {
        __extends(FPControl, _super);
        function FPControl() {
            var _this = _super.call(this) || this;
            _this.explorerControl = new FilePreviewer.ExplorerControl();
            _this.previewerControl = new FilePreviewer.PreviewerControl();
            _this.initializeProperties();
            return _this;
        }
        FPControl.prototype.setMetadata = function (metadata) {
            var _this = this;
            this.metadata = metadata;
            this.explorerControl.customUploadIcon = this.metadata.CustomUploadIcon;
            this.explorerControl.layoutMode = this.metadata.LayoutMode;
            this.explorerControl.customWidth = this.metadata.CustomWidth;
            this.explorerControl.customHeight = this.metadata.CustomHeight;
            this.explorerControl.isHiddenFileName = this.metadata.IsHiddenFileName;
            this.explorerControl.isHiddenToolbar = this.metadata.IsHiddenToolbar;
            this.explorerControl.isSmallButtonMode = this.metadata.IsSmallButtonMode;
            this.explorerControl.readonly = this.metadata.Readonly;
            this.explorerControl.clickToPreview = this.metadata.ClickToPreview;
            this.explorerControl.clickFileNameToPreview = this.metadata.ClickFileNameToPreview;
            this.explorerControl.maxFileCount = (this.metadata.UploadLimit && this.metadata.UploadLimit.MaxUploadFileCount) || Number.MAX_VALUE;
            if (metadata.StorageType === 0 /* StorageType.Forguncy */) {
                this.storageService = new FilePreviewer.ServerStorageService(this.metadata);
            }
            else if (metadata.StorageType === 1 /* StorageType.Tencent */) {
                this.storageService = new FilePreviewer.TencentCloudStorageService(this.metadata);
            }
            this.previewerControl.previewType = this.metadata.PreviewType;
            this.previewerControl.getKKFileViewHostHandler = function () { return _this.metadata.KKFileViewHost; };
            this.previewerControl.getKKFileViewExtensionsHandler = function () { return _this.metadata.KKFileViewExtensions; };
        };
        FPControl.prototype.getValue = function () {
            var result = this.explorerControl.fileItems.filter(function (i) { return i.status === 0 /* FileStatus.Normal */; }).map(function (i) {
                return i.getStorageSrc();
            }).join("|");
            return result;
        };
        FPControl.prototype.setValue = function (value) {
            var _a;
            this.explorerControl.clearFiles();
            if (typeof (value) === "string") {
                (_a = this.explorerControl).addFile.apply(_a, FilePreviewer.FileItemHelper.parseFromString(value, this.metadata));
            }
        };
        FPControl.prototype.initializeProperties = function () {
            var _this = this;
            this.previewerControl.fileItems = this.explorerControl.fileItems;
            this.previewerControl.on("Download" /* PreviewerControlEvents.Download */, function (fileItems) {
                _this.downloadFiles(fileItems);
            });
            // 预览
            this.explorerControl.on("Preview" /* ExplorerControlEvents.Preview */, function (selectedItems) {
                _this.previewFirstItem(selectedItems);
            });
            // 文件项集合改变
            this.explorerControl.on("FileItemsChanged" /* ExplorerControlEvents.FileItemsChanged */, function () {
                _this.previewerControl.syncFileItems(_this.explorerControl.fileItems);
            });
            // 上传
            this.explorerControl.on("Upload" /* ExplorerControlEvents.Upload */, function () {
                _this.uploadFilesManually();
            });
            // 拖曳上传
            this.explorerControl.on("DropFile" /* ExplorerControlEvents.DropFile */, function (files) {
                _this.uploadFiles(files);
            });
            // 粘贴上传
            this.explorerControl.on("PasterFile" /* ExplorerControlEvents.PasteFile */, function (files) {
                _this.uploadFiles(files);
            });
            // 下载
            this.explorerControl.on("Download" /* ExplorerControlEvents.Download */, function (fileItems) {
                _this.downloadFiles(fileItems);
            });
            // 删除
            this.explorerControl.on("Delete" /* ExplorerControlEvents.Delete */, function (selectedFileItems) {
                _this.deleteFiles(selectedFileItems);
            });
        };
        FPControl.prototype.previewFirstItem = function (files) {
            var _a;
            var activeItem = (files === null || files === void 0 ? void 0 : files[0]) || ((_a = this.explorerControl.fileItems) === null || _a === void 0 ? void 0 : _a[0]);
            if (activeItem) {
                this.previewerControl.activeItem = activeItem;
                this.previewerControl.show();
            }
            else {
                alert(FilePreviewer.Resources.Error_SelectionCannotBeEmpty);
            }
        };
        FPControl.prototype.uploadFilesManually = function () {
            var _this = this;
            var multiple = this.metadata.UploadLimit && this.metadata.UploadLimit.MaxUploadFileCount !== 1;
            var accept = this.metadata.UploadLimit ? this.metadata.UploadLimit.ExtensionFilter : null;
            FilePreviewer.OpenFileDialog.open(multiple, accept, function (files) {
                _this.uploadFiles(files);
            });
        };
        FPControl.prototype.deleteFiles = function (files) {
            var _this = this;
            if (!files || files.length === 0) {
                alert(FilePreviewer.Resources.Error_SelectionCannotBeEmpty);
            }
            __spreadArray([], files, true).forEach(function (fileItem) {
                if (fileItem.status === 0 /* FileStatus.Normal */) {
                    _this.storageService.delete(fileItem.getEncodeURIComponentSrc(), function () {
                        _this.explorerControl.removeFile(fileItem);
                        _this.dispatch("ValueChanged" /* FPControlEvents.ValueChanged */);
                    }, function (e) {
                        alert(e.errorMessage);
                    });
                }
            });
        };
        FPControl.prototype.downloadFiles = function (files) {
            var _this = this;
            if (!files || files.length === 0) {
                alert(FilePreviewer.Resources.Error_SelectionCannotBeEmpty);
            }
            var count = 0;
            files.forEach(function (fileItem, index) {
                if ((fileItem === null || fileItem === void 0 ? void 0 : fileItem.status) === 0 /* FileStatus.Normal */) {
                    // Chrome 批量下载时需要延时
                    setTimeout(function () {
                        _this.storageService.download(fileItem.getEncodeURIComponentSrc());
                    }, 100 * count++);
                }
            });
        };
        FPControl.prototype.uploadFiles = function (files) {
            for (var _i = 0, _a = __spreadArray([], files, true); _i < _a.length; _i++) {
                var file = _a[_i];
                if (!this.uploadFile(file)) {
                    break;
                }
            }
        };
        FPControl.prototype.uploadFile = function (file) {
            var _this = this;
            return FilePreviewer.UploadLimitChecker.checkFileCount(this.explorerControl.fileItems.length + 1, this.metadata.UploadLimit, function () {
                if (FilePreviewer.UploadLimitChecker.check(file, _this.metadata.UploadLimit, function (e) { return alert(e.errorMessage); })) {
                    var loadingFileItem_1 = new FilePreviewer.LoadingFileItem(file.name);
                    _this.explorerControl.addFile(loadingFileItem_1);
                    FilePreviewer.UploadLimitChecker.compressFile(file, _this.metadata.UploadLimit, function (actualFile) {
                        // 调用存储服务上传方法
                        _this.storageService.upload(actualFile, {
                            success: function (e) {
                                if (_this.previewerControl.activeItem === loadingFileItem_1) {
                                    _this.previewerControl.activeItem = e.fileItem;
                                }
                                _this.explorerControl.replaceFile(loadingFileItem_1, e.fileItem);
                                _this.dispatch("ValueChanged" /* FPControlEvents.ValueChanged */);
                            },
                            fail: function (e) {
                                alert(e.errorMessage);
                                if (_this.previewerControl.activeItem === loadingFileItem_1) {
                                    _this.previewerControl.activeItem = _this.previewerControl.fileItems[0];
                                }
                                _this.explorerControl.removeFile(loadingFileItem_1);
                            },
                            progress: function (e) {
                                loadingFileItem_1.change(e);
                            }
                        });
                    });
                }
            }, function (errorMessage) {
                alert(errorMessage);
            });
        };
        return FPControl;
    }(FilePreviewer.UserControl));
    FilePreviewer.FPControl = FPControl;
    var FPView = /** @class */ (function (_super) {
        __extends(FPView, _super);
        function FPView() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        FPView.prototype.createContainer = function () {
            this.container = $("<div class=\"FP-root\"></div>");
        };
        FPView.prototype.createChildren = function () {
            var _this = this;
            this.addChild(new FilePreviewer.ExplorerView(this.target.explorerControl));
            if (this.previewerRoot) {
                this.previewerRoot.remove();
            }
            this.previewerRoot = $("<div class=\"FP-root\"></div>");
            $(document.body).append(this.previewerRoot.hide());
            this.target.previewerControl.on("PropertyChanged" /* UserControlEvents.PropertyChanged */, function (propertyName) {
                if (propertyName === "visibility") {
                    if (_this.target.previewerControl.visibility) {
                        _this.previewerRoot.show();
                    }
                    else {
                        _this.previewerRoot.hide();
                    }
                }
            });
            this.addChild(new FilePreviewer.PreviewerView(this.target.previewerControl), this.previewerRoot);
        };
        return FPView;
    }(FilePreviewer.ControlUIBase));
    FilePreviewer.FPView = FPView;
})(FilePreviewer || (FilePreviewer = {}));
