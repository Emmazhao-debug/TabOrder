var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var FilePreviewer;
(function (FilePreviewer_1) {
    var FilePreviewer = /** @class */ (function (_super) {
        __extends(FilePreviewer, _super);
        function FilePreviewer() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.control = new FilePreviewer_1.FPControl();
            return _this;
        }
        FilePreviewer.prototype.createContent = function () {
            return this.control.identify(this.ID).createUI(FilePreviewer_1.FPView).container;
        };
        FilePreviewer.prototype.onPageLoaded = function (info) {
            var _this = this;
            _super.prototype.onPageLoaded.call(this, info);
            this.control.setMetadata(this.preHandleMetadata(this.CellElement));
            this.control.on("ValueChanged" /* FPControlEvents.ValueChanged */, function () {
                _this.commitValue();
            });
            this.control.refresh();
        };
        FilePreviewer.prototype.destroy = function () {
            this.control && this.control.dispose();
        };
        FilePreviewer.prototype.setValueToElement = function (jelement, value) {
            this.control.setValue(value);
        };
        FilePreviewer.prototype.getValueFromElement = function () {
            return this.control.getValue();
        };
        FilePreviewer.prototype.setReadOnly = function (value) {
            _super.prototype.setReadOnly.call(this, value);
            this.control.explorerControl.readonly = this.isReadOnly();
        };
        FilePreviewer.prototype.enable = function () {
            _super.prototype.enable.call(this);
            this.onIsDisabledChanged();
        };
        FilePreviewer.prototype.disable = function () {
            _super.prototype.disable.call(this);
            this.onIsDisabledChanged();
        };
        FilePreviewer.prototype.onIsDisabledChanged = function () {
            this.control.explorerControl.enabled = !this.isDisabled();
        };
        FilePreviewer.prototype.preHandleMetadata = function (cellContentElement) {
            var thisArg = this;
            var model = cellContentElement.CellType;
            var result = {
                Readonly: !!model.Readonly,
                UploadLimit: model.UploadLimit,
                StorageType: model.StorageType,
                PreviewType: model.PreviewType,
                get KKFileViewHost() {
                    return thisArg.evaluateFormula(model.KKFileViewHost);
                },
                get KKFileViewExtensions() {
                    return thisArg.evaluateFormula(model.KKFileViewExtensions);
                },
                IsHiddenFileName: !!model.IsHiddenFileName,
                IsHiddenToolbar: !!model.IsHiddenToolbar,
                IsSmallButtonMode: !!model.IsSmallButtonMode,
                CustomUploadIcon: model.CustomUploadIcon,
                LayoutMode: model.LayoutMode,
                CustomWidth: model.CustomWidth || 64,
                CustomHeight: model.CustomHeight || 64,
                ClickToPreview: model.ClickToPreview,
                ClickFileNameToPreview: model.ClickFileNameToPreview,
                ServerPropertiesId: cellContentElement.ServerPropertiesId,
                CellNames: cellContentElement.Name,
                get Bucket() {
                    return thisArg.evaluateFormula(model.Bucket);
                },
                get Region() {
                    return thisArg.evaluateFormula(model.Region);
                },
                get SecretId() {
                    return thisArg.evaluateFormula(model.SecretId);
                },
                get SecretKey() {
                    return thisArg.evaluateFormula(model.SecretKey);
                },
                get Folder() {
                    return thisArg.evaluateFormula(model.Folder);
                }
            };
            return result;
        };
        FilePreviewer.prototype.Upload = function () {
            this.control.uploadFilesManually();
        };
        FilePreviewer.prototype.Download = function () {
            this.control.downloadFiles(this.control.explorerControl.selectedItems);
        };
        FilePreviewer.prototype.Preview = function () {
            this.control.previewFirstItem(this.control.explorerControl.selectedItems);
        };
        FilePreviewer.prototype.Delete = function () {
            this.control.deleteFiles(this.control.explorerControl.selectedItems);
        };
        FilePreviewer.prototype.SelectItem = function (index, ctrlSelect) {
            index = parseInt(index === null || index === void 0 ? void 0 : index.toString());
            var explorer = this.control.explorerControl;
            if (index === -1) {
                if (ctrlSelect) {
                    if (explorer.selectedItems.length < explorer.fileItems.length) {
                        explorer.selectAll();
                    }
                    else {
                        explorer.clearSelect();
                    }
                }
                else {
                    explorer.selectAll();
                }
            }
            else {
                if (ctrlSelect) {
                    explorer.ctrlSelect(explorer.fileItems[index]);
                }
                else {
                    explorer.select(explorer.fileItems[index]);
                }
            }
        };
        return FilePreviewer;
    }(Forguncy.Plugin.CellTypeBase));
    FilePreviewer_1.FilePreviewer = FilePreviewer;
})(FilePreviewer || (FilePreviewer = {}));
// Key format is "Namespace.ClassName, AssemblyName"
Forguncy.Plugin.CellTypeHelper.registerCellType("FilePreviewer.FilePreviewer, FilePreviewer", FilePreviewer.FilePreviewer);
