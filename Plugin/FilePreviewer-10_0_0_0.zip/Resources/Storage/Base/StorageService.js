var FilePreviewer;
(function (FilePreviewer) {
    var ProgressData = /** @class */ (function () {
        function ProgressData() {
        }
        return ProgressData;
    }());
    FilePreviewer.ProgressData = ProgressData;
    var SuccessData = /** @class */ (function () {
        function SuccessData() {
        }
        return SuccessData;
    }());
    FilePreviewer.SuccessData = SuccessData;
    var FailData = /** @class */ (function () {
        function FailData() {
        }
        return FailData;
    }());
    FilePreviewer.FailData = FailData;
    var Transmit = /** @class */ (function () {
        function Transmit() {
        }
        return Transmit;
    }());
    FilePreviewer.Transmit = Transmit;
})(FilePreviewer || (FilePreviewer = {}));
