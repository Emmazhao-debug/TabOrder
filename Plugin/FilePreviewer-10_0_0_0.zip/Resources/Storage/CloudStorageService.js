var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var FilePreviewer;
(function (FilePreviewer) {
    /**
     * 用户名关键字
     */
    var Folder_Keywords_CurrentUser = "%CurrentUser%";
    /**
     * 匿名用户的默认文件夹名称
     */
    var Folder_Anonymous_Default = "_Forguncy_AnonymousUser";
    var TencentCloudFileItem = /** @class */ (function (_super) {
        __extends(TencentCloudFileItem, _super);
        function TencentCloudFileItem() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        TencentCloudFileItem.prototype.getEncodeURIComponentSrc = function () {
            var index = this.src.lastIndexOf("/") + 1;
            var base = this.src.substring(0, index);
            var fileName = this.src.substring(index);
            return base + encodeURIComponent(fileName);
        };
        TencentCloudFileItem.prototype.getStorageSrc = function () {
            return "<Tencent>" + this.src;
        };
        TencentCloudFileItem.prototype.getDisplayFileName = function () {
            // Length of Guid: 36 
            // Length of Underline: 1
            // Sample: c020d44c-4322-48c4-9997-f344daf52776_sample.png
            return this.getFileName().slice(37);
        };
        return TencentCloudFileItem;
    }(FilePreviewer.FileItem));
    FilePreviewer.TencentCloudFileItem = TencentCloudFileItem;
    /**
     * 腾讯云存储服务
     */
    var TencentCloudStorageService = /** @class */ (function () {
        function TencentCloudStorageService(metadata) {
            this.metadata = metadata;
            if (!this.metadata.UploadLimit) {
                this.metadata.UploadLimit = {
                    ExtensionFilter: "",
                    MaxUploadFileCount: null,
                    SizeLimit: null
                };
            }
        }
        TencentCloudStorageService.prototype.download = function (url, onSuccess, onError) {
            var link;
            if (FilePreviewer.PlatformInfo.isWeChat()) {
                link = $("<a>download</a>").attr("href", FilePreviewer.UrlHelper.getUrlWithTimestamp(url));
            }
            else {
                link = $("<a download>download</a>").attr("href", url);
            }
            $("body").append(link);
            link[0].click();
            link.remove();
            onSuccess && onSuccess();
        };
        TencentCloudStorageService.prototype.upload = function (file, transmit) {
            this.sliceUpload(file, transmit);
        };
        TencentCloudStorageService.prototype.delete = function (url, onSuccess, onError) {
            this.deleteObject(url, onSuccess, onError);
        };
        TencentCloudStorageService.prototype.getCOS = function () {
            var _a, _b;
            return new COS({
                SecretId: (_a = this.metadata.SecretId) === null || _a === void 0 ? void 0 : _a.trim(),
                SecretKey: (_b = this.metadata.SecretKey) === null || _b === void 0 ? void 0 : _b.trim(),
            });
        };
        TencentCloudStorageService.prototype.sliceUpload = function (file, transmit) {
            var _a, _b;
            this.getCOS().sliceUploadFile({
                Bucket: (_a = this.metadata.Bucket) === null || _a === void 0 ? void 0 : _a.trim(),
                Region: (_b = this.metadata.Region) === null || _b === void 0 ? void 0 : _b.trim(),
                Key: this.getFolderName() + FilePreviewer.GUID.generate() + "_" + file.name,
                ContentDisposition: "attachement;filename=" + encodeURIComponent(file.name),
                Body: file,
                onProgress: function (e) {
                    transmit.progress && transmit.progress({ raw: file, loaded: e.loaded, total: e.total });
                }
            }, function (err, data) {
                if (err) {
                    transmit.fail && transmit.fail({ raw: file, errorMessage: FilePreviewer.Resources.Error_UploadFailed + JSON.stringify(err) });
                }
                else {
                    transmit.success && transmit.success({ raw: file, fileItem: new TencentCloudFileItem("https://" + decodeURIComponent(data.Location)) });
                }
            });
        };
        TencentCloudStorageService.prototype.deleteObject = function (url, onSuccess, onError) {
            onSuccess && onSuccess();
            // 不删除
            //this.getCOS().deleteObject({
            //    Bucket: this.metadata.Bucket,
            //    Region: this.metadata.Region,
            //    Key: this.getFolderName() + url.split('/').splice(-1)[0],
            //}, function (err, data) {
            //    if (err || data.statusCode !== "204") {
            //        onError && onError(err);
            //    }
            //    else {
            //        onSuccess && onSuccess();
            //    }
            //});
        };
        TencentCloudStorageService.prototype.getFolderName = function () {
            // 用户名
            var username = Forguncy.Page.getUserName();
            username = (FilePreviewer.StringHelper.isNullOrEmpty(username) ? Folder_Anonymous_Default : username);
            // 文件夹名
            var folder = this.metadata.Folder.replace(Folder_Keywords_CurrentUser, username);
            folder = folder.slice(-1) === "/" ? folder : folder + "/";
            return folder;
        };
        return TencentCloudStorageService;
    }());
    FilePreviewer.TencentCloudStorageService = TencentCloudStorageService;
})(FilePreviewer || (FilePreviewer = {}));
