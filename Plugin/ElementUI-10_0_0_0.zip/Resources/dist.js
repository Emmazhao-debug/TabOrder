var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var ElementTheme;
(function (ElementTheme) {
    var _a;
    var colorDictionary = {
        "--el-color-primary": "Accent 1",
        "--el-color-primary-light-1": "Accent 1 10",
        "--el-color-primary-light-2": "Accent 1 20",
        "--el-color-primary-light-3": "Accent 1 30",
        "--el-color-primary-light-4": "Accent 1 40",
        "--el-color-primary-light-5": "Accent 1 50",
        "--el-color-primary-light-6": "Accent 1 60",
        "--el-color-primary-light-7": "Accent 1 70",
        "--el-color-primary-light-8": "Accent 1 80",
        "--el-color-primary-light-9": "Accent 1 90",
        "--el-color-primary-dark-2": "Accent 1 -20",
    };
    var updated = false;
    function updateCssAndAppend(forceUpdate) {
        if (forceUpdate === void 0) { forceUpdate = false; }
        if (updated && !forceUpdate) {
            return;
        }
        var cssStr = "";
        for (var key in colorDictionary) {
            cssStr += "".concat(key, ":").concat(Forguncy.ConvertToCssColor(colorDictionary[key]), ";");
        }
        cssStr = ":root{ ".concat(cssStr, " }");
        $("#FGC_Element_Plus_Variables").remove();
        var style = document.createElement("style");
        style.type = "text/css";
        style.id = "FGC_Element_Plus_Variables";
        style.innerHTML = cssStr;
        document.getElementsByTagName("head")[0].appendChild(style);
        updated = true;
    }
    ElementTheme.updateCssAndAppend = updateCssAndAppend;
    // @ts-ignore
    (_a = Forguncy.CellTypePreview) === null || _a === void 0 ? void 0 : _a.addThemeChangeListener(function () { return updateCssAndAppend(true); });
})(ElementTheme || (ElementTheme = {}));
var ElementCellTypes;
(function (ElementCellTypes) {
    var CultureEnum;
    (function (CultureEnum) {
        CultureEnum["CN"] = "ElementPlusLocaleZhCn";
        CultureEnum["EN"] = "ElementPlusLocaleEn";
        CultureEnum["KR"] = "ElementPlusLocaleKo";
        CultureEnum["JA"] = "ElementPlusLocaleJa";
    })(CultureEnum || (CultureEnum = {}));
    ElementCellTypes.iconComponent = Vue.defineComponent({
        template: "<el-icon v-html=\"icon\" />",
        props: {
            icon: String
        }
    });
    ElementCellTypes.imageComponent = Vue.defineComponent({
        template: "<el-image class=\"el-icon\" fit=\"contain\" :src=\"src\" />",
        props: {
            src: String
        }
    });
    ElementCellTypes.getBase64FromSvgElement = function (svgStr) {
        return 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svgStr)));
    };
    var ElementCellTypeBase = /** @class */ (function (_super) {
        __extends(ElementCellTypeBase, _super);
        function ElementCellTypeBase() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this._styleContainerIdSet = new Set();
            _this.cellType = _this.CellElement.CellType;
            _this._cellStyle = {};
            return _this;
        }
        Object.defineProperty(ElementCellTypeBase.prototype, "fontDom", {
            get: function () {
                return this._fontDom;
            },
            set: function (value) {
                this._fontDom = value;
                this.setFontToDom();
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(ElementCellTypeBase.prototype, "fontSelector", {
            get: function () {
                return this._fontSelector;
            },
            set: function (value) {
                this._fontSelector = value;
                this.setFontStyleElement();
            },
            enumerable: false,
            configurable: true
        });
        ElementCellTypeBase.prototype.createVueApp = function (option) {
            var self = this;
            if (option.beforeCreate) {
                var beforeCreate_1 = option.beforeCreate;
                option.beforeCreate = function () {
                    self.vue = this;
                    beforeCreate_1();
                };
            }
            else {
                option.beforeCreate = function () {
                    self.vue = this;
                };
            }
            var vueApp = Vue.createApp(option);
            vueApp.use(window.ElementPlus, {
                locale: window[CultureEnum[Forguncy.RS.Culture]],
            });
            vueApp.mount("#".concat(this.uId));
            this._vueApp = vueApp;
        };
        ElementCellTypeBase.prototype.setFontStyle = function (styleInfo) {
            var currentStyleInfo = this._cellStyle;
            currentStyleInfo.FontFamily = styleInfo.FontFamily;
            currentStyleInfo.FontStyle = styleInfo.FontStyle;
            currentStyleInfo.FontSize = styleInfo.FontSize;
            currentStyleInfo.FontWeight = styleInfo.FontWeight;
            currentStyleInfo.Foreground = styleInfo.Foreground;
            currentStyleInfo.Strikethrough = styleInfo.Strikethrough;
            currentStyleInfo.Underline = styleInfo.Underline;
            this.setFontToDom();
            this.setFontStyleElement();
        };
        ElementCellTypeBase.prototype.getStyles = function () {
            var _a, _b;
            var styleInfo = (_a = this._cellStyle) !== null && _a !== void 0 ? _a : {};
            var styles = {
                "font-family": (_b = styleInfo.FontFamily) !== null && _b !== void 0 ? _b : "",
                "font-size": styleInfo.FontSize && styleInfo.FontSize > 0 ? styleInfo.FontSize : "",
                "font-style": styleInfo.FontStyle ? styleInfo.FontStyle.toLowerCase() : "",
                "font-weight": styleInfo.FontWeight ? styleInfo.FontWeight.toLowerCase() : "",
            };
            var textDecoration = [];
            if (styleInfo.Underline) {
                textDecoration.push("underline");
            }
            if (styleInfo.Strikethrough) {
                textDecoration.push("line-through");
            }
            styles["text-decoration"] = textDecoration.join(" ");
            styles["color"] = styleInfo.Foreground ? Forguncy.ConvertToCssColor(styleInfo.Foreground) : "";
            return styles;
        };
        ElementCellTypeBase.prototype.getStyleContainerElement = function (prefix) {
            var id = "".concat(this.uId, "-style-").concat(prefix);
            this._styleContainerIdSet.add(id);
            var el = document.getElementById(id);
            if (el) {
                return el;
            }
            var style = document.createElement("style");
            style.type = "text/css";
            style.id = id;
            document.getElementsByTagName("head")[0].appendChild(style);
            return style;
        };
        ElementCellTypeBase.prototype.setFontStyleElement = function () {
            var _this = this;
            if (!this._fontSelector) {
                return;
            }
            var styles = this.getStyles();
            var str = "";
            Object.keys(styles).forEach(function (key) {
                var value = styles[key];
                if (!value) {
                    return;
                }
                if (key === "font-size") {
                    value += "px";
                }
                str += "".concat(key, ":").concat(value, " !important;");
            });
            var selectorArray = typeof this._fontSelector === 'string' ? [this.fontSelector] : this.fontSelector;
            var selector = selectorArray.map(function (item) { return ".".concat(_this.uId, " ").concat(item); }).join(",");
            this.getStyleContainerElement("font").innerHTML = "".concat(selector, "{").concat(str, "}");
        };
        ElementCellTypeBase.prototype.setFontToDom = function () {
            var _a;
            (_a = this.fontDom) === null || _a === void 0 ? void 0 : _a.css(this.getStyles());
        };
        ElementCellTypeBase.generateID = function (prefix) {
            if (prefix === void 0) { prefix = "fgc-el"; }
            return "".concat(prefix, "-").concat(new Date().getTime().toString(36), "-").concat(Math.random().toString(36).slice(2));
        };
        ElementCellTypeBase.prototype.createContent = function () {
            ElementTheme.updateCssAndAppend();
            this.uId = ElementCellTypeBase.generateID();
            // 外边加一层Div，设置ID，否则在输入值是ValidateTooltip不消失
            var container = $("<div id=".concat(this.ID, "><div id =\"").concat(this.uId, "\" class=\"").concat(this.uId, "\" style='width:100%;height:100%'></div></div>"))
                .css("width", "100%")
                .css("height", "100%");
            this._cellStyle = this.CellElement.StyleInfo;
            this.vueContainer = container;
            return container;
        };
        ElementCellTypeBase.prototype.addCustomClass = function (className) {
            this.getContainer().addClass(className);
        };
        ElementCellTypeBase.prototype.loop = function () {
            return undefined;
        };
        ElementCellTypeBase.prototype.setValueToElement = function (jelement, value) {
            var _a;
            return (((_a = this.vue) === null || _a === void 0 ? void 0 : _a.setValue) || this.loop)(value);
        };
        ElementCellTypeBase.prototype.getValueFromElement = function () {
            var _a;
            return (((_a = this.vue) === null || _a === void 0 ? void 0 : _a.getValue) || this.loop)();
        };
        ElementCellTypeBase.prototype.disable = function () {
            _super.prototype.disable.call(this);
            this.onIsDisabledChanged();
        };
        ElementCellTypeBase.prototype.enable = function () {
            _super.prototype.enable.call(this);
            this.onIsDisabledChanged();
        };
        ElementCellTypeBase.prototype.onIsDisabledChanged = function () {
            var _a, _b, _c, _d;
            if (!this.vue) {
                return;
            }
            if (this.isDisabled()) {
                (_b = (_a = this.vue).disable) === null || _b === void 0 ? void 0 : _b.call(_a);
            }
            else {
                (_d = (_c = this.vue).enable) === null || _d === void 0 ? void 0 : _d.call(_c);
            }
        };
        ElementCellTypeBase.prototype.setReadOnly = function (value) {
            var _a;
            _super.prototype.setReadOnly.call(this, value);
            return (((_a = this.vue) === null || _a === void 0 ? void 0 : _a.setReadOnly) || this.loop)(this.isReadOnly());
        };
        ElementCellTypeBase.prototype.onPageLoaded = function (info) {
            var _a;
            this.setFontToDom();
            this.setReadOnly(info.isReadOnly);
            if (info.isDisabled) {
                this.disable();
            }
            else {
                this.enable();
            }
            if ((_a = this.vue) === null || _a === void 0 ? void 0 : _a.setValue) {
                this.vue.setValue(info.value);
            }
        };
        ElementCellTypeBase.prototype.toNumber = function (value) {
            if (value === null || value === undefined || value === "") {
                return undefined;
            }
            var number = Number(value);
            if (isNaN(number)) {
                return undefined;
            }
            return number;
        };
        ElementCellTypeBase.prototype.destroy = function () {
            var _a;
            (_a = this._vueApp) === null || _a === void 0 ? void 0 : _a.unmount();
            this._fontDom = null;
            this.fontSelector = null;
            this._styleContainerIdSet.forEach(function (eid) { var _a; return (_a = document.getElementById(eid)) === null || _a === void 0 ? void 0 : _a.remove(); });
            _super.prototype.destroy.call(this);
        };
        ElementCellTypeBase.prototype.getIconComponent = function (icon, callback) {
            this.getIcon(icon, function (result) {
                if (result.isSvg) {
                    callback(Vue.h(ElementCellTypes.iconComponent, { icon: result.icon }), result);
                }
                else {
                    callback(Vue.h(ElementCellTypes.imageComponent, { src: result.icon }), result);
                }
            });
        };
        ElementCellTypeBase.prototype.getIcon = function (icon, callback) {
            if (icon) {
                if (typeof (icon) === "string") {
                    var src_1 = icon;
                    if (this.isAttachment(src_1)) {
                        src_1 = Forguncy.Helper.SpecialPath.getUploadImageFolderPathInServer() + encodeURIComponent(src_1);
                    }
                    if (src_1.endsWith(".svg")) {
                        Forguncy.ImageHelper.requestSvg(src_1, function (svgNode) {
                            if (svgNode) {
                                var svg = $(svgNode);
                                Forguncy.ImageHelper.preHandleSvg(svg, null);
                                callback({
                                    "icon": svg[0].outerHTML,
                                    isSvg: true
                                });
                            }
                            else {
                                callback({
                                    icon: src_1,
                                    isSvg: false
                                });
                            }
                        });
                    }
                    else {
                        callback({
                            icon: src_1,
                            isSvg: false
                        });
                    }
                }
            }
            if (!(icon === null || icon === void 0 ? void 0 : icon.Name)) {
                return;
            }
            var src;
            if (icon.BuiltIn) {
                src = Forguncy.Helper.SpecialPath.getBuiltInImageFolderPath() + icon.Name;
            }
            else {
                src = Forguncy.Helper.SpecialPath.getImageEditorUploadImageFolderPath() + encodeURIComponent(icon.Name);
            }
            if (Forguncy.ImageDataHelper.IsSvg(src)) {
                Forguncy.ImageHelper.requestSvg(src, function (svgNode) {
                    var svg = $(svgNode);
                    Forguncy.ImageHelper.preHandleSvg(svg, icon.UseCellTypeForeColor ? "currentColor" : icon.Color);
                    callback({
                        "icon": svg[0].outerHTML,
                        isSvg: true
                    });
                });
            }
            else {
                callback({
                    icon: src,
                    isSvg: false
                });
            }
        };
        ElementCellTypeBase.prototype.isAttachment = function (src) {
            if (typeof src !== "string") {
                return false;
            }
            src = src.toLowerCase();
            if (src.indexOf("http") === 0) {
                return false;
            }
            if (src.length < 37 || src[36] !== "_") {
                return false;
            }
            // FORGUNCY-5372 [VideoPlayer]External video set as the FilePreviewer cell, the video cannot play in runtime
            //if (src[src.length - 1] !== "|") {
            //    return false;
            //}
            // ---------------------
            return true;
        };
        ElementCellTypeBase.prototype.isEmpty = function (v) {
            return v === null || v === undefined || v === "";
        };
        ElementCellTypeBase.prototype.refreshUI = function () {
            var _a;
            (((_a = this.vue) === null || _a === void 0 ? void 0 : _a.$forceUpdate) || this.loop)();
        };
        ElementCellTypeBase.prototype.isValidDate = function (date) {
            return date instanceof Date && !isNaN(date.getTime());
        };
        ElementCellTypeBase.prototype.getCustomSlotByPath = function (slotPath) {
            var _a, _b;
            var slot = this.getPropertyByPath(window.FgcElement, slotPath.split("."));
            var slotStr = "";
            if (slot) {
                var classNames = (_b = (_a = this.CellElement.CssClassName) === null || _a === void 0 ? void 0 : _a.split(" ")) !== null && _b !== void 0 ? _b : [];
                for (var _i = 0, classNames_1 = classNames; _i < classNames_1.length; _i++) {
                    var name_1 = classNames_1[_i];
                    var selectSlotFunc = slot[name_1];
                    slotStr = selectSlotFunc ? selectSlotFunc() : "";
                    slotStr = typeof slotStr === "string" ? slotStr : "";
                    break;
                }
            }
            return slotStr;
        };
        ElementCellTypeBase.prototype.getPropertyByPath = function (target, pathes) {
            var result = target !== null && target !== void 0 ? target : {};
            for (var _i = 0, pathes_1 = pathes; _i < pathes_1.length; _i++) {
                var item = pathes_1[_i];
                var property = result[item];
                if (property !== undefined) {
                    result = property;
                }
                else {
                    return null;
                }
            }
            return result;
        };
        ElementCellTypeBase.prototype.isPlainObject = function (obj) {
            return Object.prototype.toString.call(obj) === "[object Object]";
        };
        ElementCellTypeBase.prototype.format = function (value) {
            var _a, _b;
            if ((_b = (_a = this.CellElement) === null || _a === void 0 ? void 0 : _a.StyleInfo) === null || _b === void 0 ? void 0 : _b.Formatter) {
                var formatedResult = Forguncy.FormatHelper.format(this.CellElement.StyleInfo.Formatter, value);
                return formatedResult.text;
            }
            return value === null || value === void 0 ? void 0 : value.toString();
        };
        return ElementCellTypeBase;
    }(Forguncy.Plugin.CellTypeBase));
    ElementCellTypes.ElementCellTypeBase = ElementCellTypeBase;
    var SlotPath;
    (function (SlotPath) {
        SlotPath["selectPrefix"] = "SelectSlots.Prefix";
        SlotPath["selectOption"] = "SelectSlots.Option";
        SlotPath["datePickerRangeSeparater"] = "DatePickerSlots.RangeSeparater";
        SlotPath["datePickerCell"] = "DatePickerSlots.Cell";
        SlotPath["cascaderNode"] = "CascaderSlots.Node";
        SlotPath["calendarCell"] = "CalendarSlots.Cell";
        SlotPath["calendarHeader"] = "CalendarSlots.Header";
        SlotPath["menuItemContent"] = "MenuItemSlots.Content";
        SlotPath["backTopContent"] = "BackTopSlots.Content";
        SlotPath["tableColumnContent"] = "TableColumnSlots.Content";
        SlotPath["treeNode"] = "TreeNodeSlots.Node";
    })(SlotPath = ElementCellTypes.SlotPath || (ElementCellTypes.SlotPath = {}));
    var InputCellTypeBase = /** @class */ (function (_super) {
        __extends(InputCellTypeBase, _super);
        function InputCellTypeBase() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        InputCellTypeBase.prototype.onPageLoaded = function (info) {
            var _this = this;
            var _a;
            this._inputTextCache = (_a = this.getValueFromElement()) === null || _a === void 0 ? void 0 : _a.toString();
            this.getContainer().keyup(function () {
                var _a, _b;
                if (_this._inputTextCache !== ((_a = _this.getValueFromElement()) === null || _a === void 0 ? void 0 : _a.toString())) {
                    _this.hideValidateTooltip();
                }
                _this._inputTextCache = (_b = _this.getValueFromElement()) === null || _b === void 0 ? void 0 : _b.toString();
            });
            this.setTabIndexToElement();
            _super.prototype.onPageLoaded.call(this, info);
        };
        InputCellTypeBase.prototype.setValueToElement = function (jElement, value) {
            var _a;
            _super.prototype.setValueToElement.call(this, jElement, value);
            this._inputTextCache = (_a = this.getValueFromElement()) === null || _a === void 0 ? void 0 : _a.toString();
        };
        InputCellTypeBase.prototype.setTabIndexToElement = function () {
            if (!this.cellType) {
                return;
            }
            if (this.shouldEnableTabIndex()) {
                var inputCellType = this.cellType;
                $('button, input, a, textarea', "#".concat(this.ID)).attr("tabindex", inputCellType.DisableTabOrder ? -1 : inputCellType.TabIndex);
            }
        };
        return InputCellTypeBase;
    }(ElementCellTypeBase));
    ElementCellTypes.InputCellTypeBase = InputCellTypeBase;
    var SupportDataSourceCellType = /** @class */ (function () {
        function SupportDataSourceCellType() {
        }
        SupportDataSourceCellType.refreshData = function (cellType, bindingDataSourceModel, callBack, options) {
            if (options === void 0) { options = null; }
            this.refreshDataWithOption(cellType, bindingDataSourceModel, callBack, options);
        };
        SupportDataSourceCellType.refreshDataWithOption = function (cellType, bindingDataSourceModel, callBack, options, watchOnDependenceChange, userAction) {
            if (watchOnDependenceChange === void 0) { watchOnDependenceChange = true; }
            if (userAction === void 0) { userAction = false; }
            cellType.getBindingDataSourceValue(bindingDataSourceModel, options, function (dataSource, userAction) {
                callBack(dataSource, userAction);
            }, true);
        };
        return SupportDataSourceCellType;
    }());
    ElementCellTypes.SupportDataSourceCellType = SupportDataSourceCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var AvatarShape;
    (function (AvatarShape) {
        AvatarShape[AvatarShape["circle"] = 0] = "circle";
        AvatarShape[AvatarShape["square"] = 1] = "square";
    })(AvatarShape || (AvatarShape = {}));
    // test webhook
    var AvatarFit;
    (function (AvatarFit) {
        AvatarFit[AvatarFit["fill"] = 0] = "fill";
        AvatarFit[AvatarFit["contain"] = 1] = "contain";
        AvatarFit[AvatarFit["cover"] = 2] = "cover";
        AvatarFit[AvatarFit["none"] = 3] = "none";
        AvatarFit[AvatarFit["scale-down"] = 4] = "scale-down";
    })(AvatarFit || (AvatarFit = {}));
    var AvatarCellType = /** @class */ (function (_super) {
        __extends(AvatarCellType, _super);
        function AvatarCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        AvatarCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var cellType = this.cellType;
            var self = this;
            this.addCustomClass("el-avatar-custom");
            if (cellType.shape === AvatarShape.circle) {
                this.addCustomClass("el-avatar-circle-custom");
            }
            var option = {
                template: "\n<el-badge :value=\"badge\" :hidden=\"!badge\">\n        <el-avatar\n            :src=\"src\"\n            :icon=\"icon\"            \n            :fit=\"fit\"\n            :text=\"text\"\n            :shape=\"shape\"\n            :size=\"size\">{{text}}\n        </el-avatar>\n    </el-badge>",
                data: function () {
                    return {
                        icon: "",
                        src: cellType.src,
                        fit: AvatarFit[cellType.fit],
                        shape: AvatarShape[cellType.shape],
                        size: null,
                        badge: undefined,
                        text: undefined,
                    };
                },
                mounted: function () {
                    this.size = Math.min(self.vueContainer.width(), self.vueContainer.height());
                    var hasCommandList = cellType.CommandList && cellType.CommandList.length;
                    var avatarElement = $(".el-avatar", self.vueContainer);
                    if (hasCommandList) {
                        avatarElement.css("cursor", "pointer");
                        avatarElement.click(function () { return (self.executeCommand(cellType.CommandList)); });
                    }
                    self.fontDom = $(".el-avatar", self.getContainer());
                    this.calculateSize();
                },
                methods: {
                    calculateSize: function () {
                        this.size = Math.min(self.vueContainer.width(), self.vueContainer.height());
                    },
                    getValue: function () {
                        return this.src;
                    },
                    setValue: function (value) {
                        if (!value) {
                            this.src = self._defaultSrc;
                            this.text = undefined;
                            return;
                        }
                        if (cellType.showSystemAvatar) {
                            this.src = Forguncy.Helper.SpecialPath.getBaseUrl() + "Account/UserImage?getDefault=false&userName=" + value;
                            this.text = value;
                            return;
                        }
                        if (value && ElementCellTypes.FileHelper.IsAttachment(value)) {
                            value = ElementCellTypes.FileHelper.GetUploadImageSrc(value);
                        }
                        else if (value) {
                            var lowCase = (value + "").toLowerCase();
                            if (lowCase.indexOf("http://") !== 0 && lowCase.indexOf("https://") !== 0) {
                                this.text = value;
                            }
                        }
                        this.src = value;
                    }
                }
            };
            this.createVueApp(option);
            this.onFormulaResultChanged(cellType.badge, function (value) {
                _this.vue.badge = _this.evaluateFormula(value);
            });
            this.getContainer().css("overflow", "");
            _super.prototype.onPageLoaded.call(this, info);
            _super.prototype.getIconComponent.call(this, cellType.icon, function (icon, result) {
                if (result.isSvg) {
                    self._defaultSrc = ElementCellTypes.getBase64FromSvgElement(result.icon);
                }
                else {
                    self._defaultSrc = result.icon;
                }
                if (_this.isEmpty(_this.vue.src)) {
                    _this.vue.src = self._defaultSrc;
                }
            });
        };
        AvatarCellType.prototype.onWindowResized = function () {
            var _a;
            (_a = this.vue) === null || _a === void 0 ? void 0 : _a.calculateSize();
        };
        AvatarCellType.prototype.clickable = function () {
            var cellType = this.CellElement.CellType;
            return cellType.CommandList && cellType.CommandList.length > 0;
        };
        return AvatarCellType;
    }(ElementCellTypes.ElementCellTypeBase));
    ElementCellTypes.AvatarCellType = AvatarCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.AvatarCellType, ElementUI", ElementCellTypes.AvatarCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var BackupTopCellType = /** @class */ (function (_super) {
        __extends(BackupTopCellType, _super);
        function BackupTopCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        BackupTopCellType.prototype.onPageLoaded = function (info) {
            var cellType = this.cellType;
            this.containerId = "".concat(this.uId, "-el-backuptop");
            var initData = {};
            // do nothing
            Object.assign(initData, {
                style: '',
                right: cellType.Right,
                bottom: cellType.Bottom
            });
            var contentSlot = this.getCustomSlotByPath(ElementCellTypes.SlotPath.backTopContent);
            var findHasScrollBarDom = function (el) {
                try {
                    if (!el) {
                        return null;
                    }
                    var overflowY = el.css("overflow-y");
                    if (overflowY === "auto" || overflowY === "scroll") {
                        if (el[0].scrollHeight > el[0].offsetHeight) {
                            return el;
                        }
                    }
                    var parent_1 = el === null || el === void 0 ? void 0 : el.parent();
                    return parent_1 ? findHasScrollBarDom(parent_1) : null;
                }
                catch (_a) {
                    return null;
                }
            };
            var targetTemplate;
            var el = findHasScrollBarDom(this.vueContainer);
            if (el === null || el === void 0 ? void 0 : el.length) {
                if (!el.attr("id")) {
                    el.attr("id", ElementCellTypes.ElementCellTypeBase.generateID("fgc-el-backupTop-random-id"));
                }
                targetTemplate = "target=\"#".concat(el.attr("id"), "\"");
            }
            var option = {
                el: "#".concat(this.uId),
                template: "\n<el-backtop id=\"".concat(this.containerId, "\" :style=\"style\" :visibilityHeight=\"visibilityHeight\" :right=\"right\" :bottom=\"bottom\" ").concat(targetTemplate, " >\n    ").concat(contentSlot || (info === null || info === void 0 ? void 0 : info.value) || "", "\n</el-backtop>"),
                data: function () {
                    return Object.assign({
                        visibilityHeight: cellType.VisibilityHeight,
                    }, initData);
                },
            };
            this.createVueApp(option);
            _super.prototype.onPageLoaded.call(this, info);
        };
        return BackupTopCellType;
    }(ElementCellTypes.ElementCellTypeBase));
    ElementCellTypes.BackupTopCellType = BackupTopCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.BackupTopCellType, ElementUI", ElementCellTypes.BackupTopCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var BreadcrumbCellType = /** @class */ (function (_super) {
        __extends(BreadcrumbCellType, _super);
        function BreadcrumbCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        BreadcrumbCellType.prototype.onPageLoaded = function (info) {
            var cellType = this.cellType;
            var self = this;
            var option = {
                el: "#" + this.uId,
                template: "<el-breadcrumb :separator=\"separator\">\n<template v-for=\"(path,index) in paths\">\n  <el-breadcrumb-item><a :href=\"path.href\" @click=\"ItemClick(path,index)\">{{path.pageName}}</a></el-breadcrumb-item>\n</template>\n</el-breadcrumb>",
                data: function () {
                    return {
                        paths: [],
                        pageName: undefined,
                        separator: cellType.separator
                    };
                },
                methods: {
                    ItemClick: function (node, index) {
                        var _a, _b;
                        if (index !== this.paths.length - 1 && ((_b = (_a = cellType.ClickCommand) === null || _a === void 0 ? void 0 : _a.Commands) === null || _b === void 0 ? void 0 : _b.length)) {
                            var initValue = {};
                            initValue[cellType.ClickCommand.ParamProperties["pageName"]] = node.pageName;
                            self.executeCustomCommandObject(cellType.ClickCommand, initValue);
                        }
                        event.preventDefault();
                    },
                    getValue: function () {
                        return this.pageName;
                    },
                    setValue: function (value) {
                        if (value instanceof Array) {
                            value = value.join(cellType.separator);
                        }
                        this.pageName = value === null || value === void 0 ? void 0 : value.toString();
                        this.initPath();
                    },
                    initPath: function () {
                        var _this = this;
                        if (this.pageName) {
                            var pathStrs = this.pageName.split(cellType.separator).filter(function (i) { return i; });
                            var baseUrl_1 = Forguncy.Helper.SpecialPath.getBaseUrl();
                            this.paths = pathStrs.map(function (i) { return ({
                                pageName: i,
                                href: baseUrl_1 + i
                            }); });
                            this.$nextTick(function (_) {
                                var container = $(_this.$el);
                                self.fontDom = $("a,span", container);
                                self.setFontToDom();
                            });
                        }
                        else {
                            this.paths = [];
                        }
                    }
                }
            };
            this.createVueApp(option);
            _super.prototype.onPageLoaded.call(this, info);
        };
        return BreadcrumbCellType;
    }(ElementCellTypes.ElementCellTypeBase));
    ElementCellTypes.BreadcrumbCellType = BreadcrumbCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.BreadcrumbCellType, ElementUI", ElementCellTypes.BreadcrumbCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var CalendarCellType = /** @class */ (function (_super) {
        __extends(CalendarCellType, _super);
        function CalendarCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        CalendarCellType.prototype.clearTimer = function () {
            clearTimeout(this._timer);
        };
        CalendarCellType.prototype.resetTimer = function (fn) {
            clearTimeout(this._timer);
            this._timer = setTimeout(fn, 300);
        };
        CalendarCellType.prototype.onWindowResized = function () {
            var _a;
            (_a = this.vue) === null || _a === void 0 ? void 0 : _a.calculateHeight();
        };
        CalendarCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var dateCellStr = this.getCustomSlotByPath(ElementCellTypes.SlotPath.calendarCell);
            var calendarHeaderStr = this.getCustomSlotByPath(ElementCellTypes.SlotPath.calendarHeader);
            var self = this;
            var cellType = this.cellType;
            this.addCustomClass("el-calendar-custom");
            var template = "\n            <el-calendar v-model=\"value\">\n                <template #dateCell=\"{ data }\">\n                     ".concat(dateCellStr || self.getDefaultDateCellSlot(), "\n                </template>\n                ").concat(calendarHeaderStr ? "<template #header='data'>" + calendarHeaderStr + "</template>" : "", "\n            </el-calendar>\n");
            var option = {
                template: template,
                data: function () {
                    return {
                        value: null,
                        options: [],
                        scheduleMap: {},
                        insufficientHeight: false,
                        firstDayOfWeek: cellType.firstDayOfWeek,
                        calendarContainerStyle: null,
                    };
                },
                mounted: function () {
                    this.calculateHeight();
                },
                created: function () {
                    ElementUtils.Dayjs.toggleLocale({ weekStart: cellType.firstDayOfWeek });
                },
                methods: {
                    calculateHeight: function () {
                        var tbodyHeight = $(".el-calendar", $(self.getContainer())).height() - 120;
                        var rowCount = $(".el-calendar-table tbody tr", $(self.getContainer())).length;
                        // 18： 上下间距均为8，加上border 1px
                        var height = Math.floor(tbodyHeight / rowCount) - 18;
                        if (height <= 0) {
                            return;
                        }
                        if (height <= 30) {
                            this.insufficientHeight = true;
                        }
                        this.calendarContainerStyle = "height:".concat(height, "px;padding: 8px;");
                    },
                    getValue: function () {
                        if (this.value !== null) {
                            var newDate = new Date(this.value.getTime());
                            newDate.setHours(0);
                            newDate.setMinutes(0);
                            newDate.setSeconds(0);
                            newDate.setMilliseconds(0);
                            return Forguncy.ConvertDateToOADate(newDate);
                        }
                        return null;
                    },
                    setValue: function (value) {
                        self.cacheOldValue = value ? Forguncy.ConvertOADateToDate(value) : null;
                        this.value = self.cacheOldValue;
                    },
                    formatDay: function (value) {
                        return value.split('-')[2];
                    },
                    getScheduleMapKeyByDate: function (date) {
                        return date === null || date === void 0 ? void 0 : date.toLocaleDateString();
                    },
                    clearScheduleMap: function () {
                        this.scheduleMap = {};
                    },
                    fillScheduleMap: function () {
                        var _this = this;
                        this.options.forEach(function (option) {
                            var isOADate = !isNaN(Number(option.date));
                            var date = isOADate ?
                                Forguncy.ConvertOADateToDate(option.date) :
                                new Date(option.date);
                            var key = _this.getScheduleMapKeyByDate(date);
                            if (_this.scheduleMap[key]) {
                                _this.scheduleMap[key].push(option);
                            }
                            else {
                                _this.scheduleMap[key] = [option];
                            }
                        });
                    },
                    getOptionsByDay: function (dateCell) {
                        var key = this.getScheduleMapKeyByDate(dateCell.date);
                        return (this.scheduleMap[key] || []);
                    },
                    handleDoubleClick: function (data) {
                        var _a;
                        var command = cellType.DBClickCommand;
                        if (!command) {
                            return;
                        }
                        self.executeCustomCommandObject(command, (_a = {},
                            _a[command.ParamProperties["date"]] = data.date,
                            _a), "doubleClick");
                    },
                    scheduleOnClickOrDBClick: function (type, option) {
                        var _a;
                        var command = type === "click" ? cellType.ScheduleClickCommand : cellType.ScheduleDBClickCommand;
                        if (!command) {
                            return;
                        }
                        var ParamProperties = command.ParamProperties;
                        var initParam = (_a = {},
                            _a[ParamProperties["value"]] = option.value,
                            _a[ParamProperties["text"]] = option.text,
                            _a[ParamProperties["date"]] = option.date,
                            _a);
                        self.executeCustomCommandObject(command, initParam, "schedule" + type);
                    },
                    scheduleOnClick: function (option) {
                        var _this = this;
                        self.resetTimer(function () { return _this.scheduleOnClickOrDBClick("click", option); });
                    },
                    scheduleOnDoubleClick: function (event, option) {
                        self.clearTimer();
                        if (cellType.DBClickCommand) {
                            event.stopPropagation();
                        }
                        this.scheduleOnClickOrDBClick("dbclick", option);
                    }
                },
                watch: {
                    value: function (newValue, oldValue) {
                        var _a;
                        if (((_a = self.cacheOldValue) === null || _a === void 0 ? void 0 : _a.getTime()) !== (newValue === null || newValue === void 0 ? void 0 : newValue.getTime())) {
                            self.commitValue();
                        }
                        var newDate = new Date(newValue === null || newValue === void 0 ? void 0 : newValue.getTime());
                        var oldDate = new Date(oldValue === null || oldValue === void 0 ? void 0 : oldValue.getTime());
                        if (newDate.getFullYear() !== oldDate.getFullYear() || newDate.getMonth() !== oldDate.getMonth()) {
                            this.$nextTick(this.calculateHeight);
                        }
                    },
                    options: function (newValue, oldValue) {
                        this.clearScheduleMap();
                        this.fillScheduleMap();
                    }
                }
            };
            this.createVueApp(option);
            ElementCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (dataSource) {
                _this.vue.options = dataSource;
            });
            _super.prototype.onPageLoaded.call(this, info);
        };
        CalendarCellType.prototype.reload = function () {
            var _this = this;
            var cellType = this.cellType;
            ElementCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (dataSource) {
                _this.vue.options = dataSource;
            });
        };
        CalendarCellType.prototype.getDefaultDateCellSlot = function () {
            return "\n            <div class=\"calendar-container\" :style=\"calendarContainerStyle\" v-if=\"calendarContainerStyle\" @dblclick=\"handleDoubleClick(data)\">\n                <div class=\"calendar-date-container\">\n                    <div>{{ formatDay(data.day)}}</div>\n                    <div>\n                        <div class=\"fgc-calendar-ellipsis\" v-if=\"insufficientHeight && getOptionsByDay(data).length\"/>\n                    </div>\n                </div>\n                <div class=\"calendar-schedule-container\" v-if=\"!insufficientHeight\">\n                    <el-scrollbar>\n                        <div class=\"calendar-schedule-item\" v-for=\"option in getOptionsByDay(data)\" \n                            @click=\"scheduleOnClick(option)\" @dblclick=\"scheduleOnDoubleClick($event,option)\">\n                            <div :title=\"option.text\" class=\"calendar-schedule-item-text\">{{option.text}}</div>\n                        </div>\n                    </el-scrollbar>\n                </div>\n            </div>";
        };
        return CalendarCellType;
    }(ElementCellTypes.ElementCellTypeBase));
    ElementCellTypes.CalendarCellType = CalendarCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.CalendarCellType, ElementUI", ElementCellTypes.CalendarCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var ExpendTrigger;
    (function (ExpendTrigger) {
        ExpendTrigger[ExpendTrigger["Click"] = 0] = "Click";
        ExpendTrigger[ExpendTrigger["Hover"] = 1] = "Hover";
    })(ExpendTrigger || (ExpendTrigger = {}));
    var CascaderCellType = /** @class */ (function (_super) {
        __extends(CascaderCellType, _super);
        function CascaderCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        CascaderCellType.prototype.setDataSource = function (dataSource) {
            return this.vue.setOptions(dataSource);
        };
        CascaderCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var nodeStr = this.getCustomSlotByPath(ElementCellTypes.SlotPath.cascaderNode);
            var self = this;
            var cellType = this.cellType;
            var options = [];
            if (!cellType.useBinding && cellType.options) {
                options = cellType.options;
            }
            this.addCustomClass("el-cascader-custom");
            var emitPath = cellType.emitPath && !cellType.multiple;
            var valueIsArrayStructure = emitPath || cellType.multiple;
            var CssClassName = this.CellElement.CssClassName;
            var popperClass = CssClassName ? "".concat(CssClassName, "-popper") : "";
            var option = {
                template: "\n<el-cascader\nv-model=\"value\"\n:options=\"options\"\n:props=\"props\"\n:placeholder=\"placeholder\"\n:disabled = \"disabled\"\n:clearable= \"clearable\"\n:show-all-levels = \"showAllLevels\"\n:collapse-tags = \"collapseTags\"\n:separator = \"separator\"\n:filterable = \"filterable\"\n:tag-type=\"tagType\"\npopper-class=\"".concat(popperClass, "\"\nref=\"elInput\"\n@change=\"handleChange\"\n@blur=\"handleBlur\"\n>\n    ").concat(nodeStr ? "<template #default='{ node, data }'>" + nodeStr + "</template>" : "", "\n</el-cascader>\n"),
                data: function () {
                    return {
                        disabled: cellType.IsDisabled,
                        value: null,
                        props: {
                            expandTrigger: cellType.expandTrigger === ExpendTrigger.Click ? "click" : "hover",
                            multiple: cellType.multiple,
                            emitPath: !!emitPath,
                            checkStrictly: cellType.checkStrictly
                        },
                        options: options,
                        tagType: cellType.tagType,
                        placeholder: undefined,
                        clearable: cellType.clearable,
                        showAllLevels: cellType.showAllLevels ? true : false,
                        collapseTags: cellType.collapseTags,
                        separator: undefined,
                        filterable: cellType.filterable
                    };
                },
                methods: {
                    handleChange: function () {
                        self.commitValue();
                        self.validate();
                    },
                    handleBlur: function () {
                        self.validate();
                    },
                    getValue: function () {
                        var value = this.value;
                        if (value instanceof Array) {
                            return value.join(",");
                        }
                        return value;
                    },
                    setValue: function (value) {
                        var _a, _b;
                        if (self.isEmpty(value)) {
                            this.value = null;
                            return;
                        }
                        if (valueIsArrayStructure) {
                            var values_1 = [];
                            var stringValues_1 = value.toString().split(",");
                            if (cellType.multiple) {
                                var flatOptions = ElementCellTypes.TreeHelper.flat(this.options);
                                var options_1 = flatOptions.filter(function (o) { var _a; return stringValues_1.includes((_a = o.value) === null || _a === void 0 ? void 0 : _a.toString()); });
                                values_1 = options_1.map(function (o) { return o.value; });
                            }
                            else {
                                stringValues_1.reduce(function (options, cur) {
                                    if (!Array.isArray(options) || !options.length) {
                                        return [];
                                    }
                                    // 此处比较需要忽略类型，使用双等号
                                    // eslint-disable-next-line
                                    var item = options.find(function (item) { return item.value == cur; });
                                    if (!item) {
                                        return [];
                                    }
                                    values_1.push(item.value);
                                    return item.children;
                                }, this.options);
                            }
                            this.value = values_1;
                        }
                        else {
                            var flatOptions = ElementCellTypes.TreeHelper.flat(this.options);
                            // 这里认为字符串数字与数字等价，双等号不能去掉
                            // eslint-disable-next-line
                            var option_1 = flatOptions.find(function (o) { return o.value == value; });
                            this.value = (_b = (_a = option_1 === null || option_1 === void 0 ? void 0 : option_1.value) !== null && _a !== void 0 ? _a : value) !== null && _b !== void 0 ? _b : null;
                        }
                    },
                    disable: function () {
                        this.disabled = true;
                    },
                    enable: function () {
                        this.disabled = false;
                    },
                    setOptions: function (options) {
                        if (options) {
                            ElementCellTypes.TreeHelper.flat(options).forEach(function (i) {
                                if (i === null || i === void 0 ? void 0 : i.label) {
                                    i.label = self.format(i.label);
                                }
                            });
                            this.options = options;
                        }
                        else {
                            this.options = [];
                        }
                    }
                },
                mounted: function () {
                    self.fontDom = $("input", "#".concat(self.uId));
                    self.setFontToDom();
                }
            };
            this.createVueApp(option);
            self.ReloadBindingItems();
            this.onFormulaResultChanged(cellType.placeholder, function (value) {
                var _a;
                _this.vue.placeholder = (_a = value === null || value === void 0 ? void 0 : value.toString()) !== null && _a !== void 0 ? _a : " ";
            });
            this.onFormulaResultChanged(cellType.separator, function (value) {
                _this.vue.separator = value === null || value === void 0 ? void 0 : value.toString();
            });
            _super.prototype.onPageLoaded.call(this, info);
        };
        CascaderCellType.prototype.ReloadBindingItems = function () {
            var _this = this;
            var cellType = this.cellType;
            if (cellType.useBinding) {
                ElementCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (data) { return _this.setDataSource(ElementCellTypes.TreeHelper.build(data)); });
            }
        };
        CascaderCellType.prototype.reload = function () {
            this.ReloadBindingItems();
        };
        CascaderCellType.prototype.SetDataSourceByObjTree = function (dataSource, valueProperty, labelProperty, childrenProperty) {
            if (typeof dataSource === "string") {
                dataSource = JSON.parse(dataSource);
            }
            if (childrenProperty) {
                childrenProperty = childrenProperty.split('|');
            }
            if (valueProperty) {
                valueProperty = valueProperty.split('|');
            }
            labelProperty = labelProperty ? labelProperty.split('|') : valueProperty;
            var source = this.buildTree(dataSource, valueProperty, labelProperty, childrenProperty);
            this.setDataSource(source);
        };
        CascaderCellType.prototype.buildTree = function (dataSource, valueProperty, labelProperty, childrenProperty) {
            var _this = this;
            if (!dataSource) {
                return undefined;
            }
            return dataSource.map(function (i) { return ({
                value: _this.getSubPropertyValue(i, valueProperty),
                label: _this.getSubPropertyValue(i, labelProperty),
                children: _this.buildTree(_this.getSubPropertyValue(i, childrenProperty), valueProperty, labelProperty, childrenProperty),
            }); });
        };
        CascaderCellType.prototype.getSubPropertyValue = function (obj, subProperties) {
            for (var _i = 0, subProperties_1 = subProperties; _i < subProperties_1.length; _i++) {
                var prop = subProperties_1[_i];
                if (obj[prop] !== undefined) {
                    return obj[prop];
                }
            }
            return undefined;
        };
        CascaderCellType.prototype.SetDataSourceByIdPidTable = function (dataSource, valueProperty, labelProperty, parentValue) {
            if (typeof dataSource === "string") {
                dataSource = JSON.parse(dataSource);
            }
            var treeObj = ElementCellTypes.TreeHelper.build(dataSource.map(function (i) { return (__assign(__assign({}, i), { value: i[valueProperty], label: i[labelProperty], parentValue: i[parentValue] })); }));
            this.setDataSource(treeObj);
        };
        CascaderCellType.prototype.GetCheckedNodes = function (leafOnly) {
            if (typeof (leafOnly) === "string") {
                leafOnly = !(leafOnly.toLowerCase() === "false" || leafOnly.toLowerCase() === "0");
            }
            else {
                leafOnly = !!leafOnly;
            }
            return {
                CheckedItems: this.vue.$refs.elInput.getCheckedNodes(leafOnly).map(function (i) { return ({
                    "value": i.value,
                    "label": i.label,
                }); })
            };
        };
        return CascaderCellType;
    }(ElementCellTypes.InputCellTypeBase));
    ElementCellTypes.CascaderCellType = CascaderCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.CascaderCellType, ElementUI", ElementCellTypes.CascaderCellType);
var ElementCellTypes;
(function (ElementCellTypes) {
    var FileHelper = /** @class */ (function () {
        function FileHelper() {
        }
        FileHelper.IsAttachment = function (str) {
            return /^[0-9a-f]{8}-?[0-9a-f]{4}-?[1-5][0-9a-f]{3}-?[89ab][0-9a-f]{3}-?[0-9a-f]{12}_.+$/i.test(str);
        };
        FileHelper.GetUploadImageSrc = function (str) {
            return Forguncy.Helper.SpecialPath.getBaseUrl() + "Upload/" + str;
        };
        return FileHelper;
    }());
    ElementCellTypes.FileHelper = FileHelper;
})(ElementCellTypes || (ElementCellTypes = {}));
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var DatePickerCellType = /** @class */ (function (_super) {
        __extends(DatePickerCellType, _super);
        function DatePickerCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        DatePickerCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var separaterStr = this.getCustomSlotByPath(ElementCellTypes.SlotPath.datePickerRangeSeparater);
            var cellStr = this.getCustomSlotByPath(ElementCellTypes.SlotPath.datePickerCell);
            var self = this;
            this.addCustomClass("el-date-picker-custom");
            var cellType = this.cellType;
            var rangeTemplate = "\n:is-range=\"true\"\n:start-placeholder=\"startPlaceholder\"\n:end-placeholder=\"endPlaceholder\"\n";
            var isRange = cellType.type.indexOf("range") !== -1;
            var CssClassName = this.CellElement.CssClassName;
            var popperClass = CssClassName ? "".concat(CssClassName, "-popper") : "";
            var template = "\n<el-date-picker v-model=\"input\"\n:type=\"type\"\n:clearable=\"clearable\"\n:disabled=\"disabled\"\n:editable=\"editable\"\n:placeholder=\"placeholder\"\n:readonly=\"readOnly\"\n:format=\"format\"\n:prefix-icon=\"prefixIcon\"\npopper-class=\"".concat(popperClass, "\"\n:picker-options=\"pickerOptions\"\n").concat(cellType.type.indexOf("range") !== -1 ? rangeTemplate : "", "\n@change=\"handleChange\"\n@blur=\"handleBlur\"\n>\n    <template #range-separator v-if=\"type.indexOf('range') !== -1\">\n        {{rangeSeparator}}\n    </template>\n    <template #default=\"cell\">\n        ").concat(cellStr, "\n    </template>\n</el-date-picker>\n");
            var option = {
                template: template,
                data: function () {
                    return {
                        input: null,
                        type: cellType.type,
                        clearable: this.boolConvertor(cellType.clearable),
                        disabled: cellType.IsDisabled,
                        editable: this.boolConvertor(cellType.editable),
                        format: this.getformat(),
                        placeholder: undefined,
                        prefixIcon: "",
                        readOnly: undefined,
                        rangeSeparator: separaterStr,
                        startPlaceholder: undefined,
                        endPlaceholder: undefined,
                        pickerOptions: this.getPickerOptions()
                    };
                },
                methods: {
                    handleChange: function () {
                        self.commitValue();
                        self.validate();
                    },
                    handleBlur: function () {
                        self.validate();
                    },
                    getValue: function () {
                        if (!this.input) {
                            return null;
                        }
                        if (isRange) {
                            return this.input.map(function (item) { return Forguncy.ConvertDateToOADate(new Date(item.valueOf())); }).join(",");
                        }
                        return Forguncy.ConvertDateToOADate(this.input);
                    },
                    setValue: function (value) {
                        var covertValueToInput = function () {
                            if (!value) {
                                return null;
                            }
                            if (typeof value === "number") {
                                return Forguncy.ConvertOADateToDate(value);
                            }
                            if (typeof value === "string") {
                                if (isRange) {
                                    var callbackfn = function (item) { return ElementCellTypes.DateUtil.ConvertToDate(item); };
                                    return value.split(",").map(callbackfn);
                                }
                                var numerValue = Number(value);
                                return isNaN(numerValue) ?
                                    new Date(value) :
                                    Forguncy.ConvertOADateToDate(numerValue);
                            }
                            return value;
                        };
                        this.input = this.getLegalValue(covertValueToInput());
                    },
                    getLegalValue: function (value) {
                        var isInvalidDate = this.isInvalidDate;
                        if (!value) {
                            return null;
                        }
                        if (!isRange) {
                            return isInvalidDate(value) ? null : value;
                        }
                        if (!(value instanceof Array) || value.length !== 2) {
                            return [];
                        }
                        if (isInvalidDate(value[0]) || isInvalidDate(value[1])) {
                            return [];
                        }
                        return value;
                    },
                    disable: function () {
                        this.disabled = true;
                    },
                    enable: function () {
                        this.disabled = false;
                    },
                    setReadOnly: function (value) {
                        this.readOnly = value;
                    },
                    boolConvertor: function (value) {
                        return value ? true : false;
                    },
                    getPickerOptions: function () {
                        return {
                            firstDayOfWeek: cellType.firstDayOfWeek + 0
                        };
                    },
                    getformat: function () {
                        var _a, _b;
                        var format;
                        if (!((_b = (_a = cellType === null || cellType === void 0 ? void 0 : cellType.format) === null || _a === void 0 ? void 0 : _a.trim()) === null || _b === void 0 ? void 0 : _b.length) && cellType.type === "week") {
                            format = cellType.DefautWeekFormat;
                        }
                        else {
                            format = cellType.format;
                        }
                        return format === null || format === void 0 ? void 0 : format.replace("WW", "ww").replace("yyyy", "YYYY").replace("dd", "DD");
                    },
                    isInvalidDate: function (value) {
                        if (!(value instanceof Date)) {
                            return true;
                        }
                        return isNaN(value.getTime());
                    }
                },
                created: function () {
                    ElementUtils.Dayjs.toggleLocale({ weekStart: cellType.firstDayOfWeek });
                },
                mounted: function () {
                    self.fontDom = $('input', self.vueContainer)
                        .add(".el-date-editor", self.vueContainer);
                },
            };
            this.createVueApp(option);
            this.onFormulaResultChanged(cellType.placeholder, function (value) {
                _this.vue.placeholder = value === null || value === void 0 ? void 0 : value.toString();
            });
            this.onFormulaResultChanged(cellType.startPlaceholder, function (value) {
                _this.vue.startPlaceholder = value === null || value === void 0 ? void 0 : value.toString();
            });
            this.onFormulaResultChanged(cellType.endPlaceholder, function (value) {
                _this.vue.endPlaceholder = value === null || value === void 0 ? void 0 : value.toString();
            });
            if (!separaterStr) {
                this.onFormulaResultChanged(cellType.rangeSeparator, function (value) {
                    _this.vue.rangeSeparator = value === null || value === void 0 ? void 0 : value.toString();
                });
            }
            _super.prototype.onPageLoaded.call(this, info);
            _super.prototype.getIconComponent.call(this, cellType.prefixIcon, function (icon) { return _this.vue.prefixIcon = icon; });
        };
        DatePickerCellType.prototype.GetSelectedRange = function () {
            var value = this.vue.input;
            var _a = value || [], startDate = _a[0], endDate = _a[1];
            return {
                StartValue: startDate,
                EndValue: endDate,
            };
        };
        return DatePickerCellType;
    }(ElementCellTypes.InputCellTypeBase));
    ElementCellTypes.DatePickerCellType = DatePickerCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.DatePickerCellType, ElementUI", ElementCellTypes.DatePickerCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var InputCellType = /** @class */ (function (_super) {
        __extends(InputCellType, _super);
        function InputCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        InputCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var self = this;
            this.addCustomClass("el-input-custom");
            var cellType = this.cellType;
            var option = {
                template: "\n<el-input v-model=\"input\"\n:type=\"type\" :maxlength=\"maxlength\" :show-word-limit=\"showWordLimit\" :readonly=\"readonly\"\n:placeholder=\"placeholder\" :clearable=\"clearable\" :showPassword=\"showPassword\" :resize=\"resize\"\nref=\"elInput\"\n:disabled=\"disabled\" :suffixIcon=\"suffixIcon\" :prefixIcon=\"prefixIcon\"\n@blur=\"handleBlur\"\n@focus=\"handleFocus\"\n@change=\"handleChange\">\n</el-input>\n",
                data: function () {
                    return {
                        input: null,
                        type: cellType.type === "password" ? "text" : cellType.type,
                        maxlength: undefined,
                        showWordLimit: cellType.showWordLimit,
                        placeholder: undefined,
                        clearable: cellType.clearable,
                        showPassword: cellType.type === "password",
                        disabled: cellType.IsDisabled,
                        prefixIcon: "",
                        suffixIcon: "",
                        readonly: undefined,
                        resize: cellType.resize,
                    };
                },
                methods: {
                    handleBlur: function () {
                        self.validate();
                    },
                    handleFocus: function () {
                        if (self.cellType.IsSelectAllOnFocus) {
                            self.Select();
                        }
                    },
                    handleChange: function () {
                        self.commitValue();
                    },
                    getValue: function () {
                        return this.input;
                    },
                    setValue: function (value) {
                        this.input = value;
                    },
                    disable: function () {
                        this.disabled = true;
                    },
                    enable: function () {
                        this.disabled = false;
                    },
                    setReadOnly: function (value) {
                        this.readonly = value;
                    },
                },
                mounted: function () {
                    var _a, _b, _c;
                    var refs = (_b = (_a = this.$refs) === null || _a === void 0 ? void 0 : _a.elInput) === null || _b === void 0 ? void 0 : _b.$refs;
                    var input = (_c = refs === null || refs === void 0 ? void 0 : refs.input) !== null && _c !== void 0 ? _c : refs === null || refs === void 0 ? void 0 : refs.textarea;
                    if (input) {
                        var inputJqel = $(input);
                        self.fontDom = inputJqel;
                        if (cellType.type !== "textarea") {
                            Forguncy.FocusMoveHelper.AllowMoveFocusByEnterKey(inputJqel, false);
                        }
                        else {
                            inputJqel.css("height", self.getContainer().height() + "px");
                        }
                    }
                }
            };
            this.createVueApp(option);
            this.onFormulaResultChanged(cellType.maxlength, function (value) {
                _this.vue.maxlength = _this.getMaxLength(value);
            });
            this.onFormulaResultChanged(cellType.placeholder, function (value) {
                _this.vue.placeholder = value === null || value === void 0 ? void 0 : value.toString();
            });
            _super.prototype.onPageLoaded.call(this, info);
            _super.prototype.getIconComponent.call(this, cellType.prefixIcon, function (icon) { return _this.vue.prefixIcon = icon; });
            _super.prototype.getIconComponent.call(this, cellType.suffixIcon, function (icon) { return _this.vue.suffixIcon = icon; });
        };
        InputCellType.prototype.getMaxLength = function (value) {
            value = Number(value);
            if (isNaN(value) || value < 1) {
                return null;
            }
            return value;
        };
        InputCellType.prototype.setFocus = function () {
            this.Focus();
        };
        InputCellType.prototype.hasFocus = function () {
            var dom = $(this.vue.$refs.elInput.input);
            return dom.length && document.activeElement === dom[0];
        };
        InputCellType.prototype.Focus = function () {
            this.vue.$refs.elInput.focus();
        };
        InputCellType.prototype.Select = function () {
            this.vue.$refs.elInput.select();
        };
        return InputCellType;
    }(ElementCellTypes.InputCellTypeBase));
    ElementCellTypes.InputCellType = InputCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.InputCellType, ElementUI", ElementCellTypes.InputCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var InputNumberCellType = /** @class */ (function (_super) {
        __extends(InputNumberCellType, _super);
        function InputNumberCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        InputNumberCellType.prototype.setValueToElement = function (jelement, value) {
            var _a;
            if (value === null) {
                return (_a = this.vue) === null || _a === void 0 ? void 0 : _a.setValue(undefined);
            }
            return _super.prototype.setValueToElement.call(this, jelement, value);
        };
        InputNumberCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var self = this;
            var cellType = this.cellType;
            this.addCustomClass("el-input-number-custom");
            if (cellType.controlsPosition) {
                this.addCustomClass("el-input-number-custom-right");
            }
            var option = {
                template: "\n<el-input-number v-model=\"input\"\n :min=\"min\" :max=\"max\" :step=\"step\" :step-strictly=\"stepStrictly\" :precision=\"precision\" :disabled=\"disabled\"\n:controls-position=\"controlsPosition\" :placeholder=\"placeholder\" :controls=\"controls\"\n@blur=\"blurHandler\"\n@focus=\"focusHandler\"\n@change=\"changedHandler\"\nref=\"elInput\"\n>\n</el-input-number>\n",
                data: function () {
                    return {
                        input: undefined,
                        min: undefined,
                        max: undefined,
                        step: undefined,
                        stepStrictly: cellType.stepStrictly,
                        precision: cellType.precision,
                        disabled: cellType.IsDisabled,
                        controlsPosition: cellType.controlsPosition === true ? "right" : "",
                        placeholder: undefined,
                        controls: cellType.controls ? true : false,
                    };
                },
                methods: {
                    getValue: function () {
                        return this.input;
                    },
                    setValue: function (value) {
                        if (value !== null && value !== undefined && value !== "") {
                            this.input = Number(value);
                        }
                        else {
                            this.input = undefined;
                        }
                        if (self.isEmpty(self.inputValue)) {
                            self.inputValue = this.input;
                        }
                    },
                    disable: function () {
                        this.disabled = true;
                    },
                    enable: function () {
                        this.disabled = false;
                    },
                    blurHandler: function () {
                        self.validate();
                        if (this.input === null) {
                            self.commitValue();
                        }
                    },
                    focusHandler: function () {
                        if (self.cellType.IsSelectAllOnFocus) {
                            $("input", self.vueContainer).select();
                        }
                    },
                    changedHandler: function () {
                        if (!this.stepStrictly) {
                            self.commitValue();
                            return;
                        }
                        // 这只能用双等，不要用三等
                        if (window.BigNumber(this.input).mod(window.BigNumber(this.step)) == 0) {
                            self.commitValue();
                        }
                    }
                },
                mounted: function () {
                    var _this = this;
                    var inputJqel = $("input", self.vueContainer);
                    self.fontDom = inputJqel;
                    inputJqel.on("input", function () {
                        self.inputValue = inputJqel.val();
                    });
                    inputJqel.on("blur", function () {
                        if (self.inputValue === "") {
                            _this.input = undefined;
                        }
                    });
                    Forguncy.FocusMoveHelper.AllowMoveFocusByEnterKey(inputJqel, false);
                },
            };
            this.createVueApp(option);
            this.onFormulaResultChanged(cellType.min, function (value) {
                _this.vue.min = _this.toNumber(value);
            });
            this.onFormulaResultChanged(cellType.max, function (value) {
                _this.vue.max = _this.toNumber(value);
            });
            this.onFormulaResultChanged(cellType.step, function (value) {
                _this.vue.step = _this.toNumber(value);
            });
            this.onFormulaResultChanged(cellType.placeholder, function (value) {
                _this.vue.placeholder = value === null || value === void 0 ? void 0 : value.toString();
            });
            _super.prototype.onPageLoaded.call(this, info);
        };
        InputNumberCellType.prototype.SetMinValue = function (value) {
            this.vue.min = this.toNumber(value);
        };
        InputNumberCellType.prototype.SetMaxValue = function (value) {
            this.vue.max = this.toNumber(value);
        };
        InputNumberCellType.prototype.SetStep = function (value) {
            this.vue.step = this.toNumber(value);
        };
        InputNumberCellType.prototype.Focus = function () {
            this.vue.$refs.elInput.focus();
        };
        InputNumberCellType.prototype.setFocus = function () {
            this.Focus();
        };
        InputNumberCellType.prototype.hasFocus = function () {
            var dom = $(this.vue.$refs.elInput.input);
            return dom.length && document.activeElement === dom[0];
        };
        return InputNumberCellType;
    }(ElementCellTypes.InputCellTypeBase));
    ElementCellTypes.InputNumberCellType = InputNumberCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.InputNumberCellType, ElementUI", ElementCellTypes.InputNumberCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var Page = Forguncy.Page;
    var scrollTopData = {};
    var NavMenuCellType = /** @class */ (function (_super) {
        __extends(NavMenuCellType, _super);
        function NavMenuCellType() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this._badgeDic = {};
            _this._pageName = _this.IsInMasterPage ? Page.getMasterPageName() : Page.getPageName();
            _this._scrollBarDataKey = "".concat(_this._pageName, "_").concat(_this.ID);
            _this._firstRender = true;
            return _this;
        }
        NavMenuCellType.prototype.setDataSource = function (dataSource) {
            return this.vue.setOptions(dataSource);
        };
        NavMenuCellType.prototype.generateIndex = function (options, parentIndex) {
            var _this = this;
            if (parentIndex === void 0) { parentIndex = null; }
            return options.map(function (option, index) {
                var _a;
                var key = parentIndex !== null ? "".concat(parentIndex, "-").concat(index) : index.toString();
                if ((_a = option === null || option === void 0 ? void 0 : option.children) === null || _a === void 0 ? void 0 : _a.length) {
                    option.children = _this.generateIndex(option.children, key);
                }
                return __assign(__assign({}, option), { index: key });
            });
        };
        NavMenuCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            this.addCustomClass("el-menu-custom");
            var self = this;
            var cellType = this.cellType;
            var CssClassName = this.CellElement.CssClassName;
            var options = [];
            var flatOptions = [];
            var openeds = new Set();
            var defaultOpeneds = [];
            var isVertical = cellType.mode === "vertical";
            if (!cellType.useBinding && cellType.options) {
                var permission = this.getUIPermission(1 /* Forguncy.Plugin.UIPermissionScope.Visible */);
                options = this.filterOptionsByPermission(cellType.options, permission === null || permission === void 0 ? void 0 : permission.Children);
                options = this.generateIndex(options);
                flatOptions = ElementCellTypes.TreeHelper.flat(options);
                if (isVertical) {
                    defaultOpeneds = this.getDefaultOpeneds(cellType.options);
                    defaultOpeneds.forEach(function (index) { return openeds.add(index); });
                }
            }
            this.addCustomClass(cellType.mode + "-menu");
            if (cellType.HideBorder) {
                this.addCustomClass("fgc-el-menu-hide-border");
            }
            var intervalTimer = null;
            var timeoutTimer = null;
            var clearTimers = function () {
                clearInterval(intervalTimer);
                clearInterval(timeoutTimer);
            };
            var subMenuPopperClass = CssClassName ? "".concat(CssClassName, "-popper") : "";
            var contentStr = this.getCustomSlotByPath(ElementCellTypes.SlotPath.menuItemContent);
            var menuItemOption = {
                name: "menu-item",
                template: "\n                    <el-menu-item :index=\"item.index\" :key=\"item.value\">\n                        ".concat(contentStr || self.getDefaultMenuItemSlot(), "\n                    </el-menu-item>\n                "),
                props: {
                    item: Object,
                },
            };
            var subMenuOption = {
                name: "sub-menu",
                template: "\n                    <el-sub-menu :index=\"item.index\" :key=\"item.value\" popper-class=\"".concat(subMenuPopperClass, "\" @click.stop=\"handleClick(item.index)\">\n                        <template #title>\n                           <el-icon  v-if=\"item.svgIcon\" v-html=\"item.svgIcon\" />\n                           <el-image v-if=\"item.iconSrc\" class=\"el-icon\" fit=\"contain\" :src=\"item.iconSrc\" />\n                           <span class=\"fgc-el-menu-transparent\">{{item.label}}</span>\n                           <el-badge :value=\"item.notice\" class=\"fgc-menu-badge-item\" />\n                        </template>\n                    \n                        <template v-for=\"subItem in item.children\">\n                            <template v-if=\"subItem.display != false\">\n                                <sub-menu  v-if=\"subItem && subItem.children && subItem.children.length\" :item=\"subItem\"  @click.stop=\"handleClick(subItem.index)\"/>\n                                <menu-item v-else :item=\"subItem\"/>\n                            </template>\n                        </template>\n                    \n                    </el-sub-menu>\n                "),
                props: {
                    item: Object
                },
                components: {
                    "menu-item": menuItemOption,
                },
                methods: {
                    handleClick: function (index) {
                        this.$emit("handleClick", index);
                    }
                }
            };
            var option = {
                template: "\n<el-scrollbar>\n    <el-menu\n        v-if=\"options.length\"\n        ref=\"menu\"\n        :mode=\"mode\"\n        :background-color=\"backgroundColor\"\n        :text-color=\"textColor\"\n        :active-text-color=\"activeTextColor\"\n        :default-openeds=\"defaultOpeneds\"\n        :default-active=\"defaultActive\"\n        :unique-opened=\"uniqueOpened\"\n        :collapse=\"collapse\"\n        :collapse-transition=\"collapseTransition\"\n        :menu-trigger=\"menuTrigger\"\n        :ellipsis=\"false\"\n        @select=\"handleSelect\"\n        @open=\"handleOpen\"\n        @close=\"handleClose\"\n    >\n        <template v-for=\"item in options\" >\n            <template v-if=\"item.display != false\">\n                <sub-menu v-if=\"item && item.children && item.children.length\" :item=\"item\" @handleClick=\"handleClick\" />\n                <menu-item v-else :item=\"item\"/>\n            </template>\n        </template>\n    </el-menu>\n</el-scrollbar>\n",
                components: {
                    "sub-menu": subMenuOption,
                    "menu-item": menuItemOption,
                },
                data: function () {
                    var _a;
                    return {
                        defaultActive: null,
                        selectedValue: null,
                        selectedKey: null,
                        options: options,
                        hideOptionValues: new Set(),
                        mode: cellType.mode,
                        collapse: isVertical && !!cellType.collapse,
                        uniqueOpened: cellType.uniqueOpened,
                        menuTrigger: cellType.menuTrigger,
                        collapseTransition: !!cellType.collapseTransition,
                        backgroundColor: (_a = Forguncy.ConvertToCssColor(cellType.backgroundColor)) !== null && _a !== void 0 ? _a : "transparent",
                        textColor: Forguncy.ConvertToCssColor(cellType.textColor),
                        activeTextColor: Forguncy.ConvertToCssColor(cellType.activeTextColor),
                        defaultOpeneds: defaultOpeneds,
                        openeds: openeds,
                        flatOptions: flatOptions
                    };
                },
                mounted: function () {
                    this.elMenuOnRendered();
                },
                watch: {
                    options: {
                        deep: true,
                        handler: function () {
                            this.flatOptions = ElementCellTypes.TreeHelper.flat(this.options);
                        }
                    },
                    hideOptionValues: {
                        deep: true,
                        handler: function () {
                            this.updateShownOrHiddenItems(this.options);
                        }
                    }
                },
                methods: {
                    enableAnimation: function () {
                        document.documentElement.style.setProperty('--el-transition-duration', "0.3s");
                    },
                    disableAnimation: function () {
                        document.documentElement.style.setProperty('--el-transition-duration', "0s");
                    },
                    updateShownOrHiddenItems: function (options) {
                        var _a, _b;
                        for (var i = 0; i < this.options.length; i++) {
                            var option_2 = options[i];
                            if (!option_2) {
                                continue;
                            }
                            if (this.hideOptionValues.has((_a = option_2.value) === null || _a === void 0 ? void 0 : _a.toString())) {
                                option_2.display = false;
                            }
                            else {
                                option_2.display = true;
                                this.updateShownOrHiddenItems((_b = option_2.children) !== null && _b !== void 0 ? _b : []);
                            }
                        }
                        return options;
                    },
                    elMenuOnRendered: function () {
                        var _this = this;
                        if (!this.$refs.menu) {
                            return;
                        }
                        var scrollTop = function () {
                            var scrollBarElement = _this.getScrollBarElement();
                            if (scrollBarElement) {
                                scrollBarElement.scrollTop(scrollTopData[self._scrollBarDataKey]);
                                clearTimers();
                            }
                        };
                        if (!isVertical) {
                            $(".el-menu", self.vueContainer)[0].style.setProperty('--el-menu-item-height', (self.vueContainer.height() - 3) + "px");
                        }
                        clearTimers();
                        timeoutTimer = setTimeout(clearTimers, 2000);
                        intervalTimer = setInterval(scrollTop, 50);
                    },
                    getScrollBarElement: function () {
                        return $(".el-scrollbar__wrap", $(this.$el));
                    },
                    setScrollTopValue: function () {
                        var _a;
                        scrollTopData[self._scrollBarDataKey] = (_a = this.getScrollBarElement()) === null || _a === void 0 ? void 0 : _a.scrollTop();
                    },
                    handleSelect: function (key) {
                        this.setScrollTopValue();
                        this.handleSelectInternal(key);
                    },
                    getNodeAndParentNode: function (index) {
                        var node;
                        var pNode;
                        var pNodeIndex = index.substring(0, index.lastIndexOf("-"));
                        this.flatOptions.forEach(function (option) {
                            if (option.index === index) {
                                node = option;
                                return;
                            }
                            if (option.index === pNodeIndex) {
                                pNode = option;
                            }
                        });
                        return { node: node, pNode: pNode };
                    },
                    handleClick: function (index) {
                        var _a = this.getNodeAndParentNode(index), node = _a.node, pNode = _a.pNode;
                        this.execClickCommand(node, pNode);
                    },
                    getClickCommandAndSelectCommandInitParams: function (command, node, pNode) {
                        var _a;
                        var _b = command.ParamProperties, value = _b.value, label = _b.label, parentId = _b.parentId, others = __rest(_b, ["value", "label", "parentId"]);
                        var initParam = (_a = {},
                            _a[value] = node === null || node === void 0 ? void 0 : node.value,
                            _a[label] = node === null || node === void 0 ? void 0 : node.label,
                            _a[parentId] = pNode === null || pNode === void 0 ? void 0 : pNode.value,
                            _a);
                        for (var othersKey in others) {
                            initParam[othersKey] = node[othersKey];
                        }
                        return initParam;
                    },
                    execClickCommand: function (node, pNode) {
                        var command = cellType.ClickCommand;
                        if (command) {
                            self.executeCustomCommandObject(command, this.getClickCommandAndSelectCommandInitParams(command, node, pNode), "click");
                        }
                    },
                    handleSelectInternal: function (key, preventCommandExecution) {
                        if (preventCommandExecution === void 0) { preventCommandExecution = false; }
                        this.selectedKey = key;
                        var _a = this.getNodeAndParentNode(key), node = _a.node, pNode = _a.pNode;
                        this.selectedValue = node === null || node === void 0 ? void 0 : node.value;
                        self.commitValue();
                        if (preventCommandExecution) {
                            return;
                        }
                        var command = cellType.SelectCommand;
                        if (command) {
                            self.executeCustomCommandObject(command, this.getClickCommandAndSelectCommandInitParams(command, node, pNode), "select");
                        }
                        this.execClickCommand(node, pNode);
                    },
                    handleOpen: function (index) {
                        this.openeds.add(index);
                    },
                    handleClose: function (index) {
                        this.openeds.delete(index);
                    },
                    openMenuItem: function (index) {
                        this.handleOpen(index);
                        this.$refs.menu.open(index);
                    },
                    closeMenuItem: function (index) {
                        this.handleClose(index);
                        this.$refs.menu.close(index);
                    },
                    getNodeKey: function (value) {
                        var _a, _b;
                        return (_b = (_a = this.flatOptions) === null || _a === void 0 ? void 0 : _a.find(function (option) { return option.value === value; })) === null || _b === void 0 ? void 0 : _b.index;
                    },
                    getValue: function () {
                        return this.selectedValue;
                    },
                    setValue: function (value) {
                        var key = this.getNodeKey(value);
                        if (key) {
                            this.handleSelectInternal(key, true);
                        }
                        this.defaultActive = key;
                    },
                    setOptions: function (options) {
                        var _this = this;
                        var optionsTree = self.generateIndex(options ? ElementCellTypes.TreeHelper.build(options) : []);
                        this.updateShownOrHiddenItems(optionsTree);
                        var isExpand = !cellType.uniqueOpened && cellType.DefaultExpansion === "expand" && isVertical;
                        var flatOptions = ElementCellTypes.TreeHelper.flat(optionsTree);
                        var _firstRender = self._firstRender;
                        if (_firstRender) {
                            self._firstRender = false;
                            if (isExpand) {
                                var defaultOpeneds_1 = [];
                                flatOptions.forEach(function (option) {
                                    var _a;
                                    if ((_a = option === null || option === void 0 ? void 0 : option.children) === null || _a === void 0 ? void 0 : _a.length) {
                                        defaultOpeneds_1.push(option.index);
                                    }
                                });
                                this.defaultOpeneds = defaultOpeneds_1;
                                defaultOpeneds_1.forEach(function (index) { return _this.openeds.add(index); });
                            }
                        }
                        if (isVertical) {
                            this.disableAnimation();
                        }
                        this.options = optionsTree;
                        this.flatOptions = flatOptions;
                        if (isVertical) {
                            this.$nextTick(function () {
                                _this.elMenuOnRendered();
                                $(".el-sub-menu__icon-arrow,.el-sub-menu__title", self.vueContainer)
                                    .unbind("click", _this.enableAnimation)
                                    .bind("click", _this.enableAnimation);
                                // 不是首次渲染,并且是全部展开，比如 “重新加载绑定数据”，需要手动将每一项展开
                                if (!_firstRender && isExpand) {
                                    flatOptions.forEach(function (option) { var _a, _b; return ((_a = option === null || option === void 0 ? void 0 : option.children) === null || _a === void 0 ? void 0 : _a.length) && ((_b = _this.$refs) === null || _b === void 0 ? void 0 : _b.menu.open(option.index)); });
                                    setTimeout(_this.enableAnimation, 1000);
                                }
                                else {
                                    _this.$nextTick(_this.enableAnimation);
                                }
                            });
                        }
                        NavMenuCellType.recalcIcon(this.options, self);
                    },
                    setCollapse: function (collapse) {
                        var _this = this;
                        this.enableAnimation();
                        if (collapse) {
                            if (cellType.collapseTransition) {
                                var openeds_1 = this.options.filter(function (option) { return _this.openeds.has(option.index); });
                                var timeout = openeds_1.length ? 300 : 0;
                                openeds_1.forEach(function (_a) {
                                    var index = _a.index;
                                    return _this.closeMenuItem(index);
                                });
                                setTimeout(function () {
                                    $(".fgc-el-menu-transparent", self.vueContainer).css("opacity", "0");
                                    _this.collapse = true;
                                }, timeout);
                            }
                            else {
                                this.collapse = true;
                            }
                        }
                        else {
                            this.collapse = false;
                        }
                    }
                },
                beforeDestroy: function () {
                    clearTimers();
                }
            };
            this.createVueApp(option);
            if (cellType.useBinding) {
                ElementCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (dataSource) { return _this.setDataSource(dataSource); });
            }
            else {
                NavMenuCellType.recalcNotice(this.vue.options, this);
            }
            _super.prototype.onPageLoaded.call(this, info);
            NavMenuCellType.recalcIcon(this.vue.options, this);
        };
        NavMenuCellType.prototype.filterOptionsByPermission = function (options, permissions) {
            var _this = this;
            if (!permissions) {
                return options;
            }
            return options.filter(function (option, index) {
                if (permissions[index]) {
                    var hasPermission = _this.checkRoleAuthority(permissions[index].AllowRoles);
                    if (hasPermission) {
                        option.children = _this.filterOptionsByPermission(option.children, permissions[index].Children);
                    }
                    return hasPermission;
                }
                return true;
            });
        };
        NavMenuCellType.prototype.getDefaultMenuItemSlot = function () {
            return "\n            <el-icon  v-if=\"item.svgIcon\" v-html=\"item.svgIcon\" />\n            <el-image v-if=\"item.iconSrc\" class=\"el-icon\" fit=\"contain\" :src=\"item.iconSrc\" />\n            <template #title>\n                <span class=\"fgc-el-menu-transparent\">{{item.label}}</span>\n                <el-badge :value=\"item.notice\" class=\"fgc-menu-badge-item\" />\n            </template>";
        };
        NavMenuCellType.prototype.SetDataSourceByObjTree = function (dataSource, valueProperty, labelProperty, childrenProperty, iconProperty) {
            if (typeof dataSource === "string") {
                dataSource = JSON.parse(dataSource);
            }
            var flatItems = [];
            var flat = function (data, parentValue) {
                data.forEach(function (item) {
                    var newItem = {
                        label: item[labelProperty !== null && labelProperty !== void 0 ? labelProperty : valueProperty],
                        value: item[valueProperty],
                        icon: item[iconProperty],
                        parentValue: parentValue,
                    };
                    flatItems.push(newItem);
                    if (item[childrenProperty]) {
                        flat(item[childrenProperty], newItem.value);
                    }
                });
            };
            flat(dataSource, null);
            this.setDataSource(flatItems);
        };
        NavMenuCellType.prototype.SetDataSourceByIdPidTable = function (dataSource, valueProperty, labelProperty, parentValue, iconProperty) {
            if (typeof dataSource === "string") {
                dataSource = JSON.parse(dataSource);
            }
            var items = dataSource.map(function (i) { return (__assign(__assign({}, i), { value: i[valueProperty], label: i[labelProperty !== null && labelProperty !== void 0 ? labelProperty : valueProperty], icon: i[iconProperty], parentValue: i[parentValue] })); });
            this.setDataSource(items);
        };
        NavMenuCellType.prototype.ReloadBindingItems = function () {
            var _this = this;
            var cellType = this.cellType;
            if (cellType.useBinding) {
                ElementCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (dataSource) {
                    _this.setDataSource(dataSource);
                    Object.keys(_this._badgeDic).forEach(function (key) {
                        _this.SetBadge(key, _this._badgeDic[key]);
                    });
                });
            }
        };
        NavMenuCellType.recalcNotice = function (option, cellType) {
            var nodes = ElementCellTypes.TreeHelper.flat(option);
            var _loop_1 = function (node) {
                var menuNode = node;
                if (menuNode && menuNode.notification) {
                    cellType.onFormulaResultChanged(menuNode.notification, function (value) {
                        if (value) {
                            menuNode.notice = value + "";
                        }
                        else {
                            menuNode.notice = "";
                        }
                    });
                }
            };
            for (var _i = 0, nodes_1 = nodes; _i < nodes_1.length; _i++) {
                var node = nodes_1[_i];
                _loop_1(node);
            }
        };
        NavMenuCellType.recalcIcon = function (option, cellType) {
            var nodes = ElementCellTypes.TreeHelper.flat(option);
            var _loop_2 = function (node) {
                var menuNode = node;
                if (menuNode && menuNode.icon) {
                    cellType.getIcon(menuNode.icon, function (icon) {
                        if (icon.isSvg) {
                            menuNode.svgIcon = icon.icon;
                        }
                        else {
                            menuNode.iconSrc = icon.icon;
                        }
                    });
                }
            };
            for (var _i = 0, nodes_2 = nodes; _i < nodes_2.length; _i++) {
                var node = nodes_2[_i];
                _loop_2(node);
            }
        };
        NavMenuCellType.prototype.getDefaultOpeneds = function (option, baseIndex, result) {
            if (baseIndex === void 0) { baseIndex = ""; }
            if (result === void 0) { result = []; }
            for (var i = 0; i < (option === null || option === void 0 ? void 0 : option.length); i++) {
                var item = option[i];
                if (item === null || item === void 0 ? void 0 : item.children) {
                    if (item.expend) {
                        result.push(baseIndex + i);
                    }
                    this.getDefaultOpeneds(item.children, "".concat(baseIndex).concat(i, "-"), result);
                }
            }
            return result;
        };
        NavMenuCellType.getNodePath = function (key, options) {
            if (!key) {
                return null;
            }
            var keys = key.split("-");
            var node = options.find(function (option) { return option.index === keys[0]; });
            var index = keys[0];
            var nodes = [node];
            for (var i = 1; i < keys.length; i++) {
                index += "-" + keys[i];
                node = node.children.find(function (option) { return option.index === index; });
                nodes.push(node);
            }
            return nodes;
        };
        //RunTime Method
        NavMenuCellType.prototype.GetSelectPath = function (type) {
            var nullValue = {
                PathArray: null
            };
            var key = this.vue.selectedKey;
            if (!key) {
                var value = this.getValueFromDataModel();
                if (this.vue) {
                    key = this.vue.getNodeKey(value);
                }
                if (!key) {
                    return nullValue;
                }
            }
            var nodes = NavMenuCellType.getNodePath(key, this.vue.options);
            if (nodes) {
                if (type === "valuePath") {
                    return {
                        PathArray: nodes.map(function (i) { return i.value; })
                    };
                }
                else {
                    return {
                        PathArray: nodes.map(function (i) { return i.label; })
                    };
                }
            }
            return nullValue;
        };
        NavMenuCellType.prototype.reload = function () {
            this.ReloadBindingItems();
        };
        // RunTimeMethod
        NavMenuCellType.prototype.SetCollapse = function (collapse) {
            this.vue.setCollapse(collapse);
        };
        // RunTimeMethod
        NavMenuCellType.prototype.HideItems = function (items) {
            var _this = this;
            if (!items) {
                return;
            }
            items.split(',').forEach(function (item) { return _this.vue.hideOptionValues.add(item.toString()); });
        };
        NavMenuCellType.prototype.ShowItems = function (items) {
            var _this = this;
            if (!items) {
                return;
            }
            items.split(',').forEach(function (item) { return _this.vue.hideOptionValues.delete(item.toString()); });
        };
        // RunTimeMethod
        NavMenuCellType.prototype.SetBadge = function (itemValue, badgeValue) {
            this._badgeDic[itemValue] = badgeValue;
            this.SetBadgeInternal(this.vue.options, itemValue, badgeValue);
        };
        NavMenuCellType.prototype.SetBadgeInternal = function (options, itemValue, badgeValue) {
            if (!options) {
                return;
            }
            for (var i = options.length - 1; i >= 0; i--) {
                var option = options[i];
                // eslint-disable-next-line
                if (option.value == itemValue) {
                    option.notice = badgeValue === null || badgeValue === void 0 ? void 0 : badgeValue.toString();
                }
                this.SetBadgeInternal(option.children, itemValue, badgeValue);
            }
        };
        return NavMenuCellType;
    }(ElementCellTypes.ElementCellTypeBase));
    ElementCellTypes.NavMenuCellType = NavMenuCellType;
    var CellHelper = /** @class */ (function () {
        function CellHelper() {
        }
        CellHelper.setValueToCell = function (context, cellLocationFormula, value) {
            if (!cellLocationFormula) {
                return;
            }
            var cellLocation = Forguncy.Helper.getCellLocation(cellLocationFormula, context);
            var cell = Forguncy.Page.getCellByLocation(cellLocation);
            if (cell) {
                cell.setValue(value);
            }
            else {
                Forguncy.CommandHelper.setVariableValue(cellLocationFormula, value);
            }
        };
        return CellHelper;
    }());
    ElementCellTypes.CellHelper = CellHelper;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.NavMenuCellType, ElementUI", ElementCellTypes.NavMenuCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var PaginationCellType = /** @class */ (function (_super) {
        __extends(PaginationCellType, _super);
        function PaginationCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        PaginationCellType.prototype.createContent = function () {
            var cellType = this.cellType;
            if (cellType.ListviewName) {
                Forguncy.ForguncyData.initListviewPaginationInfo(this.runTimePageName, cellType.ListviewName, cellType.pageSize);
            }
            return _super.prototype.createContent.call(this);
        };
        PaginationCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var _a;
            var self = this;
            this.addCustomClass("el-pagination-custom");
            var cellType = this.cellType;
            if (cellType.AttachElementTable) {
                this._elementTable = PaginationCellType.getElementTableCellTypeByName(cellType.ElementTableName, this.runTimePageName);
            }
            else if (cellType.ListviewName) {
                this._listview = Forguncy.Page.getListViews(true)
                    .filter(function (i) { return i.getName() === cellType.ListviewName && i.getRunTimePageName() === _this.runTimePageName; })[0];
            }
            var listview = this._listview;
            var elementTable = this._elementTable;
            var option = {
                template: "\n<div class=\"fgc-pagination\" style=\"height: 100%;\">\n<el-pagination\n    :small=\"small\"\n    :background=\"background\"\n    :page-size=\"pageSize\"\n    :total=total\n    :pager-count=\"pagerCount\"\n    :layout=\"layout\"\n    :page-sizes=\"pageSizes\"\n    :prev-text=\"prevText\"\n    :next-text=\"nextText\"\n    :disabled=\"disabled\"\n    :hide-on-single-page=\"hideOnSinglePage\"\n    v-model:currentPage=\"currentPage\"\n\n    @size-change=\"onSizeChanged\"\n    @current-change=\"onCurrentChanged\"\n    style=\"height: 100%;\"\n  >\n  </el-pagination>\n</div>",
                data: function () {
                    return {
                        small: cellType.small,
                        background: cellType.background,
                        pageSize: Number(cellType.pageSize),
                        total: 100,
                        pagerCount: cellType.pagerCount,
                        layout: cellType.layout.map(function (i) { return i.layoutItem; }).join(","),
                        pageSizes: cellType.pageSizes.map(function (i) { return i.value; }),
                        prevText: undefined,
                        nextText: undefined,
                        disabled: undefined,
                        currentPage: 1,
                        hideOnSinglePage: cellType.hideOnSinglePage,
                    };
                },
                methods: {
                    onSizeChanged: function (size) {
                        this.pageSize = size;
                        this.currentPage = 1;
                        this.updateSize();
                        this.executeCommand();
                    },
                    onCurrentChanged: function () {
                        this.updatePage();
                        this.executeCommand();
                        self.commitValue();
                    },
                    executeCommand: function () {
                        var _a, _b;
                        if ((_b = (_a = cellType.PagingChangeCommands) === null || _a === void 0 ? void 0 : _a.Commands) === null || _b === void 0 ? void 0 : _b.length) {
                            var commands = cellType.PagingChangeCommands;
                            var initParam = {};
                            initParam[commands.ParamProperties["pageSize"]] = this.pageSize;
                            initParam[commands.ParamProperties["currentPage"]] = this.currentPage;
                            initParam[commands.ParamProperties["total"]] = this.total;
                            self.executeCustomCommandObject(commands, initParam, "CurrentPageChangeCommands_" + self.ID);
                        }
                    },
                    setValue: function (value) {
                        var pageIndex = Math.max(1, Number(value));
                        if (Number.isNaN(pageIndex)) {
                            pageIndex = 1;
                        }
                        if (pageIndex !== this.currentPage) {
                            this.currentPage = pageIndex;
                            this.updatePage();
                        }
                    },
                    getValue: function () {
                        return this.currentPage;
                    },
                    updateSize: function () {
                        if (elementTable) {
                            self.queryElTable();
                        }
                        else if (listview) {
                            listview.usePaginationDisplay(this.pageSize);
                        }
                    },
                    updatePage: function () {
                        if (elementTable) {
                            self.queryElTable();
                        }
                        else if (listview) {
                            listview.goToSpecifiedPage(this.currentPage);
                        }
                    },
                    disable: function () {
                        this.disabled = true;
                    },
                    enable: function () {
                        this.disabled = false;
                    },
                    calcJumpInputWidth: function () {
                        var pageCount = Math.ceil(this.total / this.pageSize);
                        $(".el-pagination__jump .el-input__wrapper", self.vueContainer)
                            .add(".el-pagination__jump input", self.vueContainer)
                            .add(".el-pagination__jump .el-input", self.vueContainer)
                            .css("width", "".concat((Math.max(pageCount.toString().length, 5.6)) * 10, "px"));
                    }
                },
                watch: {
                    pageSize: function (value) {
                        if (typeof value !== "number") {
                            var numerValue = Number(value);
                            this.value = isNaN(numerValue) ? null : numerValue;
                        }
                        this.calcJumpInputWidth();
                    },
                    total: function () {
                        this.calcJumpInputWidth();
                    }
                }
            };
            this.createVueApp(option);
            this.onFormulaResultChanged(cellType.prevText, function (value) {
                _this.vue.prevText = value === null || value === void 0 ? void 0 : value.toString();
            });
            this.onFormulaResultChanged(cellType.nextText, function (value) {
                _this.vue.nextText = value === null || value === void 0 ? void 0 : value.toString();
            });
            if (elementTable) {
                elementTable.pager = this.vue;
                this.queryElTable();
            }
            else if (listview) {
                var currentInfo = listview.getPaginationInfo();
                this.vue.total = currentInfo === null || currentInfo === void 0 ? void 0 : currentInfo.TotalRowCount;
                this.vue.currentPage = currentInfo ? currentInfo.PageIndex : 1;
                this.vue.pageSize = (_a = currentInfo === null || currentInfo === void 0 ? void 0 : currentInfo.MaxRowCountOfOnePage) !== null && _a !== void 0 ? _a : this.vue.pageSize;
                this._pagingChangedCallBack = function (data, info) {
                    _this.vue.total = info.TotalRowCount;
                    _this.vue.currentPage = info.CurrentPageIndex;
                    _this.vue.pageSize = info.MaxRowCountOfOnePage;
                };
                listview.bind(Forguncy.ListViewEvents.PageingInfoChanged, this._pagingChangedCallBack);
            }
            _super.prototype.onPageLoaded.call(this, info);
        };
        PaginationCellType.prototype.destroy = function () {
            _super.prototype.destroy.call(this);
            if (this._listview) {
                this._listview.unbind(Forguncy.ListViewEvents.PageingInfoChanged, this._pagingChangedCallBack);
            }
        };
        PaginationCellType.getElementTableCellTypeByName = function (elTableName, pageName) {
            var _a;
            if (elTableName === null || elTableName === undefined || elTableName === "") {
                return null;
            }
            var allCells = Forguncy.ForguncyData.pageInfo.pageElementManager.cells.getAllCells([pageName]);
            var allElTableCells = allCells === null || allCells === void 0 ? void 0 : allCells.filter(function (cell) { return cell.cellType instanceof ElementCellTypes.TableCellType || cell.cellType instanceof ElementCellTypes.VirtualizedTableCellType; });
            return (_a = allElTableCells.find(function (_a) {
                var cellType = _a.cellType;
                if (cellType instanceof ElementCellTypes.VirtualizedTableCellType) {
                    return cellType.cellType.TableName === elTableName;
                }
                else {
                    return cellType.cellType.ElTableName === elTableName;
                }
            })) === null || _a === void 0 ? void 0 : _a.cellType;
        };
        PaginationCellType.prototype.queryElTable = function () {
            this._elementTable.queryElTable();
        };
        // RunTimeMethods
        PaginationCellType.prototype.SetPageSize = function (pageSize) {
            pageSize = Number(pageSize);
            this.vue.pageSize = pageSize;
            this.vue.updateSize();
        };
        PaginationCellType.prototype.SetCurrentPageIndex = function (index) {
            index = Number(index);
            this.vue.currentPage = index;
            this.vue.updatePage();
        };
        PaginationCellType.prototype.SetTotal = function (total) {
            total = Number(total);
            this.vue.total = total;
            this.vue.updateSize();
        };
        PaginationCellType.prototype.ExecuteCommand = function () {
            this.vue.executeCommand();
        };
        return PaginationCellType;
    }(ElementCellTypes.ElementCellTypeBase));
    ElementCellTypes.PaginationCellType = PaginationCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.CellTypes.PaginationCellType, ElementUI", ElementCellTypes.PaginationCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var ProgressType;
    (function (ProgressType) {
        ProgressType[ProgressType["line"] = 0] = "line";
        ProgressType[ProgressType["circle"] = 1] = "circle";
        ProgressType[ProgressType["dashboard"] = 2] = "dashboard";
    })(ProgressType || (ProgressType = {}));
    var ProgressStatus;
    (function (ProgressStatus) {
        ProgressStatus[ProgressStatus["none"] = 0] = "none";
        ProgressStatus[ProgressStatus["success"] = 1] = "success";
        ProgressStatus[ProgressStatus["exception"] = 2] = "exception";
        ProgressStatus[ProgressStatus["warning"] = 3] = "warning";
    })(ProgressStatus || (ProgressStatus = {}));
    var ProgressCellType = /** @class */ (function (_super) {
        __extends(ProgressCellType, _super);
        function ProgressCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        ProgressCellType.prototype.onWindowResized = function () {
            var _a;
            (_a = this.vue) === null || _a === void 0 ? void 0 : _a.calculateHeight();
        };
        ProgressCellType.prototype.onPageLoaded = function (info) {
            var cellType = this.cellType;
            var self = this;
            var containerId = "".concat(this.uId);
            var alignItems = cellType.type === ProgressType.line ? "" : "align-items:center";
            var option = {
                template: "<div class=\"fgc-el-progress\" style=\"".concat(alignItems, ";\">\n                              <el-progress\n                                  :percentage=\"percentage\"\n                                  :stroke-width=\"strokeWidth\"\n                                  :width=\"width\"\n                                  :type=\"type\"\n                                  :text-inside=\"textInside\"\n                                  :status=\"status\"\n                                  :color=\"color\"\n                                  :show-text=\"showText\"\n                                  :format=\"format\"\n                              />\n                        </div>\n                          "),
                data: function () {
                    return {
                        percentage: 0,
                        strokeWidth: cellType.strokeWidth,
                        width: 126,
                        showText: !!cellType.showText,
                        textInside: !!cellType.textInside && cellType.type === ProgressType.line,
                        type: ProgressType[cellType.type],
                        status: cellType.status === ProgressStatus.none ? null : ProgressStatus[cellType.status],
                        color: cellType.status === ProgressStatus.none ? Forguncy.ConvertToCssColor(cellType.color) : undefined,
                    };
                },
                mounted: function () {
                    this.calculateHeight();
                    self.fontDom = $(".el-progress__text,.el-progress-bar__innerText", self.getContainer()).find("span");
                },
                methods: {
                    calculateHeight: function () {
                        var container = document.getElementById(containerId);
                        if (!container) {
                            return;
                        }
                        var height = container.offsetHeight, width = container.offsetWidth;
                        if (this.type !== ProgressType[ProgressType.line]) {
                            this.width = Math.min(width, height);
                        }
                    },
                    getValue: function () {
                        return this.percentage;
                    },
                    setValue: function (value) {
                        var numberValue = Number(value);
                        this.percentage = isNaN(numberValue) ? value : numberValue;
                    },
                    format: function (percentage) {
                        if (cellType.textFormula) {
                            return self.evaluateFormula(cellType.textFormula);
                        }
                        return percentage + "%";
                    }
                }
            };
            this.createVueApp(option);
            _super.prototype.onPageLoaded.call(this, info);
        };
        ProgressCellType.prototype.clickable = function () {
            return false;
        };
        ProgressCellType.prototype.SetBackgroundColor = function (color) {
            this.vue.status = null;
            this.vue.color = Forguncy.ConvertToCssColor(color);
        };
        ProgressCellType.prototype.SetStatus = function (status) {
            var newStatus = status === ProgressStatus.none ? null : ProgressStatus[status];
            if (newStatus) {
                this.vue.color = undefined;
            }
            this.vue.status = newStatus;
        };
        return ProgressCellType;
    }(ElementCellTypes.ElementCellTypeBase));
    ElementCellTypes.ProgressCellType = ProgressCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.ProgressCellType, ElementUI", ElementCellTypes.ProgressCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var RateDisplayContentType;
    (function (RateDisplayContentType) {
        RateDisplayContentType[RateDisplayContentType["None"] = 0] = "None";
        RateDisplayContentType[RateDisplayContentType["Text"] = 1] = "Text";
        RateDisplayContentType[RateDisplayContentType["Scope"] = 2] = "Scope";
    })(RateDisplayContentType || (RateDisplayContentType = {}));
    var RateCellType = /** @class */ (function (_super) {
        __extends(RateCellType, _super);
        function RateCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        RateCellType.prototype.onPageLoaded = function (info) {
            var cellType = this.cellType;
            var self = this;
            var DisplayContentType = cellType.DisplayContentType;
            var option = {
                template: "\n                        <div style=\"display:flex;align-items:center;width:100%;height:100%\">\n                            <el-rate\n                                v-model=\"value\"\n                                :max=\"max\"\n                                :disabled=\"disabled\"\n                                :show-text=\"showText\"\n                                :show-score=\"showScore\"\n                                :texts=\"texts\"\n                                :colors=\"colors\"\n                                :void-color=\"voidColor\"\n                                :disabled-void-color=\"disabledVoidColor\t\"\n                                :allow-half=\"allowHalf\"\n                                :low-threshold=\"lowThreshold\"\n                                :high-threshold=\"highThreshold\"\n                                @change=\"handleChange\"\n                           />\n                       </div>\n                          ",
                data: function () {
                    var _a, _b;
                    return {
                        value: null,
                        max: cellType.max,
                        disabled: undefined,
                        allowHalf: cellType.allowHalf,
                        lowThreshold: cellType.lowThreshold,
                        highThreshold: cellType.highThreshold,
                        voidColor: Forguncy.ConvertToCssColor(cellType.voidColor),
                        disabledVoidColor: Forguncy.ConvertToCssColor(cellType.disabledVoidColor),
                        texts: (_a = cellType.texts) === null || _a === void 0 ? void 0 : _a.map(function (_a) {
                            var label = _a.label;
                            return label;
                        }),
                        colors: (_b = cellType.colors) === null || _b === void 0 ? void 0 : _b.map(function (_a) {
                            var color = _a.color;
                            return Forguncy.ConvertToCssColor(color);
                        }),
                        showText: DisplayContentType === RateDisplayContentType.Text,
                        showScore: DisplayContentType === RateDisplayContentType.Scope,
                    };
                },
                mounted: function () {
                    self.fontDom = $(".el-rate__text", self.getContainer());
                },
                methods: {
                    getValue: function () {
                        return this.value;
                    },
                    setValue: function (value) {
                        this.value = Math.min(value, this.max);
                    },
                    setReadOnly: function (readOnly) {
                        this.disabled = readOnly;
                    },
                    handleChange: function () {
                        self.commitValue();
                    }
                }
            };
            this.createVueApp(option);
            _super.prototype.onPageLoaded.call(this, info);
        };
        RateCellType.prototype.setReadOnly = function (value) {
            _super.prototype.setReadOnly.call(this, value);
            this.refreshClickable();
        };
        RateCellType.prototype.refreshClickable = function () {
            var _a, _b;
            if ((_a = this.vue) === null || _a === void 0 ? void 0 : _a.$el) {
                (_b = $(this.vue.$el).parent()) === null || _b === void 0 ? void 0 : _b.attr("clickable", this.clickable() ? true : "");
            }
        };
        RateCellType.prototype.clickable = function () {
            return !this.isReadOnly() && !this.isDisabled();
        };
        return RateCellType;
    }(ElementCellTypes.ElementCellTypeBase));
    ElementCellTypes.RateCellType = RateCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.RateCellType, ElementUI", ElementCellTypes.RateCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var SelectCellType = /** @class */ (function (_super) {
        __extends(SelectCellType, _super);
        function SelectCellType() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this._labelWithValueDict = new Map();
            _this.defaultQueryDataOption = {
                top: _this.cellType.filterInServerOptions.defaultMaxOptionsCount,
                queryConditions: [],
                distinct: true
            };
            return _this;
        }
        SelectCellType.prototype.setDataSource = function (dataSource, userAction) {
            var _a;
            if (userAction) {
                this.vue.value = null;
                this.commitValue();
            }
            var cloneDataSource = __spreadArray([], dataSource, true);
            if (this.cellType.AllowAddEmptyItem) {
                var label = (_a = this.cellType.EmptyItemLabel) !== null && _a !== void 0 ? _a : "";
                if (!label) {
                    this.vue.placeholder = null;
                }
                /**
                 * Element Plus 不接受一个null,会报 warning
                 */
                cloneDataSource.unshift({ value: "", label: label });
            }
            return this.vue.setOptions(cloneDataSource);
        };
        SelectCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var _a;
            var optionStr = this.getCustomSlotByPath(ElementCellTypes.SlotPath.selectOption);
            var prefixStr = this.getCustomSlotByPath(ElementCellTypes.SlotPath.selectPrefix);
            var self = this;
            var styleInfo = (_a = this._cellStyle) !== null && _a !== void 0 ? _a : {};
            var fontSize = styleInfo.FontSize && styleInfo.FontSize > 0 ? styleInfo.FontSize : "";
            var cellType = this.cellType;
            this.addCustomClass("el-select-custom");
            var options = [];
            if (cellType.options && !cellType.useBinding) {
                options = cellType.options.map(function (o) {
                    _this._labelWithValueDict.set(o.value, o.label);
                    return self.convertOption(o);
                });
            }
            var remoteFilterBinding = '';
            if (cellType.useBinding && cellType.filterInServer) {
                remoteFilterBinding = ':remote-method="remoteMethod"';
            }
            var CssClassName = this.CellElement.CssClassName;
            var popperClass = CssClassName ? "".concat(CssClassName, "-popper") : "";
            var option = {
                template: "\n<el-select\n    :title=\"title\"\n    v-model=\"value\"\n    :placeholder=\"placeholder\"\n    :disabled = \"disabled\"\n    :clearable= \"clearable\"\n    :collapse-tags = \"collapseTags\"\n    :filterable = \"filterable\"\n    :multiple = \"multiple\"\n    :allow-create = \"allowCreate\"\n    :reserve-keyword = \"reserveKeyword\"\n    :multiple-limit = \"multipleLimit\"\n    :no-match-text = \"noMatchText\"\n    :no-data-text = \"noDataText\"\n    :remote=\"filterInServer\"\n    popper-class=\"".concat(popperClass, "\"\n    ").concat(remoteFilterBinding, "\n    :loading-text=\"loadingText\"\n    :loading=\"loading\"\n    default-first-option\n    ref=\"elInput\"\n    @change=\"handleChange\"\n    @blur=\"handleBlur\"\n     style=\"height:100%;width:100%\">\n        <el-option\n              style=\"font-size:").concat(fontSize, "px;\"\n              v-for=\"option in options\"\n              :key=\"option.value\"\n              :label=\"option.label\"\n              :value=\"option.value\"\n        >\n            ").concat(optionStr, "\n        </el-option>\n        ").concat(prefixStr ? "<template #prefix>" + prefixStr + "</template>" : "", "\n    </el-select>\n"),
                data: function () {
                    return {
                        disabled: cellType.IsDisabled,
                        value: "",
                        options: options,
                        placeholder: undefined,
                        clearable: cellType.clearable,
                        collapseTags: cellType.collapseTags,
                        filterable: cellType.filterable,
                        multiple: cellType.multiple,
                        allowCreate: cellType.allowCreate,
                        reserveKeyword: !!cellType.reserveKeyword,
                        multipleLimit: cellType.multipleLimit,
                        noMatchText: undefined,
                        noDataText: undefined,
                        loading: false,
                        filterInServer: cellType.filterInServer,
                        loadingText: undefined,
                    };
                },
                methods: {
                    handleChange: function () {
                        self.commitValue();
                        self.validate();
                    },
                    handleBlur: function () {
                        self.validate();
                    },
                    getValue: function () {
                        if (cellType.multiple && this.value instanceof Array) {
                            return this.value.join(",");
                        }
                        return this.value;
                    },
                    setValue: function (value) {
                        this.setValueInternal(value, true);
                    },
                    setValueInternal: function (value, loadNotMathItems) {
                        if (loadNotMathItems === void 0) { loadNotMathItems = false; }
                        if (!self.isEmpty(value)) {
                            var arrayValue = void 0;
                            if (cellType.multiple) {
                                if (value instanceof Array) {
                                    arrayValue = value;
                                }
                                else {
                                    arrayValue = (value + "").split(",");
                                }
                            }
                            else {
                                arrayValue = [value];
                            }
                            var notMatchItems = this.updateValueByItems(arrayValue);
                            if (cellType.multiple) {
                                this.value = arrayValue;
                            }
                            else {
                                this.value = arrayValue[0];
                            }
                            if (loadNotMathItems) {
                                this.queryNotMatchItemsFromServer(notMatchItems);
                            }
                        }
                        else {
                            this.value = "";
                        }
                    },
                    queryNotMatchItemsFromServer: function (notMatchItems) {
                        var _this = this;
                        if (!notMatchItems || notMatchItems.length === 0) {
                            return;
                        }
                        if (cellType.filterInServer) {
                            var queryDataOption = {
                                queryConditions: [],
                                relationType: 1 /* Forguncy.Plugin.relationType.Or */
                            };
                            for (var _i = 0, notMatchItems_1 = notMatchItems; _i < notMatchItems_1.length; _i++) {
                                var notMatchItem = notMatchItems_1[_i];
                                queryDataOption.queryConditions.push({
                                    columnName: "value",
                                    compareType: 0 /* Forguncy.Plugin.compareType.EqualsTo */,
                                    compareValue: notMatchItem
                                });
                            }
                            self.getBindingDataSourceValue(cellType.bindingOptions, queryDataOption, function (newOptions) {
                                if (newOptions && newOptions.length > 0) {
                                    var _loop_3 = function (newOption) {
                                        var originalOptions = __spreadArray([], _this.options, true);
                                        // 在这里需要将newOption push到options里面去是为了正常显示label
                                        _this.options.push(newOption);
                                        // 等label渲染成功后，在还原options
                                        _this.$nextTick(function (_) {
                                            _this.options = originalOptions;
                                        });
                                    };
                                    for (var _i = 0, newOptions_1 = newOptions; _i < newOptions_1.length; _i++) {
                                        var newOption = newOptions_1[_i];
                                        _loop_3(newOption);
                                    }
                                }
                                _this.setValueInternal(_this.value);
                            });
                        }
                    },
                    updateValueByItems: function (arrayValue) {
                        var _a;
                        var notMatchItems = [];
                        if (this.options) {
                            var _loop_4 = function (i) {
                                var value = arrayValue[i];
                                if (!value && value !== 0) {
                                    return "continue";
                                }
                                var match = false;
                                var setValue = function (value) {
                                    arrayValue[i] = value;
                                    match = true;
                                };
                                for (var _i = 0, _b = this_1.options; _i < _b.length; _i++) {
                                    var option_3 = _b[_i];
                                    if (option_3.value === value) {
                                        setValue(option_3.value);
                                        break;
                                    }
                                }
                                if (!match) {
                                    for (var _c = 0, _d = this_1.options; _c < _d.length; _c++) {
                                        var option_4 = _d[_c];
                                        if (((_a = option_4.value) === null || _a === void 0 ? void 0 : _a.toString()) === (value === null || value === void 0 ? void 0 : value.toString())) {
                                            setValue(option_4.value);
                                            break;
                                        }
                                    }
                                }
                                if (!match) {
                                    for (var _e = 0, _f = this_1.options; _e < _f.length; _e++) {
                                        var option_5 = _f[_e];
                                        if (option_5.value == value) {
                                            setValue(option_5.value);
                                            break;
                                        }
                                    }
                                }
                                if (!match) {
                                    notMatchItems.push(value);
                                }
                            };
                            var this_1 = this;
                            for (var i = 0; i < arrayValue.length; i++) {
                                _loop_4(i);
                            }
                        }
                        return notMatchItems;
                    },
                    remoteMethod: function (query) {
                        var _this = this;
                        var queryDataOption = self.defaultQueryDataOption;
                        if (query) {
                            queryDataOption = {
                                queryConditions: [{
                                        columnName: "label",
                                        compareType: cellType.filterInServerOptions.matchMethod === "startWith" ?
                                            6 /* Forguncy.Plugin.compareType.BeginsWith */ : 10 /* Forguncy.Plugin.compareType.Contains */,
                                        compareValue: query + ""
                                    }],
                                distinct: true,
                                top: cellType.filterInServerOptions.maxFilterResultCount
                            };
                        }
                        this.loading = true;
                        ElementCellTypes.SupportDataSourceCellType.refreshDataWithOption(self, cellType.bindingOptions, function (dataSource) {
                            self.setDataSource(dataSource, false);
                            _this.loading = false;
                        }, queryDataOption, false);
                    },
                    disable: function () {
                        this.disabled = true;
                    },
                    enable: function () {
                        this.disabled = false;
                    },
                    setOptions: function (options) {
                        if (options) {
                            this.options = options.map(function (o) {
                                self._labelWithValueDict.set(o.value, o.label);
                                return self.convertOption(o);
                            });
                        }
                        else {
                            this.options = [];
                        }
                    }
                },
                computed: {
                    title: function () {
                        return self.getSelectedText();
                    }
                },
                mounted: function () {
                    var input = $("input", $(this.$el));
                    if (input.length > 0) {
                        self.fontDom = input;
                        self.setFontToDom();
                    }
                }
            };
            this.createVueApp(option);
            if (cellType.useBinding) {
                if (cellType.filterable && cellType.filterInServer) {
                    ElementCellTypes.SupportDataSourceCellType.refreshDataWithOption(this, cellType.bindingOptions, function (dataSource, userAction) { return _this.setDataSource(dataSource, userAction); }, this.defaultQueryDataOption);
                }
                else {
                    self.ReloadBindingItems();
                }
            }
            this.onFormulaResultChanged(cellType.placeholder, function (value) {
                var _a;
                _this.vue.placeholder = (_a = value === null || value === void 0 ? void 0 : value.toString()) !== null && _a !== void 0 ? _a : " ";
            });
            this.onFormulaResultChanged(cellType.noDataText, function (value) {
                _this.vue.noDataText = value === null || value === void 0 ? void 0 : value.toString();
            });
            this.onFormulaResultChanged(cellType.noMatchText, function (value) {
                _this.vue.noMatchText = value === null || value === void 0 ? void 0 : value.toString();
            });
            this.onFormulaResultChanged(cellType.filterInServerOptions.loadingText, function (value) {
                _this.vue.loadingText = value === null || value === void 0 ? void 0 : value.toString();
            });
            _super.prototype.onPageLoaded.call(this, info);
        };
        SelectCellType.prototype.convertOption = function (item) {
            var _a;
            return __assign(__assign({}, item), { value: (_a = item.value) !== null && _a !== void 0 ? _a : "", label: this.format(item.label) });
        };
        SelectCellType.prototype.getSelectedText = function () {
            var _this = this;
            var value = this.vue.value;
            if (Array.isArray(value)) {
                return value.map(function (v) { return _this._labelWithValueDict.has(v) ? _this._labelWithValueDict.get(v) : v; }).join(",");
            }
            else {
                return this._labelWithValueDict.has(value) ? this._labelWithValueDict.get(value) : value;
            }
        };
        SelectCellType.prototype.ReloadBindingItems = function () {
            var _this = this;
            var cellType = this.CellElement.CellType;
            ElementCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (dataSource, userAction) { return _this.setDataSource(dataSource, userAction); }, {
                distinct: true
            });
        };
        SelectCellType.prototype.preReload = function () {
            var cellType = this.CellElement.CellType;
            this.clearBindingDataSourceValueCache(cellType.bindingOptions, {
                distinct: true
            });
        };
        SelectCellType.prototype.reload = function () {
            var _this = this;
            if (this.cellType.filterable && this.cellType.filterInServer) {
                ElementCellTypes.SupportDataSourceCellType.refreshDataWithOption(this, this.cellType.bindingOptions, function (dataSource, userAction) { return _this.setDataSource(dataSource, userAction); }, this.defaultQueryDataOption, false, false);
                return;
            }
            if (this.cellType.useBinding) {
                this.ReloadBindingItems();
            }
        };
        SelectCellType.prototype.SetDataSourceByStringArray = function (dataSource) {
            if (!dataSource) {
                dataSource = [];
            }
            if (typeof dataSource === "string") {
                dataSource = JSON.parse(dataSource);
            }
            var objSource = dataSource.map(function (i) { return ({
                "value": i,
                "label": i,
            }); });
            this.setDataSource(objSource, false);
        };
        SelectCellType.prototype.SetDataSourceByObjArray = function (dataSource, valueProperty, labelProperty) {
            if (!dataSource) {
                dataSource = [];
            }
            if (typeof dataSource === "string") {
                dataSource = JSON.parse(dataSource);
            }
            if (!labelProperty) {
                labelProperty = valueProperty;
            }
            var objSource = dataSource.map(function (i) { return (__assign(__assign({}, i), { "value": i[valueProperty], "label": i[labelProperty] })); });
            this.setDataSource(objSource, false);
        };
        SelectCellType.prototype.Focus = function () {
            this.vue.$refs.elInput.focus();
        };
        SelectCellType.prototype.setFocus = function () {
            this.Focus();
        };
        SelectCellType.prototype.hasFocus = function () {
            var dom = $(".el-input__inner", this.vueContainer);
            return dom.length && document.activeElement === dom[0];
        };
        SelectCellType.prototype.GetSelectedText = function () {
            return {
                SelectedText: this.getSelectedText()
            };
        };
        return SelectCellType;
    }(ElementCellTypes.InputCellTypeBase));
    ElementCellTypes.SelectCellType = SelectCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.SelectCellType, ElementUI", ElementCellTypes.SelectCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var SliderCellType = /** @class */ (function (_super) {
        __extends(SliderCellType, _super);
        function SliderCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        SliderCellType.prototype.convertToObjectMarks = function (marks) {
            return marks.reduce(function (obj, item) { return (obj[item.Value] = item.Label, obj); }, {});
        };
        SliderCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var cellType = this.cellType;
            var self = this;
            var isVertical = cellType.layout === "vertical";
            this.getContainer().css("overflow", "");
            var marks = this.convertToObjectMarks(cellType.Marks);
            var option = {
                template: "<div id=\"".concat(this.uId, "-el-slider\" :class=\"['fgc-slider', 'hasMarks',{ 'is-vertical': vertical }]\">\n                               <el-slider\n                                   v-model=\"value\" :min=\"min\" :max=\"max\" :disabled=\"disabled\" :showTooltip=\"showTooltip\"\n                                   :step=\"step\" :show-input=\"showInput\" :show-input-controls=\"showInputControls\"\n                                   :show-stops=\"showStops\" :range=\"range\" :vertical=\"vertical\" :height=\"height\"\n                                   :formatTooltip=\"formatTooltip\" :marks=\"marks\"\n                                   @change=\"handleChange\"\n                               />\n                            </div> \n                          "),
                data: function () {
                    return {
                        value: null,
                        height: null,
                        min: undefined,
                        max: undefined,
                        disabled: undefined,
                        step: undefined,
                        showTooltip: !!cellType.showTooltip,
                        showInput: cellType.showInput,
                        showInputControls: !!cellType.showInputControls,
                        showStops: cellType.showStops,
                        range: cellType.range,
                        vertical: isVertical,
                        marks: marks
                    };
                },
                mounted: function () {
                    if (this.vertical) {
                        var element = document.getElementById("".concat(self.uId, "-el-slider"));
                        var height = (element.offsetHeight - 24) - (this.showInput ? 58 : 0);
                        this.height = "".concat(height, "px");
                    }
                },
                methods: {
                    getValue: function () {
                        if (Array.isArray(this.value)) {
                            return this.value.join(",");
                        }
                        return this.value;
                    },
                    setValue: function (value) {
                        if (self.isEmpty(value)) {
                            this.value = undefined;
                        }
                        else if (typeof value === "number") {
                            this.value = value;
                        }
                        else if (typeof value === "string") {
                            this.value = value.indexOf(',') !== -1 ?
                                value.split(",").map(function (i) { return Number(i); }) :
                                Number(value);
                        }
                    },
                    disable: function () {
                        this.disabled = true;
                    },
                    enable: function () {
                        this.disabled = false;
                    },
                    handleChange: function () {
                        self.commitValue();
                    },
                    formatTooltip: function (value) {
                        if (cellType.formatTooltipStr) {
                            self.setContextVariableValue("Value", value);
                            try {
                                return self.evaluateFormula(cellType.formatTooltipStr);
                            }
                            finally {
                                self.clearContextVariableValue("Value");
                            }
                        }
                        return value;
                    }
                }
            };
            this.createVueApp(option);
            this.onFormulaResultChanged(cellType.min, function (value) {
                _this.vue.min = _this.toNumber(value);
            });
            this.onFormulaResultChanged(cellType.max, function (value) {
                _this.vue.max = _this.toNumber(value);
            });
            this.onFormulaResultChanged(cellType.step, function (value) {
                _this.vue.step = _this.toNumber(value);
            });
            _super.prototype.onPageLoaded.call(this, info);
        };
        SliderCellType.prototype.SetMinValue = function (value) {
            this.vue.min = this.toNumber(value);
        };
        SliderCellType.prototype.SetMaxValue = function (value) {
            this.vue.max = this.toNumber(value);
        };
        SliderCellType.prototype.SetMarks = function (marks) {
            this.vue.marks = this.convertToObjectMarks((marks === null || marks === void 0 ? void 0 : marks.$values) || []);
        };
        SliderCellType.prototype.GetSelectedRange = function () {
            var value = this.vue.value;
            if (value instanceof Array) {
                return {
                    StartValue: value[0],
                    EndValue: value[1]
                };
            }
            return {};
        };
        return SliderCellType;
    }(ElementCellTypes.InputCellTypeBase));
    ElementCellTypes.SliderCellType = SliderCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.SliderCellType, ElementUI", ElementCellTypes.SliderCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var StepsStatus;
    (function (StepsStatus) {
        StepsStatus[StepsStatus["wait"] = 0] = "wait";
        StepsStatus[StepsStatus["process"] = 1] = "process";
        StepsStatus[StepsStatus["finish"] = 2] = "finish";
        StepsStatus[StepsStatus["error"] = 3] = "error";
        StepsStatus[StepsStatus["success"] = 4] = "success";
    })(StepsStatus || (StepsStatus = {}));
    var StepsCellType = /** @class */ (function (_super) {
        __extends(StepsCellType, _super);
        function StepsCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        StepsCellType.prototype.setDataSource = function (dataSource) {
            return this.vue.setOptions(dataSource);
        };
        StepsCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var cellType = this.cellType;
            var self = this;
            var containerId = "".concat(this.uId, "-el-steps");
            this.addCustomClass("el-steps-custom");
            var option = {
                el: "#" + this.uId,
                template: "<div id=\"".concat(containerId, "\" style=\"width: 100%;height: 100%;\">\n                                 <el-steps \n                                     :key=\"refreshKey\"\n                                     :active=\"active\" \n                                     :direction=\"direction\" \n                                     :simple=\"simple\" \n                                     :align-center=\"alignCenter\" \n                                     :process-status=\"processStatus\"\n                                     :finish-status=\"finishStatus\"\n                                 > \n                                    <el-step \n                                        v-for=\"item in options\" \n                                        :key=\"item.title\" \n                                        :title=\"item.title\" \n                                        :icon=\"item.iconComponent\" \n                                        :class=\"{'custom-icon':item.iconComponent}\"\n                                        :description=\"item.description\" \n                                    />\n                                 </el-steps>\n                            </div>\n                          "),
                data: function () {
                    return {
                        active: -1,
                        value: null,
                        options: cellType.useBinding ? [] : cellType.options,
                        simple: cellType.simple && cellType.layout === "horizontal",
                        alignCenter: cellType.simple ? false : cellType.alignCenter,
                        direction: cellType.layout,
                        processStatus: StepsStatus[cellType.processStatus],
                        finishStatus: StepsStatus[cellType.finishStatus],
                        refreshKey: 0
                    };
                },
                methods: {
                    getValue: function () {
                        return this.value;
                    },
                    setValue: function (value) {
                        this.value = value;
                        this.updateActive();
                    },
                    setOptions: function (options) {
                        this.options = options;
                        this.updateActive();
                        self.recalcIcon();
                        // element bug, 暂时使用key重新刷新组件，重置step内部错误状态。
                        // bug report [Component] [steps] el-steps: 数据源改变之后，步骤条的顺序出错 #12811
                        // bug link: https://github.com/element-plus/element-plus/issues/12811
                        this.refreshKey = (this.refreshKey + 1) % 2;
                    },
                    updateActive: function () {
                        var _a, _b;
                        if ((_a = this.options) === null || _a === void 0 ? void 0 : _a.length) {
                            for (var i = 0; i < this.options.length; i++) {
                                var option_6 = this.options[i];
                                // 这里认为字符串数字与数字等价，双等号不能去掉
                                // eslint-disable-next-line
                                if (option_6.value == this.value) {
                                    this.active = i;
                                    return;
                                }
                            }
                        }
                        if (this.value || this.value === 0) {
                            this.active = (_b = this.options) === null || _b === void 0 ? void 0 : _b.length;
                        }
                        else {
                            this.active = -1;
                        }
                    }
                }
            };
            this.createVueApp(option);
            self.recalcIcon();
            if (cellType.useBinding) {
                ElementCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (dataSource) { return _this.setDataSource(dataSource); });
            }
        };
        StepsCellType.prototype.recalcIcon = function () {
            var _loop_5 = function (i) {
                var option = this_2.vue.options[i];
                var icon = option === null || option === void 0 ? void 0 : option.icon;
                this_2.getIconComponent(icon, function (icon) { return option.iconComponent = icon; });
            };
            var this_2 = this;
            for (var i = 0; i < this.vue.options.length; i++) {
                _loop_5(i);
            }
        };
        StepsCellType.prototype.ReloadBindingItems = function () {
            var _this = this;
            var cellType = this.cellType;
            if (cellType.useBinding) {
                ElementCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (dataSource) { return _this.setDataSource(dataSource); });
            }
        };
        StepsCellType.prototype.reload = function () {
            this.ReloadBindingItems();
        };
        StepsCellType.prototype.UpdateProcessState = function (state) {
            this.vue.processStatus = StepsStatus[state];
        };
        return StepsCellType;
    }(ElementCellTypes.ElementCellTypeBase));
    ElementCellTypes.StepsCellType = StepsCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.StepsCellType, ElementUI", ElementCellTypes.StepsCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var transitionDuration = 0.3;
    var setElTransitionDurationPropertyTimeOut = 0.3 * 1000;
    var TabHeaderCellType = /** @class */ (function (_super) {
        __extends(TabHeaderCellType, _super);
        function TabHeaderCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        TabHeaderCellType.prototype.setElTransitionDurationProperty = function (delay) {
            if (delay === void 0) { delay = false; }
            var handler = function () { return document.documentElement.style.setProperty('--el-transition-duration', transitionDuration + "s"); };
            if (delay) {
                if (this._setElTransitionDurationPropertyTimer) {
                    clearTimeout(this._setElTransitionDurationPropertyTimer);
                }
                this._setElTransitionDurationPropertyTimer = setTimeout(handler, setElTransitionDurationPropertyTimeOut);
            }
            else {
                handler();
            }
        };
        TabHeaderCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var cellType = this.cellType;
            var self = this;
            var tabs = [];
            if (!cellType.useBinding && cellType.Tabs) {
                cellType.Tabs.every(function (i) { var _a; return i.ValueStr = (_a = i.Value) === null || _a === void 0 ? void 0 : _a.toString(); });
                tabs = cellType.Tabs;
            }
            this.addCustomClass("el-tabs-custom");
            var activeName = (cellType.DefaultIndex - 1).toString();
            var classStr = "fgc-" + cellType.type;
            var option = {
                template: "<el-tabs v-model=\"activeName\" class=\"".concat(classStr, "\" :type=\"type\" :stretch=\"stretch\" :tab-position=\"position\" @tab-click=\"ItemClick\">\n<template v-for=\"(tab,index) in displayedTabs\">\n  <el-tab-pane :name=\"tab.ValueStr\" :label=\"tab.Name\"></el-tab-pane>\n</template>\n</el-tabs>"),
                data: function () {
                    return {
                        tabs: tabs,
                        displayedTabs: tabs,
                        activeName: activeName,
                        value: null,
                        type: cellType.type === "default" ? undefined : cellType.type,
                        position: cellType.position,
                        stretch: cellType.stretch
                    };
                },
                methods: {
                    getValue: function () {
                        return this.value;
                    },
                    setValue: function (value) {
                        document.documentElement.style.setProperty('--el-transition-duration', "0s");
                        this.value = value;
                        this.activeName = value === null || value === void 0 ? void 0 : value.toString();
                        self.setElTransitionDurationProperty(true);
                    },
                    ItemClick: function (tab) {
                        var _this = this;
                        self.setElTransitionDurationProperty(false);
                        setTimeout(function () {
                            var _a, _b;
                            var index = Number(tab.index);
                            var value = _this.displayedTabs[index].Value;
                            if ((_b = (_a = cellType.ClickCommand) === null || _a === void 0 ? void 0 : _a.Commands) === null || _b === void 0 ? void 0 : _b.length) {
                                var initValue = {};
                                initValue[cellType.ClickCommand.ParamProperties["itemIndex"]] = index + 1;
                                initValue[cellType.ClickCommand.ParamProperties["itemValue"]] = value;
                                initValue[cellType.ClickCommand.ParamProperties["itemText"]] = tab.props.label;
                                self.executeCustomCommandObject(cellType.ClickCommand, initValue);
                            }
                            _this.value = value;
                            self.commitValue();
                        }, transitionDuration * 1000);
                    },
                }
            };
            this.createVueApp(option);
            if (cellType.useBinding) {
                ElementCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (dataSource) {
                    if (dataSource) {
                        dataSource.every(function (i) { var _a; return i.ValueStr = (_a = i.Value) === null || _a === void 0 ? void 0 : _a.toString(); });
                    }
                    _this.vue.tabs = dataSource !== null && dataSource !== void 0 ? dataSource : [];
                    _this.vue.displayedTabs = _this.vue.tabs;
                });
            }
            _super.prototype.onPageLoaded.call(this, info);
        };
        TabHeaderCellType.prototype.HideItems = function (value) {
            var _a;
            var itemArray = (_a = value === null || value === void 0 ? void 0 : value.split(',')) === null || _a === void 0 ? void 0 : _a.map(function (item) { return item.toString(); });
            if (!(itemArray === null || itemArray === void 0 ? void 0 : itemArray.length)) {
                return;
            }
            this.vue.displayedTabs = this.vue.displayedTabs.filter(function (tab) { var _a; return !itemArray.includes((_a = tab.Value) === null || _a === void 0 ? void 0 : _a.toString()); });
        };
        TabHeaderCellType.prototype.ShowItems = function (value) {
            var _this = this;
            var _a;
            var itemArray = (_a = value === null || value === void 0 ? void 0 : value.split(',')) === null || _a === void 0 ? void 0 : _a.map(function (item) { return item.toString(); });
            if (!(itemArray === null || itemArray === void 0 ? void 0 : itemArray.length)) {
                return;
            }
            this.vue.displayedTabs = this.vue.tabs.filter(function (tab) { var _a; return itemArray.includes((_a = tab.Value) === null || _a === void 0 ? void 0 : _a.toString()) || _this.vue.displayedTabs.includes(tab); });
        };
        return TabHeaderCellType;
    }(ElementCellTypes.ElementCellTypeBase));
    ElementCellTypes.TabHeaderCellType = TabHeaderCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.TabHeader, ElementUI", ElementCellTypes.TabHeaderCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var TableCellType = /** @class */ (function (_super) {
        __extends(TableCellType, _super);
        function TableCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        TableCellType.prototype.setDataSource = function (dataSource) {
            return this.vue.setOptions(dataSource);
        };
        TableCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var self = this;
            var columnSlot = this.getCustomSlotByPath(ElementCellTypes.SlotPath.tableColumnContent);
            var cellType = this.CellElement.CellType;
            if (cellType.autoGenerateColumnsByDataSource) {
                cellType.columns = cellType.bindingColumns;
            }
            var option = {
                el: "#" + this.uId,
                template: "\n<el-table\nref=\"elTable\"\n:data=\"tableData\"\n:stripe=\"stripe\"\n:border=\"border\"\n:fit=\"fit\"\n:show-header=\"showHeader\"\n:highlight-current-row=\"highlightCurrentRow\"\n:empty-text=\"emptyText\"\n:show-summary=\"showSummary\"\n:sum-text=\"sumText\"\n:summary-method=\"formatSummary\"\nheight=\"100%\"\n@row-click=\"handleRowClick\"\n@row-dblclick=\"handleDoubleRowClick\"\n@current-change=\"handleCurrentRowChange\"\n@sort-change=\"handleSortChange\"\n@selection-change=\"handleSelectionChange\"\n:size=\"size\" style=\"width: 100%;\">\n  <template v-if=\"showIndexColumn\">\n       <el-table-column type=\"index\"></el-table-column>\n  </template>\n  <template v-if=\"showSelectColumn\">\n       <el-table-column type=\"selection\"></el-table-column>\n  </template>\n  <template :key=\"item.key\" v-for=\"(item,index) in columns\">\n      <el-table-column\n        :sortable=\"item.sortable ? 'custom' : false\"\n        :column-key=\"item.key\"\n        :prop=\"item.dataColumnName\"\n        :show-overflow-tooltip=\"!!item.showOverflowTooltip\"\n        :width=\"item.width\"\n        :minWidth=\"item.minWidth\"\n        :resizable=\"!!item.resizable\"\n        :align=\"item.align\"\n        :formatter=\"handleFormatter\"\n        :filters=\"!!item.filter ? filters[item.dataColumnName] : undefined\"\n        :filter-method=\"!!item.filter ? columnFilter : undefined\"\n        :filter-multiple=\"!!item.filter && !!item.multipleFilter\"\n        :headerAlign=\"item.headerAlign\"\n        :label=\"item.label\">\n        <template #default=\"scope\">".concat(columnSlot, "</template>\n      </el-table-column>\n  </template>\n  <template v-if=\"showActionButtons\">\n       <el-table-column fixed=\"right\" :label=\"operationColumnName\" :width=\"operationColumnWidth\" headerAlign=\"center\">\n             <template #default=\"scope\">\n                <template v-for=\"(item,index) in actionButtons\">\n                    <template v-if=\"item.type === 'icon' && item.icon\">\n                        <el-icon\n                            v-if=\"item.isIconSvg\"\n                            v-html=\"item.icon.props.icon\"\n                            :title=\"item.Name\"\n                            :style=\"getOperateIconStyle(item)\"\n                            @click=\"handleActionClick(scope.row, item)\" />\n                        <el-image v-else\n                            class=\"el-icon\"\n                            fit=\"contain\"\n                            :src=\"item.icon.props.src\"\n                            :title=\"item.Name\"\n                            :style=\"getOperateIconStyle(item)\"\n                            @click=\"handleActionClick(scope.row, item)\" />\n                    </template>\n                    <el-button v-else-if=\"item.type === 'button'\"\n                        :size=\"getOperationButtonSize(item)\"\n                        class=\"fgc-el-table-opr-button\"\n                        :round=\"item.shape === 'round'\"\n                        :circle=\"item.shape === 'circle'\"\n                        @click=\"handleActionClick(scope.row, item)\"\n                        :icon=\"item.icon\" bg text\n                        :style=\"getOperationButtonStyle(item)\"\n                    >\n                        {{ item.Name }}\n                    </el-button>\n                    <el-link v-else\n                        :underline=\"false\"\n                        class=\"fgc-el-table-opr-link\"\n                        :style=\"getOperationLinkStyle(item)\"\n                        @click=\"handleActionClick(scope.row, item)\"\n                    >{{ item.Name }}</el-link>\n                </template>\n             </template>\n       </el-table-column>\n  </template>\n</el-table>"),
                data: function () {
                    var _a;
                    return {
                        tableData: undefined,
                        columns: cellType.columns,
                        border: !!cellType.border,
                        emptyText: cellType.emptyText,
                        fit: !!cellType.fit,
                        highlightCurrentRow: !!cellType.highlightCurrentRow,
                        showHeader: !!cellType.showHeader,
                        showIndexColumn: !!cellType.showIndexColumn,
                        showSelectColumn: !!cellType.showSelectColumn,
                        showActionButtons: !!cellType.showActionButtons,
                        actionButtons: cellType.actionButtons,
                        showSummary: !!cellType.showSummary,
                        size: cellType.size,
                        stripe: !!cellType.stripe,
                        sumText: undefined,
                        operationColumnName: cellType.operationColumnName,
                        operationColumnWidth: (_a = cellType.operationColumnWidth) !== null && _a !== void 0 ? _a : 200,
                        filters: {}
                    };
                },
                methods: {
                    GetUniqueKey: function (key) {
                        if (this.columns.some(function (x) { return x.key === key; })) {
                            return this.GetUniqueKey(key + "0");
                        }
                        return key;
                    },
                    setOptions: function (options) {
                        this.tableData = options;
                    },
                    handleFormatter: function (row, column, cellValue, index) {
                        var _a, _b;
                        if (column.columnKey && this.columnCache[column.columnKey] && ((_a = this.columnCache[column.columnKey]) === null || _a === void 0 ? void 0 : _a.formatStr)) {
                            var result = Forguncy.FormatHelper.format((_b = this.columnCache[column.columnKey]) === null || _b === void 0 ? void 0 : _b.formatStr, cellValue);
                            if (result) {
                                return result.text;
                            }
                        }
                        return cellValue;
                    },
                    handleRowClick: function (row) {
                        this.handleRowCommand(row, cellType.RowClickCommand);
                    },
                    handleActionClick: function (row, actionButton) {
                        var commands = actionButton.Commands;
                        if (commands) {
                            var initParam = {};
                            initParam[commands.ParamProperties["dataRow"]] = row;
                            self.executeCustomCommandObject(commands, initParam);
                        }
                    },
                    handleDoubleRowClick: function (row) {
                        this.handleRowCommand(row, cellType.RowDoubleClickCommand, "doubleClick");
                    },
                    handleCurrentRowChange: function (currentRow) {
                        this.handleRowCommand(currentRow, cellType.CurrentRowChangedCommand);
                    },
                    handleRowCommand: function (row, commands, eventType) {
                        if (commands) {
                            var initParam_1 = {};
                            initParam_1[commands.ParamProperties["dataRow"]] = row;
                            if (!self.isEmpty(cellType.bindingOptions)) {
                                this.columns.forEach(function (x, index) {
                                    initParam_1[x.dataColumnName + index] = row[x.dataColumnName];
                                });
                            }
                            self.executeCustomCommandObject(commands, initParam_1, eventType);
                        }
                    },
                    handleSelectionChange: function (selection) {
                        if (cellType.SelectionChangedCommand) {
                            var commands = cellType.SelectionChangedCommand;
                            var initParam = {};
                            initParam[commands.ParamProperties["selection"]] = selection;
                            self.executeCustomCommandObject(commands, initParam);
                        }
                    },
                    getOperateIconStyle: function (button) {
                        return {
                            cursor: "pointer",
                            margin: "3px 10px",
                            verticalAlign: "middle",
                            width: button.iconWidth + 'px',
                            height: button.iconHeight + 'px'
                        };
                    },
                    getOperationButtonStyle: function (button) {
                        var noFill = self.isEmpty(button.styleType);
                        return {
                            margin: '3px 10px',
                            backgroundColor: button.styleType,
                            color: noFill ? '#606266' : '#fff',
                            border: noFill ? '1px solid #dcdfe6' : "1px solid ".concat(button.styleType)
                        };
                    },
                    getOperationButtonSize: function (button) {
                        var sizeMap = {
                            large: "default",
                            default: "default",
                            small: "small"
                        };
                        return sizeMap[this.size];
                    },
                    getOperationLinkStyle: function (button) {
                        var noFill = self.isEmpty(button.styleType);
                        var fontSizeMap = {
                            large: "14px",
                            default: "14px",
                            small: "12px"
                        };
                        return {
                            margin: '3px 10px',
                            userSelect: 'none',
                            color: noFill ? "#606266" : button.styleType,
                            fontSize: fontSizeMap[this.size]
                        };
                    },
                    handleSortChange: function (data) {
                        var column = data.column, order = data.order;
                        if (column === null || order === null) {
                            self._orderParam = null;
                        }
                        else {
                            self._orderParam = {
                                ColumnName: column.property,
                                Order: order === "ascending" ? 0 /* Forguncy.Plugin.SqlOrder.ASC */ : 1 /* Forguncy.Plugin.SqlOrder.DESC */
                            };
                        }
                        self.queryElTable();
                    },
                    columnFilter: function (value, row, column) {
                        var property = column['property'];
                        return row[property] === value;
                    },
                    formatSummary: function (_a) {
                        var _this = this;
                        var columns = _a.columns, data = _a.data;
                        var summary = [];
                        columns.forEach(function (column, index) {
                            if (index === 0) {
                                summary[index] = _this.sumText;
                            }
                            else {
                                var values = data.map(function (x) { return x[column.property]; });
                                var columnSetting = _this.columns.find(function (x) { return x.label === column.label; });
                                if (self.isEmpty(columnSetting === null || columnSetting === void 0 ? void 0 : columnSetting.formatStr) && values.every(function (x) { return typeof x === "number" || self.isEmpty(x); })) {
                                    var total = values.reduce(function (x, y) { return self.isEmpty(y) ? x : x + y; }, 0);
                                    summary[index] = (isNaN(total) || total === 0) ? null : total;
                                }
                            }
                        });
                        return summary;
                    }
                },
                created: function () {
                    this.actionButtons.forEach(function (button) {
                        self.getIconComponent(button.icon, function (icon, result) {
                            button.icon = icon;
                            button.isIconSvg = result.isSvg;
                        });
                        button.styleType = Forguncy.ConvertToCssColor(button.styleType);
                    });
                },
                computed: {
                    columnCache: function (_a) {
                        var columns = _a.columns;
                        var result = {};
                        columns.forEach(function (x) {
                            result[x.key] = x;
                        });
                        return result;
                    }
                }
            };
            this.createVueApp(option);
            this.onDependenceCellValueChanged(function () {
                _this.queryElTable();
            });
            if (!this.IsElTablePaging()) {
                this.queryElTable();
            }
            this.onFormulaResultChanged(cellType.sumText, function (value) {
                _this.vue.sumText = value === null || value === void 0 ? void 0 : value.toString();
            });
            _super.prototype.onPageLoaded.call(this, info);
        };
        TableCellType.prototype.reload = function () {
            this.queryElTable();
        };
        TableCellType.prototype.IsElTablePaging = function () {
            var tableCellType = this.CellElement.CellType;
            if (this.isEmpty(tableCellType.ElTableName)) {
                return false;
            }
            var allCells = Forguncy.ForguncyData.pageInfo.pageElementManager.cells.getAllCells([this.runTimePageName]);
            var allElPagerCells = allCells === null || allCells === void 0 ? void 0 : allCells.filter(function (cell) { return cell.cellType instanceof ElementCellTypes.PaginationCellType; });
            return allElPagerCells.some(function (_a) {
                var cellType = _a.cellType;
                return cellType.cellType.ElementTableName === tableCellType.ElTableName;
            });
        };
        TableCellType.prototype.queryElTableTotalRecords = function () {
            var _this = this;
            var tableCellType = this.CellElement.CellType;
            return new Promise(function (resolve) {
                var option = { queryValueType: 3 /* Forguncy.Plugin.TableValueType.Count */ };
                _this.getBindingDataSourceValue(tableCellType.bindingOptions, option, function (total) {
                    resolve(total);
                });
            });
        };
        TableCellType.prototype.queryElTable = function () {
            return __awaiter(this, void 0, void 0, function () {
                var tableCellType, query, total;
                var _this = this;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            tableCellType = this.CellElement.CellType;
                            query = {};
                            if (this._orderParam) {
                                query.sort = true;
                                query.orderBySqlParams = [{ ColumnName: this._orderParam.ColumnName, Order: this._orderParam.Order }];
                            }
                            if (!this.pager) return [3 /*break*/, 2];
                            query.top = this.pager.pageSize;
                            query.offset = this.pager.pageSize * (this.pager.currentPage - 1);
                            query.pagerMode = true;
                            return [4 /*yield*/, this.queryElTableTotalRecords()];
                        case 1:
                            total = _a.sent();
                            this.pager.total = total;
                            _a.label = 2;
                        case 2:
                            this.getBindingDataSourceValue(tableCellType.bindingOptions, query, function (dataSource) {
                                _this.setDataSource(dataSource);
                                _this.SetColumnFilters(dataSource);
                            });
                            return [2 /*return*/];
                    }
                });
            });
        };
        TableCellType.prototype.SetColumnFilters = function (dataSource) {
            var _this = this;
            this.vue.filters = {};
            this.vue.columns.forEach(function (column) {
                var columnName = column.dataColumnName;
                var categories = dataSource.map(function (row) { return row[columnName]; });
                _this.vue.filters[columnName] = categories
                    .filter(function (ca, index) {
                    return categories.indexOf(ca) === index;
                })
                    .map(function (ca) {
                    var text = ca;
                    if (!_this.isEmpty(column.formatStr)) {
                        var result = Forguncy.FormatHelper.format(column.formatStr, ca);
                        if (result) {
                            text = result.text;
                        }
                    }
                    return { text: text, value: ca };
                });
            });
        };
        // RunTimeMethods
        TableCellType.prototype.SetJsonDataSource = function (json) {
            var cellType = this.CellElement.CellType;
            var data = this.evaluateFormula(json);
            if (typeof data === "string") {
                data = JSON.parse(data);
            }
            if (Array.isArray(data) && data.length > 0 && cellType.autoGenerateColumnsByDataSource) {
                var sample = data[0];
                if (this.isPlainObject(sample)) {
                    this.vue.columns = Object.keys(sample).map(function (columnName, index) {
                        return {
                            key: columnName + index,
                            label: columnName,
                            dataColumnName: columnName,
                            headerAlign: "center",
                            resizable: true
                        };
                    });
                }
            }
            this.setDataSource(data);
            this.SetColumnFilters(data);
        };
        TableCellType.prototype.SetTableColumnSetting = function (name, columnSetting) {
            var index = this.vue.columns.findIndex(function (x) { return x.dataColumnName === name; });
            if (index !== -1) {
                columnSetting.key = this.vue.GetUniqueKey(columnSetting.key);
                this.vue.columns[index] = __assign(__assign({}, this.vue.columns[index]), columnSetting);
            }
        };
        TableCellType.prototype.ClearSelection = function () {
            this.vue.$refs["elTable"].clearSelection();
        };
        TableCellType.prototype.SetCurrentRow = function (rowIndex) {
            if (this.isEmpty(rowIndex)) {
                this.vue.$refs["elTable"].setCurrentRow();
                return;
            }
            var index = Number(this.evaluateFormula(rowIndex));
            if (!isNaN(index) && index > 0 && this.vue.tableData.length >= index) {
                this.vue.$refs["elTable"].setCurrentRow(this.vue.tableData[index - 1]);
            }
        };
        TableCellType.prototype.GetSelectedRow = function () {
            return {
                SelectedRow: this.vue.$refs["elTable"].getSelectionRows()
            };
        };
        TableCellType.prototype.ResetTable = function (clearSort, clearFilter) {
            if (clearSort) {
                if (this._orderParam !== null) {
                    this.vue.$refs["elTable"].clearSort();
                    this._orderParam = null;
                }
            }
            if (clearFilter) {
                this.vue.$refs["elTable"].clearFilter();
            }
            this.queryElTable();
        };
        return TableCellType;
    }(ElementCellTypes.ElementCellTypeBase));
    ElementCellTypes.TableCellType = TableCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.TableCellType, ElementUI", ElementCellTypes.TableCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var TagCellType = /** @class */ (function (_super) {
        __extends(TagCellType, _super);
        function TagCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        TagCellType.prototype.getColor = function (color) {
            color = Forguncy.ConvertToCssColor(color);
            switch (this.cellType.effect) {
                case "dark":
                    return "#fff";
                case "light":
                    return color;
                case "plain":
                    return color;
                default:
            }
        };
        ;
        TagCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var cellType = this.cellType;
            var self = this;
            var colorList = cellType.ColorList;
            var marginBottom = "";
            var _a = this.CellElement.StyleInfo, WordWrap = _a.WordWrap, HorizontalAlignment = _a.HorizontalAlignment;
            if (WordWrap) {
                marginBottom = ",marginBottom:itemSpace+'px'";
            }
            this.fontSelector = [".el-tag__content", ".el-button-new-tag"];
            var html = '';
            for (var i = 0; i < colorList.length; i++) {
                var color = this.getColor(colorList[i % colorList.length].color);
                var isDark = this.cellType.effect === "dark";
                html += "#".concat(this.uId, " .fgc-tag-container-tag-").concat(i, "  svg {\n                             color: ").concat(color, ";\n                         }\n                         #").concat(this.uId, " .fgc-tag-container-tag-").concat(i, " svg:hover{\n                             color: #fff;\n                         }\n                         #").concat(this.uId, " .fgc-tag-container-tag-").concat(i, " .el-icon:hover{\n                             background-color: ").concat(!isDark ? color : Forguncy.ColorHelper.UpdateTint(color, 30, 128), ";\n                         }\n");
            }
            this.getStyleContainerElement("tags").innerHTML = html;
            var horizontalAlignmentClass = "fgc-flex-justify-content-" + ["left", "center", "right"][HorizontalAlignment];
            var template = "\n<el-scrollbar class=\"fgc-tag-scrollbar  ".concat(horizontalAlignmentClass, " ").concat(WordWrap ? 'fgc-tag-word-wrap' : '', "\">\n    <div class=\"fgc-tag-container\">\n            <el-tag\n                ref=\"tags\"\n                v-for=\"item in items\"\n                :key=\"item.key\"\n                :size=\"size\"\n                :effect=\"effect\"\n                :hit=\"hit\"\n                :closable=\"!disabled&&!readonly\"\n                :disableTransitions=\"disableTransitions\"\n                :class=\"item.class\"\n                @click=\"onClick\"\n                @close=\"onClose\"\n                :color=\"item.background\"\n                :style=\"{marginRight:item.itemSpace+'px'").concat(marginBottom, ",cursor:item.cursor, borderColor:item.border, color: item.color}\"\n                >\n                {{ item.label }}\n             </el-tag>\n            <el-input\n                  :maxlength=\"maxlength\"\n                  :placeholder=\"placeholder\" \n                  :size=\"addButtonSize\"\n                  class=\"el-input-new-tag\"\n                  v-if=\"inputVisible\"\n                  v-model=\"inputValue\"\n                  ref=\"saveTagInput\"\n                  @keyup.enter.native=\"handleInputConfirm\"\n                  @blur=\"handleInputConfirm\"\n                  :style=\"{display:!disabled&&!readonly&&allowAdd?'':'none', flexShrink:0,width:addButtonWidth+'px'").concat(marginBottom, "}\"\n                >\n            </el-input>\n            <el-button clickable=\"true\" :size=\"addButtonSize\" :style=\"{display:!disabled&&!readonly&&allowAdd?'':'none',flexShrink:0, width:addButtonWidth+'px'").concat(marginBottom, "}\" v-else class=\"el-button-new-tag\" @click=\"showInput\">{{addButtonText}}</el-button>\n    </div>\n</el-scrollbar>\n");
            var option = {
                template: template,
                data: function () {
                    return {
                        maxlength: cellType.addButtonSettings.InputMaxLength,
                        placeholder: cellType.addButtonSettings.InputPlaceHolder,
                        items: [],
                        size: cellType.size === "mini" ? "small" : cellType.size,
                        effect: cellType.effect,
                        hit: !!cellType.hit,
                        disabled: false,
                        readonly: false,
                        itemSpace: cellType.itemSpace,
                        allowAdd: cellType.allowAdd,
                        disableTransitions: !!cellType.disableTransitions,
                        inputVisible: false,
                        addButtonWidth: cellType.addButtonSettings.width,
                        addButtonText: "",
                        addButtonSize: this.getAddButtonSize(cellType.size),
                        inputValue: ''
                    };
                },
                methods: {
                    getValue: function () {
                        return this.items ? this.items.map(function (i) { return i.label; }).join(cellType.separator) : null;
                    },
                    setValue: function (value) {
                        var _this = this;
                        var hasAddButton = !this.readonly && !this.disabled && cellType.allowAdd;
                        if (value || value === 0) {
                            var strItems = (value + "").split(cellType.separator).filter(function (i) { return i !== ""; });
                            if (cellType.distinct) {
                                strItems = this.distinct(strItems);
                            }
                            this.items = strItems.map(function (value, index, array) {
                                var _a, _b;
                                return ({
                                    key: cellType.distinct ? value : index,
                                    label: value,
                                    class: "fgc-tag-container-tag-".concat(index % colorList.length),
                                    background: _this.getBackground(colorList[index % colorList.length].color),
                                    color: _this.getColor(colorList[index % colorList.length].color),
                                    border: _this.getBorder(colorList[index % colorList.length].color),
                                    itemSpace: index !== array.length - 1 ? cellType.itemSpace : (hasAddButton ? cellType.addButtonSettings.space : 0),
                                    cursor: ((_b = (_a = cellType.ClickCommand) === null || _a === void 0 ? void 0 : _a.Commands) === null || _b === void 0 ? void 0 : _b.length) ? "pointer" : ""
                                });
                            });
                        }
                        else {
                            this.items = [];
                        }
                    },
                    onClick: function (event) {
                        var _a, _b;
                        if ((_b = (_a = cellType.ClickCommand) === null || _a === void 0 ? void 0 : _a.Commands) === null || _b === void 0 ? void 0 : _b.length) {
                            var index = this.getEventIndex(event);
                            if (index >= 0) {
                                var initValue = {};
                                initValue[cellType.ClickCommand.ParamProperties["itemName"]] = this.items[index].label;
                                self.executeCustomCommandObject(cellType.ClickCommand, initValue);
                            }
                        }
                    },
                    onClose: function (event) {
                        var index = this.getEventIndex(event);
                        if (index >= 0) {
                            this.items.splice(index, 1);
                            self.commitValue();
                        }
                    },
                    getAddButtonSize: function (size) {
                        switch (size) {
                            case "large":
                                return "default";
                            default:
                                return "small";
                        }
                    },
                    getEventIndex: function (event) {
                        var clickItem = $(event.target, self.getContainer()).parents(".el-tag")[0];
                        var tags = $(".el-tag", self.getContainer());
                        for (var i = 0; i < tags.length; i++) {
                            var item = tags[i];
                            if (item === clickItem) {
                                return i;
                            }
                        }
                    },
                    distinct: function (arr) {
                        var result = [];
                        var obj = {};
                        for (var _i = 0, arr_1 = arr; _i < arr_1.length; _i++) {
                            var i = arr_1[_i];
                            if (obj[i]) {
                                continue;
                            }
                            obj[i] = true;
                            result.push(i);
                        }
                        return result;
                    },
                    getBorder: function (color) {
                        color = Forguncy.ConvertToCssColor(color);
                        if (this.hit) {
                            return color;
                        }
                        switch (this.effect) {
                            case "dark":
                                return color;
                            case "light":
                                return Forguncy.ColorHelper.UpdateTint(color, 0.8, 255);
                            case "plain":
                                return Forguncy.ColorHelper.UpdateTint(color, 0.6, 255);
                            default:
                        }
                    },
                    getColor: function (color) {
                        color = Forguncy.ConvertToCssColor(color);
                        switch (this.effect) {
                            case "dark":
                                return "#fff";
                            case "light":
                                return color;
                            case "plain":
                                return color;
                            default:
                        }
                    },
                    getBackground: function (color) {
                        color = Forguncy.ConvertToCssColor(color);
                        switch (this.effect) {
                            case "dark":
                                return color;
                            case "light":
                                return Forguncy.ColorHelper.UpdateTint(color, 0.9, 255);
                            case "plain":
                                return "#fff";
                            default:
                        }
                    },
                    showInput: function () {
                        var _this = this;
                        this.inputVisible = true;
                        this.$nextTick(function (_) {
                            _this.$refs.saveTagInput.$refs.input.focus();
                        });
                    },
                    handleInputConfirm: function () {
                        var inputValue = this.inputValue;
                        if (inputValue) {
                            var currentValue = this.getValue();
                            this.setValue(currentValue ? currentValue + cellType.separator + inputValue : inputValue);
                            self.commitValue();
                        }
                        this.inputVisible = false;
                        this.inputValue = '';
                    },
                    disable: function () {
                        this.disabled = true;
                    },
                    enable: function () {
                        this.disabled = false;
                    },
                    setReadOnly: function (value) {
                        this.readonly = value;
                    },
                }
            };
            this.createVueApp(option);
            this.onFormulaResultChanged(cellType.addButtonSettings.text, function (value) {
                var _a;
                _this.vue.addButtonText = (_a = value === null || value === void 0 ? void 0 : value.toString()) !== null && _a !== void 0 ? _a : "";
            });
            _super.prototype.onPageLoaded.call(this, info);
        };
        TagCellType.prototype.disable = function () {
            _super.prototype.disable.call(this);
            this.refreshClickable();
        };
        TagCellType.prototype.enable = function () {
            _super.prototype.enable.call(this);
            this.refreshClickable();
        };
        TagCellType.prototype.setReadOnly = function (value) {
            _super.prototype.setReadOnly.call(this, value);
            this.refreshClickable();
        };
        TagCellType.prototype.refreshClickable = function () {
            var _a, _b;
            (_a = this.getContainer()) === null || _a === void 0 ? void 0 : _a.attr("clickable", this.clickable() ? true : "");
            (_b = this.getContainer()) === null || _b === void 0 ? void 0 : _b.css("cursor", this.clickable() ? "default" : "");
        };
        TagCellType.prototype.clickable = function () {
            var _a;
            var cellType = this.cellType;
            return (!this.isReadOnly() && !this.isDisabled()) || (((_a = cellType === null || cellType === void 0 ? void 0 : cellType.ClickCommand) === null || _a === void 0 ? void 0 : _a.Commands) && cellType.ClickCommand.Commands.length > 0);
        };
        return TagCellType;
    }(ElementCellTypes.InputCellTypeBase));
    ElementCellTypes.TagCellType = TagCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.Tag, ElementUI", ElementCellTypes.TagCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var TimePickerCellType = /** @class */ (function (_super) {
        __extends(TimePickerCellType, _super);
        function TimePickerCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        TimePickerCellType.prototype.resolveTimeNumber = function (value) {
            return value < 10 ? "0".concat(value) : value;
        };
        TimePickerCellType.prototype.parseTime = function (value, needSeconds) {
            if (value === void 0) { value = 0; }
            if (needSeconds === void 0) { needSeconds = true; }
            var date = Forguncy.ConvertOADateToDate(value);
            var hours = date.getHours();
            var minutes = date.getMinutes();
            var seconds = date.getSeconds();
            var time = "".concat(this.resolveTimeNumber(hours), ":").concat(this.resolveTimeNumber(minutes));
            if (needSeconds) {
                time += ":" + this.resolveTimeNumber(seconds);
            }
            return { hours: hours, minutes: minutes, seconds: seconds, time: time };
        };
        TimePickerCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var self = this;
            var cellType = this.cellType;
            var CssClassName = this.CellElement.CssClassName;
            var popperClass = CssClassName ? "".concat(CssClassName, "-popper") : "";
            var rangeTemplate = "\n:is-range=\"true\"\n:range-separator=\"rangeSeparator\"\n:start-placeholder=\"startPlaceholder\"\n:end-placeholder=\"endPlaceholder\"\n";
            var pickerTemplate = "\n<el-time-picker v-model=\"input\"\n:clearable=\"clearable\"\n:disabled=\"disabled\"\n:editable=\"editable\"\n:placeholder=\"placeholder\"\n:prefix-icon=\"prefixIcon\"\n:format=\"format\"\n:disabled-hours=\"disabledHours\"\n:disabled-minutes=\"disabledMinutes\"\n:disabled-seconds=\"disabledSeconds\"\n:readonly=\"readOnly\"\npopper-class=\"".concat(popperClass, "\"\n").concat(cellType.isRange ? rangeTemplate : "", "\n@change=\"handleChange\"\n@blur=\"handleBlur\">\n</el-time-picker>");
            var selectTemplate = "\n<el-time-select v-model=\"input\"\n:clearable=\"clearable\"\n:disabled=\"disabled\"\n:editable=\"editable\"\n:step=\"step\"\n:start=\"start\"\n:end=\"end\"\n:placeholder=\"placeholder\"\n:prefix-icon=\"prefixIcon\"\npopper-class=\"".concat(popperClass, "\"\n@change=\"handleChange\"\n@blur=\"handleBlur\">\n</el-time-select>");
            var isSelect = cellType.mode === "select";
            var useTemplate = isSelect ? selectTemplate : pickerTemplate;
            this.addCustomClass(isSelect ? "el-time-select-custom" : "el-time-picker-custom");
            var _a = this.parseTime(cellType.StartTime), startTime = _a.time, startHour = _a.hours, startMinutes = _a.minutes, startSeconds = _a.seconds;
            var _b = this.parseTime(cellType.EndTime), endTime = _b.time, endHour = _b.hours, endMinutes = _b.minutes, endSeconds = _b.seconds;
            var option = {
                el: "#" + this.uId,
                template: useTemplate,
                data: function () {
                    return {
                        input: null,
                        clearable: this.boolConvertor(cellType.clearable),
                        disabled: cellType.IsDisabled,
                        editable: this.boolConvertor(cellType.editable),
                        readOnly: undefined,
                        placeholder: undefined,
                        prefixIcon: "",
                        rangeSeparator: undefined,
                        startPlaceholder: undefined,
                        endPlaceholder: undefined,
                        step: self.parseTime(cellType.step, false).time,
                        format: "HH:mm:ss",
                        start: startTime,
                        end: endTime
                    };
                },
                methods: {
                    handleChange: function () {
                        self.commitValue();
                        self.validate();
                    },
                    handleBlur: function () {
                        self.validate();
                    },
                    makeRange: function (start, end) {
                        var result = [];
                        for (var i = start; i <= end; i++) {
                            result.push(i);
                        }
                        return result;
                    },
                    disabledHours: function () {
                        return this.makeRange(0, startHour - 1).concat(this.makeRange(endHour + 1, 23));
                    },
                    disabledMinutes: function (hour) {
                        if (hour === startHour) {
                            return this.makeRange(0, startMinutes - 1);
                        }
                        if (hour === endHour) {
                            return this.makeRange(endMinutes + 1, 59);
                        }
                    },
                    disabledSeconds: function (hour, minute) {
                        if (hour === startHour && minute === startMinutes) {
                            return this.makeRange(0, startSeconds - 1);
                        }
                        if (hour === endHour && minute === endMinutes) {
                            return this.makeRange(endSeconds + 1, 59);
                        }
                    },
                    convertDateToOADate: function (value) {
                        var date = Forguncy.ConvertOADateToDate(0);
                        date.setHours(value.getHours());
                        date.setMinutes(value.getMinutes());
                        date.setSeconds(value.getSeconds());
                        return Forguncy.ConvertDateToOADate(date);
                    },
                    getValue: function () {
                        if (!this.input) {
                            return null;
                        }
                        if (cellType.isRange) {
                            return this.input.map(this.convertDateToOADate).join(",");
                        }
                        var inputIsDate = this.input instanceof Date;
                        return this.convertDateToOADate(inputIsDate ? this.input : new Date("1970/1/1 ".concat(this.input)));
                    },
                    setValue: function (value) {
                        var convertValueToInput = function () {
                            if (self.isEmpty(value)) {
                                return null;
                            }
                            if (cellType.mode === "select") {
                                return self.parseTime(value, false).time;
                            }
                            if (typeof value === "number") {
                                return Forguncy.ConvertOADateToDate(value);
                            }
                            if (typeof value === "string") {
                                var convertTimeToDateOptions_1 = { year: 1970, month: 0, day: 1 };
                                if (cellType.isRange) {
                                    return value.split(",").map(function (item) { return ElementCellTypes.DateUtil.ConverTimeToDate(item, convertTimeToDateOptions_1); });
                                }
                                return ElementCellTypes.DateUtil.ConverTimeToDate(value, convertTimeToDateOptions_1);
                            }
                            return value;
                        };
                        this.input = convertValueToInput();
                    },
                    disable: function () {
                        this.disabled = true;
                    },
                    enable: function () {
                        this.disabled = false;
                    },
                    setReadOnly: function (value) {
                        this.readOnly = value;
                    },
                    boolConvertor: function (value) {
                        return value ? true : false;
                    },
                },
                mounted: function () {
                    var _this = this;
                    self.fontDom = $("input", "#".concat(self.uId));
                    self.setFontToDom();
                    if (isSelect) {
                        var el = $(".select-trigger", "#".concat(self.uId));
                        if (el.length > 0) {
                            el[0].addEventListener("click", function (e) {
                                if (_this.readOnly) {
                                    e.stopImmediatePropagation();
                                }
                            });
                        }
                    }
                }
            };
            this.createVueApp(option);
            this.onFormulaResultChanged(cellType.placeholder, function (value) {
                _this.vue.placeholder = value === null || value === void 0 ? void 0 : value.toString();
            });
            this.onFormulaResultChanged(cellType.startPlaceholder, function (value) {
                _this.vue.startPlaceholder = value === null || value === void 0 ? void 0 : value.toString();
            });
            this.onFormulaResultChanged(cellType.endPlaceholder, function (value) {
                _this.vue.endPlaceholder = value === null || value === void 0 ? void 0 : value.toString();
            });
            this.onFormulaResultChanged(cellType.rangeSeparator, function (value) {
                _this.vue.rangeSeparator = value === null || value === void 0 ? void 0 : value.toString();
            });
            _super.prototype.onPageLoaded.call(this, info);
            _super.prototype.getIconComponent.call(this, cellType.prefixIcon, function (icon) { return _this.vue.prefixIcon = icon; });
        };
        TimePickerCellType.prototype.GetSelectedRange = function () {
            var value = this.vue.input;
            var _a = value instanceof Array ? value : [], startDaTe = _a[0], endDate = _a[1];
            return {
                StartValue: Forguncy.ConvertDateToOADate(startDaTe) - Math.floor(Forguncy.ConvertDateToOADate(startDaTe)),
                EndValue: Forguncy.ConvertDateToOADate(endDate) - Math.floor(Forguncy.ConvertDateToOADate(endDate)),
            };
        };
        return TimePickerCellType;
    }(ElementCellTypes.InputCellTypeBase));
    ElementCellTypes.TimePickerCellType = TimePickerCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.TimePickerCellType, ElementUI", ElementCellTypes.TimePickerCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var TimelinePlacement;
    (function (TimelinePlacement) {
        TimelinePlacement[TimelinePlacement["top"] = 0] = "top";
        TimelinePlacement[TimelinePlacement["bottom"] = 1] = "bottom";
    })(TimelinePlacement || (TimelinePlacement = {}));
    function formatDate(date, fmt) {
        var o = {
            "M+": date.getMonth() + 1,
            "D+": date.getDate(),
            "d+": date.getDate(),
            "H+": date.getHours(),
            "m+": date.getMinutes(),
            "s+": date.getSeconds(),
            "q+": Math.floor((date.getMonth() + 3) / 3),
            "S": date.getMilliseconds()
        };
        if (/(y+)/.test(fmt)) {
            fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
        }
        ;
        for (var k in o) {
            if (new RegExp("(" + k + ")").test(fmt)) {
                fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
            }
        }
        return fmt;
    }
    var TimelineCellType = /** @class */ (function (_super) {
        __extends(TimelineCellType, _super);
        function TimelineCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        TimelineCellType.prototype.setDataSource = function (dataSource) {
            return this.vue.setOptions(dataSource);
        };
        TimelineCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var cellType = this.cellType;
            var self = this;
            var option = {
                el: "#" + this.uId,
                template: "<el-scrollbar>\n                                <el-timeline>\n                                    <el-timeline-item\n                                         v-for=\"(activity, index) in activities\"\n                                         :key=\"index\"\n                                         :timestamp=\"activity.timestamp\"\n                                         :icon=\"activity.iconComponent\"\n                                         :color=\"activity.color\"\n                                         :size=\"nodeSize\"\n                                         :hide-timestamp=\"hideTimestamp\"\n                                         :placement=\"placement\"\n                                         >\n                                      {{activity.content}}\n                                    </el-timeline-item>\n                                 </el-timeline>\n                            </el-scrollbar>\n                          ",
                data: function () {
                    return {
                        activities: [],
                        hideTimestamp: cellType.hideTimestamp,
                        placement: TimelinePlacement[cellType.placement],
                        nodeSize: cellType.NodeSize
                    };
                },
                methods: {
                    getValue: function () {
                        return this.active;
                    },
                    setValue: function (value) {
                        this.active = value;
                    },
                    sort: function (type, a, b) {
                        var value1 = a.timestamp;
                        if (typeof (a.timestamp) === "string") {
                            value1 = new Date(a.timestamp);
                        }
                        var value2 = b.timestamp;
                        if (typeof (b.timestamp) === "string") {
                            value2 = new Date(b.timestamp);
                        }
                        return type === "ascTimestamp" ? value1 - value2 : value2 - value1;
                    },
                    formatOption: function (option) {
                        var timestamp = option.timestamp, color = option.color;
                        var isNumber = typeof (timestamp) === "number" || !isNaN(Number(timestamp));
                        var getDate = function (isOADate) {
                            if (isOADate === void 0) { isOADate = true; }
                            if (isOADate) {
                                var date_1 = Forguncy.ConvertOADateToDate(timestamp);
                                var isInvalidDate = isNaN(date_1.getTime());
                                return isInvalidDate ? getDate(false) : date_1;
                            }
                            var dateString = isNumber ? Number(timestamp) : timestamp === null || timestamp === void 0 ? void 0 : timestamp.replace(/-/g, "/");
                            return new Date(dateString);
                        };
                        var date = getDate();
                        var newTimestamp = self.isValidDate(date)
                            ? formatDate(date, cellType.format || "yyyy/MM/dd")
                            : timestamp;
                        return __assign(__assign({}, option), { timestamp: newTimestamp, color: Forguncy.ConvertToCssColor(color) });
                    },
                    setOptions: function (options) {
                        var activities = options.map(this.formatOption);
                        this.activities = cellType.sort === "default" ? activities : activities.sort(this.sort.bind(this, cellType.sort));
                        self.recalcIcon();
                    },
                }
            };
            this.createVueApp(option);
            if (cellType.useBinding) {
                ElementCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (dataSource) { return _this.setDataSource(dataSource); });
            }
            else {
                this.vue.setOptions(cellType.options);
            }
            self.recalcIcon();
        };
        TimelineCellType.prototype.recalcIcon = function () {
            var _loop_6 = function (i) {
                var option = this_3.vue.activities[i];
                var icon = option === null || option === void 0 ? void 0 : option.icon;
                this_3.getIconComponent(icon, function (icon) { return option.iconComponent = icon; });
            };
            var this_3 = this;
            for (var i = 0; i < this.vue.activities.length; i++) {
                _loop_6(i);
            }
        };
        TimelineCellType.prototype.ReloadBindingItems = function () {
            var _this = this;
            var cellType = this.cellType;
            if (cellType.useBinding) {
                ElementCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (dataSource) { return _this.setDataSource(dataSource); });
            }
        };
        TimelineCellType.prototype.reload = function () {
            this.ReloadBindingItems();
        };
        TimelineCellType.prototype.SetDataSource = function (dataSource, contentProperty, timestempProperty) {
            if (!dataSource) {
                dataSource = [];
            }
            if (typeof dataSource === "string") {
                dataSource = JSON.parse(dataSource);
            }
            var objSource = dataSource.map(function (i) { return ({
                "content": i[contentProperty],
                "timestamp": i[timestempProperty],
            }); });
            this.setDataSource(objSource);
        };
        return TimelineCellType;
    }(ElementCellTypes.ElementCellTypeBase));
    ElementCellTypes.TimelineCellType = TimelineCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.TimelineCellType, ElementUI", ElementCellTypes.TimelineCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var TransferTargetOrder;
    (function (TransferTargetOrder) {
        TransferTargetOrder[TransferTargetOrder["original"] = 0] = "original";
        TransferTargetOrder[TransferTargetOrder["push"] = 1] = "push";
        TransferTargetOrder[TransferTargetOrder["unshift"] = 2] = "unshift";
    })(TransferTargetOrder || (TransferTargetOrder = {}));
    var TransferCellType = /** @class */ (function (_super) {
        __extends(TransferCellType, _super);
        function TransferCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        TransferCellType.prototype.setDataSource = function (dataSource) {
            return this.vue.setOptions(dataSource);
        };
        TransferCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var cellType = this.cellType;
            var containerId = "".concat(this.uId, "-el-transfer");
            var self = this;
            var formatData = function (data) {
                if (data === void 0) { data = []; }
                return data.map(function (_a) {
                    var _b;
                    var key = _a.key, label = _a.label, _c = _a.disabled, disabled = _c === void 0 ? false : _c;
                    return ({
                        label: (_b = _this.format(label)) === null || _b === void 0 ? void 0 : _b.toString(),
                        key: key === null || key === void 0 ? void 0 : key.toString(),
                        disabled: !!disabled
                    });
                });
            };
            this.addCustomClass("fgc-el-transfer");
            var option = {
                template: "<div id=\"".concat(containerId, "\" style=\"width: 100%;height: 100%;overflow: auto\">\n                                <el-transfer\n                                     v-model=\"value\"\n                                     :titles=\"titles\"\n                                     :data=\"data\"\n                                     :filterable=\"filterable\"\n                                     :filter-placeholder=\"filterPlaceholder\"\n                                     :target-order=\"targetOrder\"\n                                     @change=\"handleChange\"\n                                     :render-content=\"renderContent\"\n                                 />\n                            </div>\n                          "),
                data: function () {
                    return {
                        value: [],
                        titles: ["", ""],
                        filterable: !!cellType.filterable,
                        filterPlaceholder: undefined,
                        data: cellType.useBinding ? [] : formatData(cellType.options),
                        targetOrder: TransferTargetOrder[cellType.targetOrder]
                    };
                },
                methods: {
                    getValue: function () {
                        if (this.value instanceof Array) {
                            return this.value.join(",");
                        }
                        return this.value;
                    },
                    setValue: function (value) {
                        var _this = this;
                        var list = [];
                        if (value instanceof Array) {
                            list = value;
                        }
                        else {
                            list = typeof value === "string" ? value.split(",") : [value];
                        }
                        this.value = list.filter(function (item) { return _this.data.find(function (_a) {
                            var key = _a.key;
                            return key === item;
                        }); });
                    },
                    setOptions: function (options) {
                        this.data = formatData(options);
                    },
                    handleChange: function () {
                        var _this = this;
                        var _a;
                        this.value = (_a = this.value) === null || _a === void 0 ? void 0 : _a.filter(function (val) { return _this.data.find(function (_a) {
                            var key = _a.key;
                            return key === val;
                        }); });
                        self.commitValue();
                    },
                    renderContent: function (h, option) {
                        return self.customRender(h, option);
                    }
                }
            };
            this.createVueApp(option);
            if (cellType.useBinding) {
                ElementCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (dataSource) { return _this.setDataSource(dataSource); });
            }
            this.onFormulaResultChanged(cellType.filterPlaceholder, function (value) {
                var _a;
                _this.vue.filterPlaceholder = (_a = value === null || value === void 0 ? void 0 : value.toString()) !== null && _a !== void 0 ? _a : " ";
            });
            this.onFormulaResultChanged(cellType.leftTitle, function (value) {
                _this.vue.titles = [value === null || value === void 0 ? void 0 : value.toString(), _this.vue.titles[1]];
            });
            this.onFormulaResultChanged(cellType.rightTitle, function (value) {
                _this.vue.titles = [_this.vue.titles[0], value === null || value === void 0 ? void 0 : value.toString()];
                ;
            });
            _super.prototype.onPageLoaded.call(this, info);
        };
        TransferCellType.prototype.ReloadBindingItems = function () {
            var _this = this;
            var cellType = this.CellElement.CellType;
            if (cellType.useBinding) {
                ElementCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (dataSource) { return _this.setDataSource(dataSource); });
            }
        };
        TransferCellType.prototype.reload = function () {
            this.ReloadBindingItems();
        };
        TransferCellType.prototype.customRender = function (h, option) {
            return h("span", option.label);
        };
        return TransferCellType;
    }(ElementCellTypes.InputCellTypeBase));
    ElementCellTypes.TransferCellType = TransferCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.TransferCellType, ElementUI", ElementCellTypes.TransferCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var TreeCellType = /** @class */ (function (_super) {
        __extends(TreeCellType, _super);
        function TreeCellType() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this._dataSourceFirstLoaded = false;
            return _this;
        }
        TreeCellType.prototype.onPageLoaded = function (info) {
            var self = this;
            var cellTypeParam = this.cellType;
            var options = [];
            if (!cellTypeParam.isTreeNodeFromDb && cellTypeParam.configTreeNodeOptions) {
                options = cellTypeParam.configTreeNodeOptions;
            }
            var nodeSlot = this.getCustomSlotByPath(ElementCellTypes.SlotPath.treeNode);
            var vueOption = {
                template: "\n<el-scrollbar>\n    <el-tree\n        ref=\"treeRef\"\n        :data=\"options\"\n        :empty-text=\"emptyText\"\n        :show-checkbox=\"isMultiSelection\"\n        :check-on-click-node=\"isCheckedByCheckbox\"\n        :default-expand-all=\"isDefaultExpandAll\"\n        :expand-on-click-node=\"isClickCanExpandNode\"\n        :accordion=\"isOnlyExpandOneLevel\"\n        :highlight-current=\"isHighlightCurrent\"\n        :check-strictly=\"isCheckStrictly\"\n        :draggable=\"isDraggable\"\n        node-key=\"value\"\n        @node-click=\"handleNodeClick\"\n        @check=\"handleCurrentChange\"\n        @node-drop=\"handleNodeDrop\">\n        <template #default=\"scope\">\n            ".concat(nodeSlot || self.getDefaultTreeNodeSlot(), "\n        </template>\n    </el-tree>\n</el-scrollbar>"),
                data: function () {
                    var _a, _b, _c, _d, _e, _f, _g, _h;
                    return {
                        emptyText: '',
                        isMultiSelection: (_a = cellTypeParam.isMultiSelection) !== null && _a !== void 0 ? _a : false,
                        isCheckedByCheckbox: (_b = cellTypeParam.isCheckedByCheckbox) !== null && _b !== void 0 ? _b : false,
                        isDefaultExpandAll: (_c = cellTypeParam.isDefaultExpandAll) !== null && _c !== void 0 ? _c : false,
                        isClickCanExpandNode: (_d = cellTypeParam.isClickCanExpandNode) !== null && _d !== void 0 ? _d : false,
                        isOnlyExpandOneLevel: (_e = cellTypeParam.isOnlyExpandOneLevel) !== null && _e !== void 0 ? _e : false,
                        isHighlightCurrent: (_f = cellTypeParam.isHighlightCurrent) !== null && _f !== void 0 ? _f : false,
                        isCheckStrictly: (_g = cellTypeParam.isCheckStrictly) !== null && _g !== void 0 ? _g : false,
                        isDraggable: (_h = cellTypeParam.isDraggable) !== null && _h !== void 0 ? _h : false,
                        value: new Set(),
                        options: options,
                        isFromClick: false,
                        isDisabled: false,
                    };
                },
                methods: {
                    reload: function () {
                        self.ReloadBinding();
                    },
                    handleNodeClick: function (nodeData, nodeObj) {
                        this.executeClickCommand(nodeData, nodeObj.parent.data);
                        if (!this.isMultiSelection) {
                            // 单选模式不会触发 handleCurrentChange 事件，会导致 this.value 不被修改
                            // 因此需要额外处理一遍 value
                            this.value = new Set();
                            this.value.add(nodeData.value);
                        }
                        self.commitValue();
                    },
                    handleCurrentChange: function (nodeData, treeStatus) {
                        var _this = this;
                        var checkedKeys = treeStatus.checkedKeys, halfCheckedKeys = treeStatus.halfCheckedKeys;
                        if (!this.isCheckStrictly) {
                            var childValueSet = new Set();
                            this.flatNodesRecursively(nodeData, childValueSet);
                            if (checkedKeys.includes(nodeData.value)) {
                                childValueSet.forEach(function (v) { return _this.value.add(v); });
                            }
                            else {
                                childValueSet.forEach(function (v) { return _this.value.delete(v); });
                            }
                        }
                        else {
                            if (!checkedKeys.includes(nodeData.value)) {
                                this.value.delete(nodeData.value);
                            }
                        }
                        checkedKeys === null || checkedKeys === void 0 ? void 0 : checkedKeys.forEach(function (v) { return _this.value.add(v); });
                        halfCheckedKeys === null || halfCheckedKeys === void 0 ? void 0 : halfCheckedKeys.forEach(function (v) { return _this.value.delete(v); });
                        this.isFromClick = true;
                        self.commitValue();
                    },
                    flatNodesRecursively: function (nodeData, result) {
                        if (!nodeData) {
                            return;
                        }
                        result.add(nodeData.value);
                        if (nodeData.children) {
                            for (var _i = 0, _a = nodeData.children; _i < _a.length; _i++) {
                                var child = _a[_i];
                                this.flatNodesRecursively(child, result);
                            }
                        }
                    },
                    handleNodeDrop: function (draggingObj, dropObj, dropType) {
                        this.executeDragCommand(draggingObj.data, dropObj.data, dropType);
                    },
                    executeClickCommand: function (node, pNode) {
                        var command = cellTypeParam.clickCommand;
                        if (!command) {
                            return;
                        }
                        var initValue = this.buildCommandParam(command, node, pNode);
                        self.executeCustomCommandObject(command, initValue, "click");
                    },
                    executeSelectCommand: function (node, pNode) {
                        var command = cellTypeParam.selectCommand;
                        if (!command) {
                            return;
                        }
                        var initValue = this.buildCommandParam(command, node, pNode);
                        self.executeCustomCommandObject(command, initValue, "select");
                    },
                    executeMultiSelectCommand: function (treeNodeInfos) {
                        var command = cellTypeParam.multiSelectCommand;
                        if (!command) {
                            return;
                        }
                        var initParam = this.buildMultiSelectCommandParam(command, treeNodeInfos);
                        self.executeCustomCommandObject(command, initParam, "select");
                    },
                    executeDragCommand: function (draggingNode, dropNode, type) {
                        var command = cellTypeParam.dragCommand;
                        if (!command) {
                            return;
                        }
                        var initValue = this.buildDragCommandParam(command, draggingNode, dropNode, type);
                        self.executeCustomCommandObject(command, initValue, "drag");
                    },
                    buildCommandParam: function (command, node, pNode) {
                        var _a;
                        var _b, _c, _d;
                        var _e = command.ParamProperties, value = _e.value, label = _e.label, parentValue = _e.parentValue;
                        var others = (_d = (_c = (_b = self.cellType) === null || _b === void 0 ? void 0 : _b.bindingDataSource) === null || _c === void 0 ? void 0 : _c.CustomColumns) !== null && _d !== void 0 ? _d : [];
                        var initParam = (_a = {},
                            _a[value] = node === null || node === void 0 ? void 0 : node.value,
                            _a[label] = node === null || node === void 0 ? void 0 : node.label,
                            _a[parentValue] = pNode === null || pNode === void 0 ? void 0 : pNode.value,
                            _a);
                        for (var _i = 0, others_1 = others; _i < others_1.length; _i++) {
                            var othersKey = others_1[_i];
                            initParam[othersKey] = node[othersKey];
                        }
                        return initParam;
                    },
                    buildMultiSelectCommandParam: function (command, treeNodeInfos) {
                        var _a;
                        var _b, _c, _d, _e;
                        var resultArray = command.ParamProperties.resultArray;
                        var resultArrayValue = [];
                        var others = (_d = (_c = (_b = self.cellType) === null || _b === void 0 ? void 0 : _b.bindingDataSource) === null || _c === void 0 ? void 0 : _c.CustomColumns) !== null && _d !== void 0 ? _d : [];
                        for (var _i = 0, treeNodeInfos_1 = treeNodeInfos; _i < treeNodeInfos_1.length; _i++) {
                            var treeNodeInfo = treeNodeInfos_1[_i];
                            var item = {
                                "value": treeNodeInfo.cur.value,
                                "label": treeNodeInfo.cur.label,
                                "parentValue": (_e = treeNodeInfo.parent) === null || _e === void 0 ? void 0 : _e.value,
                            };
                            for (var _f = 0, others_2 = others; _f < others_2.length; _f++) {
                                var othersKey = others_2[_f];
                                item[othersKey] = treeNodeInfo.cur[othersKey];
                            }
                            resultArrayValue.push(item);
                        }
                        return _a = {},
                            _a[resultArray] = resultArrayValue,
                            _a;
                    },
                    buildDragCommandParam: function (command, draggingNode, dropNode, type) {
                        var _a;
                        var _b = command.ParamProperties, draggingNodeValue = _b.draggingNodeValue, dropNodeValue = _b.dropNodeValue, dragType = _b.dragType, others = __rest(_b, ["draggingNodeValue", "dropNodeValue", "dragType"]);
                        // bugx-22177：确定，删除自定义属性
                        return _a = {},
                            _a[draggingNodeValue] = draggingNode === null || draggingNode === void 0 ? void 0 : draggingNode.value,
                            _a[dropNodeValue] = dropNode === null || dropNode === void 0 ? void 0 : dropNode.value,
                            _a[dragType] = type,
                            _a;
                    },
                    getValue: function () {
                        var _a;
                        if (!this.isMultiSelection) {
                            return (_a = Array.from(this.value)[0]) !== null && _a !== void 0 ? _a : null;
                        }
                        return Array.from(this.value).join(",");
                    },
                    setValue: function (value) {
                        var _this = this;
                        if (!this.isMultiSelection) {
                            // 优先处理单选模式
                            if (!value) {
                                this.cleanSelection();
                            }
                            else {
                                var splitArr = value.toString().split(',');
                                var certainValue = "0";
                                if (splitArr.length > 1) {
                                    // 说明传入了一个逗号分割的字符串，那么应该获取第一项
                                    certainValue = splitArr[0];
                                }
                                else {
                                    certainValue = value.toString();
                                }
                                self.SetCurrentNode(certainValue);
                                var node = this.$refs.treeRef.getCurrentNode();
                                var parentNode = this.findParentNodeRecursively(this.options, node.value);
                                this.executeSelectCommand(node, parentNode);
                            }
                            this.isFromClick = false;
                            return;
                        }
                        // 多选模式
                        if (!value) {
                            // 值不存在
                            this.cleanSelection();
                            if (this.isFromClick) {
                                this.executeMultiSelectCommand([]);
                            }
                            this.isFromClick = false;
                            return;
                        }
                        // 多选模式且值存在
                        var treeNodeInfos = [];
                        if (!this.isFromClick) {
                            // 设置的值有可能和当前的值不一致，需要进行判断
                            var newValueSet_1 = new Set();
                            var oldValueSet_1 = new Set();
                            var compareSet_1 = new Set(Array.from(this.value).map(toString));
                            var splitArr = value.toString().split(',');
                            splitArr.forEach(function (v) {
                                if (!compareSet_1.has(v)) {
                                    newValueSet_1.add(v);
                                }
                                else {
                                    oldValueSet_1.add(v);
                                }
                            });
                            if (newValueSet_1.size) {
                                // 查找合法值
                                var newValueArr = Array.from(newValueSet_1);
                                var checkedSet = new Set(newValueArr);
                                this.buildValidSelectedNodesRecursively(this.options, treeNodeInfos, newValueArr, checkedSet);
                                if (treeNodeInfos.length) {
                                    self.SetSelectedNodes(false, treeNodeInfos.map(function (p) { return p.cur.value; }).join(','));
                                    treeNodeInfos.forEach(function (v) { return _this.value.add(v.cur.value); });
                                }
                                else {
                                    // 说明 新值 全部都不合法
                                    if (oldValueSet_1.size) {
                                        this.value = oldValueSet_1;
                                    }
                                    else {
                                        this.cleanSelection();
                                    }
                                }
                            }
                        }
                        if (!treeNodeInfos.length) {
                            // 没有新值输入，则使用现有记录的值构建
                            var newValueArr = Array.from(this.value);
                            var checkedSet = new Set(newValueArr);
                            this.buildValidSelectedNodesRecursively(this.options, treeNodeInfos, newValueArr, checkedSet);
                        }
                        this.isFromClick = false;
                        // 触发多选值变更命令
                        this.executeMultiSelectCommand(treeNodeInfos);
                    },
                    buildValidSelectedNodesRecursively: function (treeNodes, treeNodeInfos, newValueArr, checkedSet, parentNode) {
                        if (!treeNodes || !treeNodes.length) {
                            return;
                        }
                        for (var _i = 0, treeNodes_1 = treeNodes; _i < treeNodes_1.length; _i++) {
                            var treeNode = treeNodes_1[_i];
                            for (var _a = 0, newValueArr_1 = newValueArr; _a < newValueArr_1.length; _a++) {
                                var selectedValue = newValueArr_1[_a];
                                if (treeNode.value == selectedValue) {
                                    treeNodeInfos.push({
                                        cur: treeNode,
                                        parent: parentNode
                                    });
                                    checkedSet.add(treeNode.value.toString());
                                }
                            }
                            if (!this.isCheckStrictly && parentNode && checkedSet.has(parentNode.value) && !checkedSet.has(treeNode.value.toString())) {
                                // 如果不允许选中每个节点，则勾选了父节点肯定要勾选子节点
                                treeNodeInfos.push({
                                    cur: treeNode,
                                    parent: parentNode
                                });
                                checkedSet.add(treeNode.value.toString());
                            }
                            this.buildValidSelectedNodesRecursively(treeNode.children, treeNodeInfos, newValueArr, checkedSet, treeNode);
                        }
                    },
                    setOptions: function (dataSource) {
                        var _this = this;
                        if (self._dataSourceFirstLoaded === false) {
                            self._dataSourceFirstLoaded = true;
                            self.onFormulaResultChanged(self.cellType.emptyText, function (value) {
                                _this.emptyText = value === null || value === void 0 ? void 0 : value.toString();
                            });
                        }
                        this.options = dataSource;
                        self.resolveIconRecursively(dataSource, self);
                        self.SetSelectedNodes(false, Array.from(this.value).join(","));
                    },
                    findNodeByValueRecursively: function (treeNodes, value) {
                        if (!treeNodes) {
                            return null;
                        }
                        for (var _i = 0, treeNodes_2 = treeNodes; _i < treeNodes_2.length; _i++) {
                            var node = treeNodes_2[_i];
                            if (node.value == value) {
                                return node;
                            }
                            if (node.children) {
                                var result = this.findNodeByValueRecursively(node.children, value);
                                if (result) {
                                    return result;
                                }
                            }
                        }
                        return null;
                    },
                    findParentNodeRecursively: function (treeNodes, value) {
                        if (!treeNodes) {
                            return null;
                        }
                        for (var _i = 0, treeNodes_3 = treeNodes; _i < treeNodes_3.length; _i++) {
                            var node = treeNodes_3[_i];
                            if (!node.children) {
                                continue;
                            }
                            for (var _a = 0, _b = node.children; _a < _b.length; _a++) {
                                var child = _b[_a];
                                if (child.value == value) {
                                    return node;
                                }
                            }
                            var result = this.findParentNodeRecursively(node.children, value);
                            if (result) {
                                return result;
                            }
                        }
                        return null;
                    },
                    cleanSelection: function () {
                        if (!this.options) {
                            return;
                        }
                        this.value = new Set();
                        for (var _i = 0, _a = this.options; _i < _a.length; _i++) {
                            var treeNode = _a[_i];
                            this.$refs.treeRef.setChecked(treeNode.value, false, true);
                        }
                    }
                }
            };
            this.createVueApp(vueOption);
            this.ReloadBinding();
            _super.prototype.onPageLoaded.call(this, info);
            self.resolveIconRecursively(self.vue.options, self);
        };
        TreeCellType.prototype.getDefaultTreeNodeSlot = function () {
            return "<div class=\"custom-node\" style=\"display: flex; align-items: center;\">\n              <el-icon v-if=\"scope.node.data.svgIcon\" v-html=\"scope.node.data.svgIcon\"></el-icon>\n              <el-image v-if=\"scope.node.data.iconSrc\" class=\"el-icon\" fit=\"contain\" :src=\"scope.node.data.iconSrc\"></el-image>\n              <span class=\"el-tree-node__label\">&nbsp;{{scope.node.data.label}}</span>\n            </div>";
        };
        TreeCellType.prototype.setDataSource = function (dataSource) {
            this.setCheckboxDisabledRecursively(dataSource);
            return this.vue.setOptions(dataSource);
        };
        TreeCellType.prototype.setArrayDataSource = function (dataSource) {
            var _a;
            var treeNodes = (_a = ElementCellTypes.TreeHelper.build(dataSource)) !== null && _a !== void 0 ? _a : [];
            this.setDataSource(treeNodes);
        };
        TreeCellType.prototype.resolveIconRecursively = function (options, cellType) {
            if (!options) {
                return;
            }
            var _loop_7 = function (treeNode) {
                if (treeNode && treeNode.icon) {
                    cellType.getIcon(treeNode.icon, function (icon) {
                        if (icon.isSvg) {
                            treeNode.svgIcon = icon.icon;
                        }
                        else {
                            treeNode.iconSrc = icon.icon;
                        }
                    });
                }
                if (treeNode.children) {
                    this_4.resolveIconRecursively(treeNode.children, cellType);
                }
            };
            var this_4 = this;
            for (var _i = 0, options_2 = options; _i < options_2.length; _i++) {
                var treeNode = options_2[_i];
                _loop_7(treeNode);
            }
        };
        TreeCellType.prototype.setCheckboxDisabledRecursively = function (options) {
            if (!options) {
                return;
            }
            for (var _i = 0, options_3 = options; _i < options_3.length; _i++) {
                var treeNode = options_3[_i];
                if (treeNode) {
                    treeNode["disabled"] = this.vue.isDisabled;
                }
                if (treeNode.children) {
                    this.setCheckboxDisabledRecursively(treeNode.children);
                }
            }
        };
        TreeCellType.prototype.reload = function () {
            var _this = this;
            if (!this.cellType.isTreeNodeFromDb) {
                return;
            }
            ElementCellTypes.SupportDataSourceCellType.refreshData(this, this.cellType.bindingDataSource, function (dataSource) { return _this.setArrayDataSource(dataSource); });
        };
        TreeCellType.prototype.SetDataSourceByObjTree = function (dataSource, valueProperty, labelProperty, iconProperty, childrenProperty) {
            if (typeof dataSource === "string") {
                dataSource = JSON.parse(dataSource);
            }
            var buildTreeNodesRecursively = function (data) {
                if (!data) {
                    return [];
                }
                var result = [];
                data.forEach(function (item) {
                    var node = __assign(__assign({}, item), { label: item[labelProperty], value: item[valueProperty], icon: item[iconProperty], children: buildTreeNodesRecursively(item[childrenProperty]) });
                    result.push(node);
                });
                return result;
            };
            this.setDataSource(buildTreeNodesRecursively(dataSource));
        };
        TreeCellType.prototype.SetDataSourceByIdPidTable = function (dataSource, valueProperty, labelProperty, iconProperty, parentValue) {
            if (typeof dataSource === "string") {
                dataSource = JSON.parse(dataSource);
            }
            var arrayNodes = dataSource.map(function (item) {
                return __assign(__assign({}, item), { label: item[labelProperty], value: item[valueProperty], icon: item[iconProperty], children: null, parentValue: item[parentValue] });
            });
            this.setArrayDataSource(arrayNodes);
        };
        TreeCellType.prototype.GetSelectedNodes = function (isLeafOnly, isContainsHalf) {
            var result = {
                Result: null
            };
            var selectedNodes = this.vue.$refs.treeRef.getCheckedNodes(isLeafOnly, isContainsHalf);
            if (selectedNodes) {
                result.Result = selectedNodes.map(function (p) { return p.value; });
            }
            return result;
        };
        TreeCellType.prototype.SetSelectedNodes = function (isLeafOnly, selectedIndexes) {
            if (!selectedIndexes) {
                return;
            }
            var selectedIndexArr = selectedIndexes.split(',');
            if (!selectedIndexArr) {
                return;
            }
            this.vue.$refs.treeRef.setCheckedKeys(selectedIndexArr, isLeafOnly);
        };
        TreeCellType.prototype.GetCurrentNode = function () {
            var result = {
                Result: null
            };
            var currentNode = this.vue.$refs.treeRef.getCurrentNode();
            if (currentNode) {
                result.Result = currentNode.value;
            }
            return result;
        };
        TreeCellType.prototype.SetCurrentNode = function (currentNodeValue) {
            if (!currentNodeValue) {
                return;
            }
            this.vue.$refs.treeRef.setCurrentKey(currentNodeValue);
            var node = this.vue.findNodeByValueRecursively(this.vue.options, currentNodeValue);
            if (!node) {
                return;
            }
            var pNode = this.vue.findParentNodeRecursively(this.vue.options, currentNodeValue);
            this.vue.executeSelectCommand(node, pNode);
        };
        TreeCellType.prototype.GetHalfSelectedNodes = function () {
            var result = {
                Result: null
            };
            var halfSelectedNodes = this.vue.$refs.treeRef.getHalfCheckedNodes();
            if (halfSelectedNodes) {
                result.Result = halfSelectedNodes.map(function (p) { return p.value; });
            }
            return result;
        };
        TreeCellType.prototype.SetNodeSelectedStatus = function (nodeValue, isSelected, isRecurseSubNodes) {
            if (!nodeValue) {
                return;
            }
            this.vue.$refs.treeRef.setChecked(nodeValue, isSelected, isRecurseSubNodes);
        };
        TreeCellType.prototype.ReloadBinding = function () {
            var _this = this;
            if (!this.cellType.isTreeNodeFromDb) {
                return;
            }
            ElementCellTypes.SupportDataSourceCellType.refreshData(this, this.cellType.bindingDataSource, function (dataSource) { return _this.setArrayDataSource(dataSource); });
        };
        TreeCellType.prototype.DisableAllCheckbox = function (isDisable) {
            this.vue.isDisabled = isDisable;
            var dataSource = this.vue.options;
            this.setDataSource(dataSource);
        };
        return TreeCellType;
    }(ElementCellTypes.ElementCellTypeBase));
    ElementCellTypes.TreeCellType = TreeCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.TreeCellType, ElementUI", ElementCellTypes.TreeCellType);
var ElementCellTypes;
(function (ElementCellTypes) {
    var TreeHelper = /** @class */ (function () {
        function TreeHelper() {
        }
        TreeHelper.build = function (nodes) {
            var _this = this;
            if (!nodes) {
                return undefined;
            }
            var allDataNodes = nodes.map(function (item) { return (__assign({}, item)); });
            for (var _i = 0, allDataNodes_1 = allDataNodes; _i < allDataNodes_1.length; _i++) {
                var node = allDataNodes_1[_i];
                node.uId = this.getUid(node.value, node.parentValue);
            }
            var uidNodesCache = {};
            var idNodesCache = {};
            var parentIdNodesCache = {};
            for (var _a = 0, allDataNodes_2 = allDataNodes; _a < allDataNodes_2.length; _a++) {
                var node = allDataNodes_2[_a];
                uidNodesCache[node.uId] = node;
            }
            for (var _b = 0, allDataNodes_3 = allDataNodes; _b < allDataNodes_3.length; _b++) {
                var node = allDataNodes_3[_b];
                if (!idNodesCache[node.value]) {
                    idNodesCache[node.value] = [];
                }
                idNodesCache[node.value].push(node);
            }
            for (var _c = 0, allDataNodes_4 = allDataNodes; _c < allDataNodes_4.length; _c++) {
                var node = allDataNodes_4[_c];
                if (!parentIdNodesCache[node.parentValue]) {
                    parentIdNodesCache[node.parentValue] = [];
                }
                parentIdNodesCache[node.parentValue].push(node);
            }
            this.buildChildren(allDataNodes, parentIdNodesCache);
            var roots = allDataNodes.filter(function (i) { return _this.isRootNode(i, idNodesCache); });
            var exsitId = {};
            var uniqueRoots = roots.filter(function (i) {
                if (exsitId[i.value]) {
                    return false;
                }
                exsitId[i.value] = true;
                return true;
            });
            return uniqueRoots;
        };
        TreeHelper.getUid = function (id, pid) {
            return (id !== null && id !== void 0 ? id : "") + "_%_" + (pid !== null && pid !== void 0 ? pid : "");
        };
        TreeHelper.buildChildren = function (nodes, parentIdDataNodesCache) {
            for (var _i = 0, nodes_3 = nodes; _i < nodes_3.length; _i++) {
                var node = nodes_3[_i];
                var children = parentIdDataNodesCache[node.value];
                if (children) {
                    node.children = children;
                }
                else {
                    node.children = null;
                }
            }
        };
        TreeHelper.isRootNode = function (node, idNodesCache) {
            if (!node.parentValue) {
                return true;
            }
            var nodes = idNodesCache[node.parentValue];
            if (!nodes) {
                return true;
            }
            return false;
        };
        TreeHelper.flat = function (nodes) {
            var result = [];
            if (nodes && nodes.length) {
                for (var _i = 0, nodes_4 = nodes; _i < nodes_4.length; _i++) {
                    var n = nodes_4[_i];
                    result.push(n);
                    var subResult = this.flat(n.children);
                    subResult.every(function (i) { return result.push(i); });
                }
            }
            return result;
        };
        return TreeHelper;
    }());
    ElementCellTypes.TreeHelper = TreeHelper;
})(ElementCellTypes || (ElementCellTypes = {}));
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var TreeSelectCellType = /** @class */ (function (_super) {
        __extends(TreeSelectCellType, _super);
        function TreeSelectCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        TreeSelectCellType.prototype.setDataSource = function (dataSource) {
            return this.vue.setOptions(dataSource);
        };
        TreeSelectCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var cellType = this.cellType;
            var options = [];
            if (!cellType.useBinding && cellType.options) {
                options = cellType.options;
            }
            this.addCustomClass("el-select-custom");
            var self = this;
            var CssClassName = this.CellElement.CssClassName;
            var popperClass = CssClassName ? "".concat(CssClassName, "-popper") : "";
            var option = {
                template: "\n                    <el-tree-select\n                        v-model=\"value\"\n                        :data=\"options\"\n                        :placeholder=\"placeholder\"\n                        :disabled = \"disabled\"\n                        :clearable= \"clearable\"\n                        :collapse-tags = \"collapseTags\"\n                        :filterable = \"filterable\"\n                        :multiple = \"multiple\"\n                        :multiple-limit = \"multipleLimit\"\n                        :check-strictly = \"checkStrictly\"\n                        :indent=\"indent\"\n                        :highlightCurrent=\"highlightCurrent\"\n                        :defaultExpandAll=\"defaultExpandAll\"\n                        :expandOnClickNode=\"expandOnClickNode\"\n                        :accordion=\"accordion\"\n                        :show-checkbox=\"showCheckbox\"\n                        collapse-tags-tooltip\n                        popper-class=\"".concat(popperClass, "\"\n                        default-first-option\n                        ref=\"elTreeSelect\"\n                        @change=\"handleChange\"\n                        @blur=\"handleBlur\"\n                    />"),
                data: function () {
                    return {
                        options: options,
                        value: null,
                        disabled: cellType.IsDisabled,
                        placeholder: undefined,
                        clearable: cellType.clearable,
                        collapseTags: cellType.collapseTags,
                        filterable: cellType.filterable,
                        multiple: cellType.multiple,
                        indent: cellType.TreeSettings.indent,
                        highlightCurrent: cellType.TreeSettings.highlightCurrent,
                        defaultExpandAll: cellType.TreeSettings.defaultExpandAll,
                        expandOnClickNode: !!cellType.TreeSettings.expandOnClickNode,
                        accordion: cellType.TreeSettings.accordion,
                        showCheckbox: cellType.TreeSettings.showCheckBox,
                        multipleLimit: cellType.multipleLimit,
                        checkStrictly: cellType.checkStrictly,
                    };
                },
                methods: {
                    handleChange: function () {
                        self.commitValue();
                        self.validate();
                    },
                    handleBlur: function () {
                        self.validate();
                    },
                    getValue: function () {
                        if (cellType.multiple && Array.isArray(this.value)) {
                            return this.value.join(",");
                        }
                        return this.value;
                    },
                    setValue: function (value) {
                        var _a, _b;
                        if (self.isEmpty(value)) {
                            this.value = null;
                            return;
                        }
                        if (cellType.multiple) {
                            var stringValues_2 = value.toString().split(",");
                            var flatOptions = ElementCellTypes.TreeHelper.flat(this.options);
                            var options_4 = flatOptions.filter(function (o) { var _a; return stringValues_2.includes((_a = o.value) === null || _a === void 0 ? void 0 : _a.toString()); });
                            this.value = options_4.map(function (o) { return o.value; });
                        }
                        else {
                            var flatOptions = ElementCellTypes.TreeHelper.flat(this.options);
                            // 这里认为字符串数字与数字等价，双等号不能去掉
                            // eslint-disable-next-line
                            var option_7 = flatOptions.find(function (o) { return o.value == value; });
                            this.value = (_b = (_a = option_7 === null || option_7 === void 0 ? void 0 : option_7.value) !== null && _a !== void 0 ? _a : value) !== null && _b !== void 0 ? _b : null;
                        }
                    },
                    disable: function () {
                        this.disabled = true;
                    },
                    enable: function () {
                        this.disabled = false;
                    },
                    setOptions: function (options) {
                        if (options) {
                            ElementCellTypes.TreeHelper.flat(options).forEach(function (i) {
                                if (i === null || i === void 0 ? void 0 : i.label) {
                                    i.label = self.format(i.label);
                                }
                            });
                            this.options = options;
                        }
                        else {
                            this.options = [];
                        }
                    }
                },
            };
            this.createVueApp(option);
            if (cellType.useBinding) {
                self.ReloadBindingItems();
            }
            this.onFormulaResultChanged(cellType.placeholder, function (value) {
                var _a;
                _this.vue.placeholder = (_a = value === null || value === void 0 ? void 0 : value.toString()) !== null && _a !== void 0 ? _a : " ";
            });
            _super.prototype.onPageLoaded.call(this, info);
        };
        TreeSelectCellType.prototype.ReloadBindingItems = function () {
            var _this = this;
            var cellType = this.cellType;
            if (cellType.useBinding) {
                ElementCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (data) { return _this.setDataSource(ElementCellTypes.TreeHelper.build(data)); });
            }
        };
        TreeSelectCellType.prototype.preReload = function () {
            var cellType = this.CellElement.CellType;
            this.clearBindingDataSourceValueCache(cellType.bindingOptions, {
                distinct: true
            });
        };
        TreeSelectCellType.prototype.reload = function () {
            if (this.cellType.useBinding) {
                this.ReloadBindingItems();
            }
        };
        TreeSelectCellType.prototype.SetDataSourceByObjTree = function (dataSource, valueProperty, labelProperty, childrenProperty) {
            if (typeof dataSource === "string") {
                dataSource = JSON.parse(dataSource);
            }
            if (childrenProperty) {
                childrenProperty = childrenProperty.split('|');
            }
            if (valueProperty) {
                valueProperty = valueProperty.split('|');
            }
            labelProperty = labelProperty ? labelProperty.split('|') : valueProperty;
            var source = this.buildTree(dataSource, valueProperty, labelProperty, childrenProperty);
            this.setDataSource(source);
        };
        TreeSelectCellType.prototype.buildTree = function (dataSource, valueProperty, labelProperty, childrenProperty) {
            var _this = this;
            if (!dataSource) {
                return undefined;
            }
            return dataSource.map(function (i) { return ({
                value: _this.getSubPropertyValue(i, valueProperty),
                label: _this.getSubPropertyValue(i, labelProperty),
                children: _this.buildTree(_this.getSubPropertyValue(i, childrenProperty), valueProperty, labelProperty, childrenProperty),
            }); });
        };
        TreeSelectCellType.prototype.getSubPropertyValue = function (obj, subProperties) {
            for (var _i = 0, subProperties_2 = subProperties; _i < subProperties_2.length; _i++) {
                var prop = subProperties_2[_i];
                if (obj[prop] !== undefined) {
                    return obj[prop];
                }
            }
            return undefined;
        };
        TreeSelectCellType.prototype.SetDataSourceByIdPidTable = function (dataSource, valueProperty, labelProperty, parentValue) {
            if (typeof dataSource === "string") {
                dataSource = JSON.parse(dataSource);
            }
            var treeObj = ElementCellTypes.TreeHelper.build(dataSource.map(function (i) { return (__assign(__assign({}, i), { value: i[valueProperty], label: i[labelProperty], parentValue: i[parentValue] })); }));
            this.setDataSource(treeObj);
        };
        return TreeSelectCellType;
    }(ElementCellTypes.InputCellTypeBase));
    ElementCellTypes.TreeSelectCellType = TreeSelectCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.TreeSelectCellType, ElementUI", ElementCellTypes.TreeSelectCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var UploadListType;
    (function (UploadListType) {
        UploadListType[UploadListType["upload"] = 0] = "upload";
        UploadListType[UploadListType["pictureList"] = 1] = "pictureList";
        UploadListType[UploadListType["pictureCard"] = 2] = "pictureCard";
    })(UploadListType || (UploadListType = {}));
    var UploadCellType = /** @class */ (function (_super) {
        __extends(UploadCellType, _super);
        function UploadCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        UploadCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var self = this;
            var cellType = this.cellType;
            var bindingStr = "action=\"#\"\n:multiple=\"multiple\"\n:limit=\"limit\"\n:on-exceed=\"handleExceed\"\n:on-success=\"handleSuccess\"\n:on-remove=\"handleRemove\"\n:disabled=\"disabled || readOnly\"\n:on-preview=\"handlePreview\"\n:before-upload=\"handleBeforeUpload\"\n:http-request=\"httpRequest\"\n:accept=\"accept\"\n:file-list=\"fileList\" ";
            this.addCustomClass("el-upload-custom");
            var getTemplate = function () {
                if (cellType.listType === UploadListType.upload) {
                    return "<el-upload class=\"upload-demo\" ".concat(bindingStr, " list-type=\"text\">\n                                <el-button :disabled=\"disabled\" size=\"default\" type=\"primary\" v-if=\"!readOnly\">{{buttonText}}</el-button>\n                                <template #tip>\n                                    <div class=\"el-upload__tip\" :style=\"{ display: tipDisplay }\" v-if=\"!readOnly\">{{tipText}}</div>\n                                </template>\n                            </el-upload>");
                }
                if (cellType.listType === UploadListType.pictureCard) {
                    return "<el-upload ".concat(bindingStr, " list-type=\"picture-card\">\n                                <el-icon>").concat(ElementCellTypes.ElementIconMap.get("plus"), "</el-icon>\n                            </el-upload>");
                }
                if (cellType.listType === UploadListType.pictureList) {
                    return "<el-upload ".concat(bindingStr, " list-type=\"picture\" class=\"el-upload-picture-custom\">\n                                <el-button :disabled=\"disabled\" type=\"primary\" v-if=\"!readOnly\">{{buttonText}}</el-button>\n\n                                <template #tip v-if=\"!readOnly\">\n                                    <div class=\"el-upload__tip\" :style=\"{ display: tipDisplay }\" >{{tipText}}</div>\n                                </template>\n                            </el-upload>");
                }
            };
            var CssClassName = this.CellElement.CssClassName;
            var dialogCustomClass = CssClassName ? "".concat(CssClassName, "-upload-dialog") : "";
            var template = "<el-scrollbar>".concat(getTemplate(), "\n                                  <el-dialog append-to-body v-model=\"dialogVisible\" custom-class=\"fgc-upload-dialog ").concat(dialogCustomClass, "\">\n                                      <img style=\"max-width:100%;object-fit:contain;\" :src=\"dialogImageUrl\" alt=\"\" />\n                                  </el-dialog>\n                              </el-scrollbar>");
            var option = {
                el: "#" + this.uId,
                template: template,
                data: function () {
                    return {
                        multiple: cellType.multiple,
                        limit: cellType.limit,
                        accept: cellType.accept,
                        sizeLimit: cellType.sizeLimit,
                        buttonText: undefined,
                        tipText: undefined,
                        tipDisplay: cellType.tipText ? "" : "none",
                        disabled: undefined,
                        fileList: [],
                        dialogImageUrl: '',
                        dialogVisible: false,
                        readOnly: null,
                        successSet: new Set()
                    };
                },
                methods: {
                    getValue: function () {
                        var fileList = this.fileList;
                        if (this.updatingFileList) {
                            fileList = this.updatingFileList;
                        }
                        var text = fileList.map(function (i) { return i.fgc_fileName; }).join("|");
                        return text ? text + "|" : null;
                    },
                    setValue: function (value) {
                        if (value === this.getValue()) {
                            return;
                        }
                        this.updatingFileList = null;
                        if (value) {
                            var values = value.split("|");
                            var fileList_1 = [];
                            values.forEach(function (i) {
                                if (i && i.length > 37 && i.charAt(36) === "_") {
                                    var fileName = i.substring(37);
                                    fileList_1.push({
                                        isBoundData: true,
                                        name: fileName,
                                        fgc_fileName: i,
                                        url: UploadCellType.getFileUrl(i)
                                    });
                                }
                            });
                            this.fileList = fileList_1;
                        }
                        else {
                            this.fileList = [];
                        }
                    },
                    disable: function () {
                        this.disabled = true;
                        self.addCustomClass("disable");
                    },
                    enable: function () {
                        this.disabled = false;
                        self.getContainer().removeClass("disable");
                    },
                    setReadOnly: function (readOnly) {
                        if (cellType.listType === UploadListType.pictureCard) {
                            $(".el-upload--picture-card", self.getContainer()).css("display", readOnly ? "none" : "flex");
                        }
                        this.readOnly = readOnly;
                    },
                    handleSuccess: function (response, file, fileList) {
                        this.successSet.add(file.uid);
                        file.fgc_fileName = response;
                        file.url = UploadCellType.getFileUrl(response);
                        this.updatingFileList = fileList;
                        self.commitValue();
                    },
                    handleExceed: function (files, fileList) {
                        var error = cellType.OverFileCountLimitError;
                        error = error.replace("${limit}", this.limit);
                        error = error.replace("${length}", files.length);
                        error = error.replace("${total}", files.length + fileList.length);
                        this.$message.error(error);
                    },
                    httpRequest: function (data) {
                        var root = Forguncy.Helper.SpecialPath.getBaseUrl();
                        var uploadPath = root + "FileDownloadUpload/Upload";
                        var formData = new FormData();
                        formData.append("file", data.file);
                        formData.append("uploadLimitId", self.CellElement.ServerPropertiesId.UploadLimit);
                        $.ajax({
                            url: uploadPath,
                            type: 'POST',
                            success: function (responseData) {
                                data.onSuccess(responseData);
                            },
                            error: function () {
                                data.onError();
                            },
                            data: formData,
                            cache: false,
                            contentType: false,
                            processData: false,
                            headers: {
                                "Accept": "application/json"
                            }
                        });
                    },
                    handlePreview: function (file) {
                        if (!file.isBoundData && !this.successSet.has(file.uid)) {
                            return;
                        }
                        if (UploadCellType.isImage(file.name)) {
                            this.dialogImageUrl = file.url;
                            this.dialogVisible = true;
                        }
                        else {
                            Forguncy.Common.download(file.url);
                        }
                    },
                    handleBeforeUpload: function (file) {
                        if (cellType.accept) {
                            var exts = cellType.accept.split(",").filter(function (i) { return i; }).map(function (i) { return i.trim(); });
                            if (!exts.some(function (i) { return file.name.endsWith(i); })) {
                                this.$message.error(cellType.FileFormatError);
                                return false;
                            }
                        }
                        if (cellType.sizeLimit) {
                            if (file.size / 1024 / 1024 > cellType.sizeLimit) {
                                this.$message.error(cellType.OverFileSizeLimitError);
                                return false;
                            }
                        }
                        return true;
                    },
                    handleRemove: function (file, fileList) {
                        this.updatingFileList = fileList;
                        self.commitValue();
                    }
                }
            };
            this.createVueApp(option);
            this.onFormulaResultChanged(cellType.buttonText, function (value) {
                _this.vue.buttonText = value === null || value === void 0 ? void 0 : value.toString();
            });
            this.onFormulaResultChanged(cellType.tipText, function (value) {
                _this.vue.tipText = value === null || value === void 0 ? void 0 : value.toString();
            });
            _super.prototype.onPageLoaded.call(this, info);
        };
        UploadCellType.getFileUrl = function (fileName) {
            return Forguncy.Helper.SpecialPath.getBaseUrl() + Forguncy.ModuleLoader.getCdnUrl("FileDownloadUpload/Download?file=" + encodeURIComponent(fileName));
        };
        UploadCellType.isImage = function (fileName) {
            if (fileName) {
                var pointIndex = fileName.lastIndexOf(".");
                if (pointIndex) {
                    var extension_1 = fileName.toLowerCase().substring(pointIndex + 1, fileName.length);
                    return ["jpg", "jpeg", "png", "gif", "eps", "svg", "bmp", "tif", "tiff"].some(function (i) { return i === extension_1; });
                }
            }
            return false;
        };
        return UploadCellType;
    }(ElementCellTypes.InputCellTypeBase));
    ElementCellTypes.UploadCellType = UploadCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.UploadCellType, ElementUI", ElementCellTypes.UploadCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var FixedDir;
    (function (FixedDir) {
        FixedDir["LEFT"] = "left";
        FixedDir["RIGHT"] = "right";
    })(FixedDir || (FixedDir = {}));
    var parseAlign = function (align) {
        return align == "left" ? false : align;
    };
    var parseFixed = function (fixed) {
        if (fixed === "none") {
            return null;
        }
        if (fixed === "left") {
            return FixedDir.LEFT;
        }
        if (fixed === "right") {
            return FixedDir.RIGHT;
        }
    };
    var isEmpty = function (v) {
        return v === null || v === undefined || v === "";
    };
    var SelectionCell = Vue.defineComponent({
        template: "<div :class='classNames'> \n                    <el-checkbox size=\"large\" :onChange=\"onChange\" v-model=\"value\" :indeterminate=\"indeterminate\" @click.stop/>\n                   </div>",
        props: {
            value: Boolean,
            indeterminate: Boolean,
            align: String,
            onChange: Function
        },
        computed: {
            classNames: function () {
                var extendClassMap = {
                    "left": "fgc-virtualized-table-selection-cell-left",
                    "center": "fgc-virtualized-table-selection-cell-center",
                    "right": "fgc-virtualized-table-selection-cell-right"
                };
                return "fgc-virtualized-table-selection-cell " + extendClassMap[this.align];
            }
        }
    });
    var HeaderCell = Vue.defineComponent({
        template: "<div :class='classNames'>{{label}}</div>",
        props: {
            label: String,
            align: String
        },
        computed: {
            classNames: function () {
                var extendClassMap = {
                    "left": "fgc-virtualized-table-left-header-cell",
                    "center": "fgc-virtualized-table-center-header-cell",
                    "right": "fgc-virtualized-table-right-header-cell"
                };
                return "fgc-virtualized-table-header-cell " + extendClassMap[this.align];
            }
        }
    });
    var ActionButtonsCell = Vue.defineComponent({
        template: "\n<div style=\"display: flex;align-items: center\">\n  <template v-for=\"(item,index) in innerData\">\n    <template v-if=\"item.Type === 'icon' && item.Icon\">\n      <el-icon\n          v-if=\"item.IsIconSvg\"\n          v-html=\"item.Icon.props.icon\"\n          :title=\"item.Name\"\n          :style=\"getOperateIconStyle(item)\"\n          @click.stop=\"handleActionClick(item)\" />\n      <el-image v-else\n                class=\"el-icon\"\n                fit=\"contain\"\n                :src=\"item.Icon.props.src\"\n                :title=\"item.Name\"\n                :style=\"getOperateIconStyle(item)\"\n                @click.stop=\"handleActionClick(scope.row, item)\" />\n    </template>\n    <el-button v-else-if=\"item.Type === 'button'\"\n               class=\"fgc-el-table-opr-button\"\n               :round=\"item.Shape === 'round'\"\n               :circle=\"item.Shape === 'circle'\"\n               @click.stop=\"handleActionClick(item)\"\n               :icon=\"item.Icon\" bg text\n               :style=\"getOperationButtonStyle(item)\"\n    >\n      {{ item.Name }}\n    </el-button>\n    <el-link v-else\n             :underline=\"false\"\n             class=\"fgc-el-table-opr-link\"\n             :style=\"getOperationLinkStyle(item)\"\n             @click=\"handleActionClick(item)\"\n    >{{ item.Name }}</el-link>\n  </template>\n</div>\n        ",
        props: {
            data: Object,
            rowData: Object,
            executeCustomCommandObject: Function,
            getIconComponent: Function
        },
        data: function () {
            return {
                innerData: [],
            };
        },
        mounted: function () {
            var _this = this;
            this.innerData = this.$props.data.map(function (item) {
                return __assign(__assign({}, item), { Icon: null });
            });
            var _loop_8 = function (i) {
                this_5.$props.getIconComponent(this_5.$props.data[i].Icon, function (icon, result) {
                    var item = _this.innerData[i];
                    item.Icon = icon;
                    item.IsIconSvg = result.isSvg;
                    item.StyleType = Forguncy.ConvertToCssColor(item.StyleType);
                });
            };
            var this_5 = this;
            for (var i = 0; i < this.innerData.length; i++) {
                _loop_8(i);
            }
        },
        methods: {
            handleActionClick: function (item) {
                if (item.Commands) {
                    var commands = item.Commands;
                    var initParam = {};
                    initParam[commands.ParamProperties["dataRow"]] = this.rowData;
                    this.executeCustomCommandObject(commands, initParam);
                }
            },
            getOperateIconStyle: function (button) {
                return {
                    cursor: "pointer",
                    margin: "3px 10px",
                    verticalAlign: "middle",
                    width: button.IconWidth + 'px',
                    height: button.IconHeight + 'px'
                };
            },
            getOperationButtonStyle: function (button) {
                var noFill = isEmpty(button.StyleType);
                return {
                    margin: '3px 10px',
                    backgroundColor: button.StyleType,
                    color: noFill ? '#606266' : '#fff',
                    border: noFill ? '1px solid #dcdfe6' : "1px solid ".concat(button.StyleType)
                };
            },
            getOperationLinkStyle: function (button) {
                var noFill = isEmpty(button.StyleType);
                return {
                    margin: '3px 10px',
                    userSelect: 'none',
                    color: noFill ? "#606266" : button.StyleType
                };
            }
        }
    });
    var VirtualizedTableCellType = /** @class */ (function (_super) {
        __extends(VirtualizedTableCellType, _super);
        function VirtualizedTableCellType() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.jsonDataSource = null;
            _this.originalDataSource = [];
            return _this;
        }
        Object.defineProperty(VirtualizedTableCellType.prototype, "isTreeTable", {
            get: function () {
                return this.cellType.DataType === "treeTable";
            },
            enumerable: false,
            configurable: true
        });
        VirtualizedTableCellType.prototype.setDataSource = function (dataSource, calcExpandRowKeys) {
            if (calcExpandRowKeys === void 0) { calcExpandRowKeys = false; }
            this.vue.isLoading = false;
            return this.vue.setData(dataSource, calcExpandRowKeys);
        };
        VirtualizedTableCellType.prototype.convertColumnDataModelToColumn = function (item) {
            return {
                key: item.Label,
                dataKey: item.Label,
                originalDataKey: item.DataColumnName,
                title: item.Label,
                width: item.Width,
                align: item.Align === "left" ? false : item.Align,
                fixed: parseFixed(item.Fixed),
                formatStr: item.FormatStr,
                headerCellRenderer: function () {
                    return Vue.h(HeaderCell, {
                        label: item.Label,
                        align: item.HeaderAlign
                    });
                },
            };
        };
        VirtualizedTableCellType.prototype.formatValue = function (formatStr, cellValue) {
            if (!formatStr) {
                return cellValue;
            }
            var result = Forguncy.FormatHelper.format(formatStr, cellValue);
            if (result) {
                return result.text;
            }
            return cellValue;
        };
        VirtualizedTableCellType.prototype.onWindowResized = function () {
            this.vue.calculateColumnLayout();
        };
        VirtualizedTableCellType.prototype.getColumns = function (items) {
            var _this = this;
            var columns = items.map(this.convertColumnDataModelToColumn);
            var newColumns = [];
            // 行号列
            if (this.cellType.ShowLineNumberColumn) {
                newColumns.push({
                    key: 'fgc-el-line-number',
                    width: this.cellType.LineNumberColumnSetting.Width,
                    align: parseAlign(this.cellType.LineNumberColumnSetting.Align),
                    fixed: parseFixed(this.cellType.LineNumberColumnSetting.Fixed),
                    cellRenderer: function (_a) {
                        var rowIndex = _a.rowIndex;
                        return rowIndex + 1;
                    },
                    headerCellRenderer: function () {
                        return Vue.h(HeaderCell, {
                            label: _this.cellType.LineNumberColumnSetting.Label,
                            align: _this.cellType.LineNumberColumnSetting.HeaderAlign
                        });
                    },
                });
            }
            // 选择列
            if (this.cellType.ShowSelectionColumn && !this.isTreeTable) {
                newColumns.push({
                    key: 'fgc-el-selection',
                    width: this.cellType.SelectColumnSettings.Width,
                    align: parseAlign(this.cellType.SelectColumnSettings.Align),
                    fixed: parseFixed(this.cellType.SelectColumnSettings.Fixed),
                    cellRenderer: function (data) {
                        var onChange = function (value) {
                            data.rowData.fgc_checked = value;
                            if (_this.cellType.SelectionChangedCommand) {
                                var commands = _this.cellType.SelectionChangedCommand;
                                var initParam = {};
                                initParam[commands.ParamProperties["selection"]] = _this.vue.data.filter(function (i) { return i.fgc_checked; }).map(_this.vue.convertRowData);
                                _this.executeCustomCommandObject(commands, initParam);
                            }
                        };
                        return Vue.h(SelectionCell, {
                            align: _this.cellType.SelectColumnSettings.Align,
                            onChange: onChange,
                            intermediate: false,
                            value: !!data.rowData.fgc_checked
                        });
                    },
                    headerCellRenderer: function () {
                        var allSelected = _this.vue.data.length && _this.vue.data.every(function (row) { return row.fgc_checked; });
                        var containsChecked = _this.vue.data.some(function (row) { return row.fgc_checked; });
                        var onChange = function (value) {
                            if (_this.isTreeTable) {
                                Forguncy.TreeHelper.flattenTree(_this.vue.data, "children").map(function (item) { return (item.fgc_checked = value); });
                            }
                            else {
                                _this.vue.data.map(function (item) { return (item.fgc_checked = value); });
                            }
                            if (_this.cellType.SelectionChangedCommand) {
                                var commands = _this.cellType.SelectionChangedCommand;
                                var initParam = {};
                                initParam[commands.ParamProperties["selection"]] = _this.vue.data.filter(function (i) { return i.fgc_checked; });
                                _this.executeCustomCommandObject(commands, initParam);
                            }
                        };
                        return Vue.h(SelectionCell, {
                            align: _this.cellType.SelectColumnSettings.HeaderAlign,
                            onChange: onChange,
                            value: !!allSelected,
                            indeterminate: containsChecked && !allSelected
                        });
                    },
                });
            }
            newColumns.push.apply(newColumns, columns);
            if (this.cellType.ShowOperationColumn) {
                var operationColumn = {
                    key: 'fgc-el-operations',
                    width: this.cellType.OperationColumnSettings.Width,
                    align: parseAlign(this.cellType.OperationColumnSettings.Align),
                    fixed: parseFixed(this.cellType.OperationColumnSettings.Fixed),
                    headerCellRenderer: function () {
                        return Vue.h(HeaderCell, {
                            label: _this.cellType.OperationColumnSettings.Label,
                            align: _this.cellType.OperationColumnSettings.HeaderAlign
                        });
                    },
                    cellRenderer: function (data) {
                        return Vue.h(ActionButtonsCell, {
                            data: _this.cellType.OperationColumnSettings.ActionButtons,
                            rowData: data.rowData,
                            executeCustomCommandObject: _this.executeCustomCommandObject.bind(_this),
                            getIconComponent: _this.getIconComponent.bind(_this)
                        });
                    }
                };
                if (this.cellType.OperationColumnSettings.Fixed !== "none") {
                    operationColumn.fixed = this.cellType.OperationColumnSettings.Fixed;
                }
                newColumns.push(operationColumn);
            }
            return newColumns;
        };
        VirtualizedTableCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var self = this;
            var isLoading = false;
            if (this.isTreeTable) {
                if (this.cellType.BindingTreeTableOptions) {
                    isLoading = true;
                }
            }
            else if (this.cellType.BindingTableOptions) {
                isLoading = true;
            }
            var columns = this.getColumns(this.cellType.Columns);
            this.cellType.OperationColumnSettings.ActionButtons.forEach(function (button) {
                button.StyleType = Forguncy.ConvertToCssColor(button.StyleType);
            });
            var option = {
                el: "#" + this.uId,
                template: "\n  <el-auto-resizer>\n    <template #default=\"{ height, width }\">\n      <el-table-v2\n          row-key=\"fgc_row_key\"\n          :columns=\"columns\"\n          :data=\"data\"\n          :width=\"width\"\n          :height=\"height\"\n          :expand-column-key=\"expandColumnKey\"\n          :row-event-handlers=\"rowEventHandlers\"\n          v-model:expanded-row-keys=\"expandedRowKeys\"\n          border\n          fixed\n      >\n    <template #overlay v-if=\"isLoading\">\n      <div\n        class=\"el-loading-mask\"\n        style=\"display: flex; align-items: center; justify-content: center\"\n      >\n        <el-icon class=\"is-loading\" color=\"var(--el-color-primary)\" :size=\"26\">\n            <svg viewBox=\"0 0 1024 1024\" xmlns=\"http://www.w3.org/2000/svg\" data-v-ea893728=\"\"><path fill=\"currentColor\" d=\"M512 64a32 32 0 0 1 32 32v192a32 32 0 0 1-64 0V96a32 32 0 0 1 32-32zm0 640a32 32 0 0 1 32 32v192a32 32 0 1 1-64 0V736a32 32 0 0 1 32-32zm448-192a32 32 0 0 1-32 32H736a32 32 0 1 1 0-64h192a32 32 0 0 1 32 32zm-640 0a32 32 0 0 1-32 32H96a32 32 0 0 1 0-64h192a32 32 0 0 1 32 32zM195.2 195.2a32 32 0 0 1 45.248 0L376.32 331.008a32 32 0 0 1-45.248 45.248L195.2 240.448a32 32 0 0 1 0-45.248zm452.544 452.544a32 32 0 0 1 45.248 0L828.8 783.552a32 32 0 0 1-45.248 45.248L647.744 692.992a32 32 0 0 1 0-45.248zM828.8 195.264a32 32 0 0 1 0 45.184L692.992 376.32a32 32 0 0 1-45.248-45.248l135.808-135.808a32 32 0 0 1 45.248 0zm-452.544 452.48a32 32 0 0 1 0 45.248L240.448 828.8a32 32 0 0 1-45.248-45.248l135.808-135.808a32 32 0 0 1 45.248 0z\"></path></svg>\n        </el-icon>\n      </div>\n    </template>\n        <template #empty>\n          <div>\n            <el-empty :image-size=\"200\" v-if=\"!isLoading\"/>\n            <div v-if=\"isLoading\">\n            </div>\n          </div>\n        </template>\n      </el-table-v2>\n    </template>\n  </el-auto-resizer>",
                data: function () {
                    var _this = this;
                    return {
                        isLoading: isLoading,
                        columns: columns,
                        data: [],
                        expandedRowKeys: [],
                        actionButtons: self.cellType.OperationColumnSettings.ActionButtons,
                        rowEventHandlers: {
                            onClick: function (e) {
                                var target = e.event.target;
                                if (target.tagName === "svg" || target.parentElement.tagName === "svg") {
                                    return;
                                }
                                _this.handleRowCommand(_this.convertRowData(e.rowData), self.cellType.RowClickCommand, "click");
                            },
                            onDblclick: function (e) {
                                var target = e.event.target;
                                if (target.tagName === "svg" || target.parentElement.tagName === "svg") {
                                    return;
                                }
                                _this.handleRowCommand(_this.convertRowData(e.rowData), self.cellType.RowDoubleClickCommand, "dblclick");
                            },
                        }
                    };
                },
                mounted: function () {
                    this.calculateColumnLayout();
                },
                computed: {
                    expandColumnKey: function () {
                        if (self.isTreeTable && this.columns.length) {
                            return this.columns[0].key;
                        }
                        return null;
                    }
                },
                methods: {
                    convertRowData: function (item) {
                        var data = __assign({}, item);
                        delete data.fgc_row_key;
                        delete data.fgc_checked;
                        this.columns.forEach(function (column) {
                            var _a;
                            data[(_a = column.title) !== null && _a !== void 0 ? _a : column.key] = item[column.key];
                        });
                        return data;
                    },
                    handleRowCommand: function (row, commands, eventType) {
                        if (commands) {
                            var initParam = {};
                            initParam[commands.ParamProperties["dataRow"]] = row;
                            self.executeCustomCommandObject(commands, initParam, eventType);
                        }
                    },
                    setData: function (data, calcExpandRowKeys) {
                        var _this = this;
                        self.originalDataSource = data;
                        var formatMap = new Map();
                        this.columns.forEach(function (i) {
                            var _a;
                            if ((_a = i.formatStr) === null || _a === void 0 ? void 0 : _a.toString().length) {
                                formatMap.set(i.title, i.formatStr);
                            }
                        });
                        var expandedRowKeys = [];
                        var loop = function (items, level) {
                            if (level === void 0) { level = 1; }
                            return items.map(function (i, index) {
                                var _a;
                                var cloneItem = __assign({ "fgc_row_key": index }, i);
                                if (calcExpandRowKeys && self.isTreeTable) {
                                    if (self.cellType.DefaultExpansion === "expandAll" || (self.cellType.DefaultExpansion === "expandToSpecifiedLevel" && level < self.cellType.ExpandToSpecifiedLevel)) {
                                        expandedRowKeys.push(cloneItem.fgc_row_key);
                                    }
                                }
                                _this.columns.forEach(function (i) {
                                    var _a;
                                    cloneItem[i.dataKey] = self.formatValue(i.formatStr, cloneItem[(_a = i.originalDataKey) !== null && _a !== void 0 ? _a : i.dataKey]);
                                });
                                if ((_a = i === null || i === void 0 ? void 0 : i.children) === null || _a === void 0 ? void 0 : _a.length) {
                                    cloneItem.children = loop(i.children, level + 1);
                                }
                                return cloneItem;
                            });
                        };
                        if (calcExpandRowKeys && self.isTreeTable) {
                            this.expandedRowKeys = expandedRowKeys;
                        }
                        this.data = loop(data);
                    },
                    calculateColumnLayout: function () {
                        var availableWidth = self.getContainer().width();
                        var columns = __spreadArray([], this.columns, true);
                        var needCalcColumns = [];
                        columns.forEach(function (c) {
                            if (!isEmpty(c.width) && !c.isWidthAutoCalculated) {
                                availableWidth -= c.width;
                            }
                            else {
                                needCalcColumns.push(c);
                            }
                        });
                        var averageWidth = Math.floor(availableWidth / needCalcColumns.length);
                        needCalcColumns.forEach(function (c, index) {
                            var width = averageWidth;
                            if (index == needCalcColumns.length - 1) {
                                width = availableWidth - ((needCalcColumns.length - 1) * averageWidth);
                            }
                            c.isWidthAutoCalculated = true;
                            c.width = Math.max(width, 100);
                        });
                        this.columns = columns;
                    },
                }
            };
            this.createVueApp(option);
            this.onDependenceCellValueChanged(function () {
                _this.queryElTable();
            });
            if (!this.IsElTablePaging()) {
                this.queryElTable();
            }
            _super.prototype.onPageLoaded.call(this, info);
        };
        VirtualizedTableCellType.prototype.reload = function () {
            this.queryElTable();
        };
        VirtualizedTableCellType.prototype.getSubPropertyValue = function (obj, subProperties) {
            for (var _i = 0, subProperties_3 = subProperties; _i < subProperties_3.length; _i++) {
                var prop = subProperties_3[_i];
                if (obj[prop] !== undefined) {
                    return obj[prop];
                }
            }
            return undefined;
        };
        VirtualizedTableCellType.prototype.buildTree = function (dataSource, valueProperty, childrenProperty) {
            var _this = this;
            if (!dataSource) {
                return undefined;
            }
            if (!(dataSource === null || dataSource === void 0 ? void 0 : dataSource.map)) {
                return [];
            }
            return dataSource.map(function (i) { return (__assign(__assign({ fgc_row_key: _this.getSubPropertyValue(i, valueProperty) }, i), { children: _this.buildTree(_this.getSubPropertyValue(i, childrenProperty), valueProperty, childrenProperty) })); });
        };
        VirtualizedTableCellType.prototype.IsElTablePaging = function () {
            var _this = this;
            if (this.isEmpty(this.cellType.TableName)) {
                return false;
            }
            var allCells = Forguncy.ForguncyData.pageInfo.pageElementManager.cells.getAllCells([this.runTimePageName]);
            var allElPagerCells = allCells === null || allCells === void 0 ? void 0 : allCells.filter(function (cell) { return cell.cellType instanceof ElementCellTypes.PaginationCellType; });
            return allElPagerCells.some(function (_a) {
                var cellType = _a.cellType;
                return cellType.cellType.ElementTableName === _this.cellType.TableName;
            });
        };
        VirtualizedTableCellType.prototype.ClearSelection = function () {
            if (this.isTreeTable) {
                Forguncy.TreeHelper.flattenTree(this.vue.data, "children").map(function (item) { return (item.fgc_checked = false); });
            }
            else {
                this.vue.data.map(function (item) { return (item.fgc_checked = false); });
            }
            if (this.cellType.SelectionChangedCommand) {
                var commands = this.cellType.SelectionChangedCommand;
                var initParam = {};
                initParam[commands.ParamProperties["selection"]] = this.vue.data.filter(function (i) { return i.fgc_checked; });
                this.executeCustomCommandObject(commands, initParam);
            }
        };
        VirtualizedTableCellType.prototype.GetSelectedRow = function () {
            return {
                SelectedRow: this.vue.data.filter(function (i) { return i.fgc_checked; })
            };
        };
        VirtualizedTableCellType.prototype.ResetTable = function () {
            this.jsonDataSource = null;
            this.queryElTable();
        };
        VirtualizedTableCellType.prototype.SetTableColumnSetting = function (name, columnSetting) {
            var _this = this;
            var column = this.convertColumnDataModelToColumn(columnSetting);
            var index = this.vue.columns.findIndex(function (x) { return x.originalDataKey === name; });
            if (index !== -1) {
                var originalColumn = this.vue.columns[index];
                var oldTitle_1 = originalColumn.title;
                this.vue.columns[index] = __assign(__assign(__assign({}, this.vue.columns[index]), column), { isWidthAutoCalculated: !column.width });
                this.vue.calculateColumnLayout();
                var newDataSource = this.originalDataSource;
                if (oldTitle_1 !== this.vue.columns[index].title) {
                    var loop_1 = function (items) {
                        return items.map(function (i) {
                            var _a;
                            i[_this.vue.columns[index].title] = i[oldTitle_1];
                            delete i[oldTitle_1];
                            if ((_a = i === null || i === void 0 ? void 0 : i.children) === null || _a === void 0 ? void 0 : _a.length) {
                                i.children = loop_1(i.children);
                            }
                            return i;
                        });
                    };
                    newDataSource = loop_1(newDataSource);
                }
                this.setDataSource(newDataSource);
            }
        };
        VirtualizedTableCellType.prototype.SetJsonDataSource = function (dataSource) {
            if (typeof dataSource === "string") {
                dataSource = JSON.parse(dataSource);
            }
            if (Array.isArray(dataSource) && dataSource.length > 0 && this.cellType.AutoGenerateColumnsByDataSource) {
                var sample = dataSource[0];
                if (this.isPlainObject(sample)) {
                    var data = Object.keys(sample).map(function (columnName, index) {
                        return {
                            Label: columnName,
                            DataColumnName: columnName,
                            Align: "left",
                            HeaderAlign: "left",
                            Fixed: "none",
                        };
                    });
                    this.vue.columns = this.getColumns(data);
                    this.vue.calculateColumnLayout();
                }
            }
            if (this.pager != null) {
                this.pager.total = dataSource.length;
            }
            this.jsonDataSource = dataSource;
            this.queryElTable();
        };
        VirtualizedTableCellType.prototype.SetDataSourceByObjTree = function (dataSource, valueProperty, childrenProperty) {
            if (typeof dataSource === "string") {
                dataSource = JSON.parse(dataSource);
            }
            if (childrenProperty) {
                childrenProperty = childrenProperty.split('|');
            }
            if (valueProperty) {
                valueProperty = valueProperty.split('|');
            }
            var source = this.buildTree(dataSource, valueProperty, childrenProperty);
            this.setDataSource(source, true);
        };
        VirtualizedTableCellType.prototype.SetDataSourceByIdPidTable = function (dataSource, valueProperty, parentValue) {
            if (typeof dataSource === "string") {
                dataSource = JSON.parse(dataSource);
            }
            var data = dataSource.map(function (i) { return (__assign(__assign({}, i), { fgc_row_key: i[valueProperty], value: i[valueProperty], parentValue: i[parentValue] })); });
            var tree = Forguncy.TreeHelper.buildTree(data, "value", "parentValue");
            this.setDataSource(tree, true);
        };
        VirtualizedTableCellType.prototype.queryElTableTotalRecords = function () {
            var _this = this;
            var tableCellType = this.cellType;
            var option = { queryValueType: 3 /* Forguncy.Plugin.TableValueType.Count */ };
            return new Promise(function (resolve) {
                _this.getBindingDataSourceValue(_this.isTreeTable ? tableCellType.BindingTreeTableOptions : tableCellType.BindingTableOptions, option, resolve);
            });
        };
        VirtualizedTableCellType.prototype.queryElTable = function () {
            return __awaiter(this, void 0, void 0, function () {
                var offset, top, query, total;
                var _this = this;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            offset = 0;
                            top = 0;
                            if (this.pager) {
                                offset = this.pager.pageSize * (this.pager.currentPage - 1);
                                top = this.pager.pageSize;
                            }
                            if (this.jsonDataSource != null) {
                                if (!this.pager) {
                                    this.setDataSource(this.jsonDataSource);
                                }
                                else {
                                    this.setDataSource(this.jsonDataSource.slice(offset, Math.min(offset + top, this.jsonDataSource.length)));
                                }
                                return [2 /*return*/];
                            }
                            query = {};
                            if (!this.pager) return [3 /*break*/, 2];
                            query.top = top;
                            query.offset = offset;
                            query.pagerMode = true;
                            return [4 /*yield*/, this.queryElTableTotalRecords()];
                        case 1:
                            total = _a.sent();
                            this.pager.total = total;
                            _a.label = 2;
                        case 2:
                            if (this.cellType.DataType === "table") {
                                this.getBindingDataSourceValue(this.cellType.BindingTableOptions, query, function (dataSource) {
                                    _this.setDataSource(dataSource);
                                });
                            }
                            else {
                                this.getBindingDataSourceValue(this.cellType.BindingTreeTableOptions, query, function (dataSource) {
                                    var cloneDataSource = dataSource.map(function (i) { return (__assign({ fgc_row_key: i === null || i === void 0 ? void 0 : i.value }, i)); });
                                    var tree = Forguncy.TreeHelper.buildTree(cloneDataSource, "value", "parentValue");
                                    _this.setDataSource(tree, true);
                                });
                            }
                            return [2 /*return*/];
                    }
                });
            });
        };
        return VirtualizedTableCellType;
    }(ElementCellTypes.ElementCellTypeBase));
    ElementCellTypes.VirtualizedTableCellType = VirtualizedTableCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.VirtualizedTableCellType, ElementUI", ElementCellTypes.VirtualizedTableCellType);
var ElementCommands;
(function (ElementCommands) {
    var ElementCommandBase = /** @class */ (function (_super) {
        __extends(ElementCommandBase, _super);
        function ElementCommandBase() {
            var _a;
            (_a = window["elementUITheme"]) === null || _a === void 0 ? void 0 : _a.UpdateCssAndAppend();
            return _super.call(this) || this;
        }
        return ElementCommandBase;
    }(Forguncy.Plugin.CommandBase));
    ElementCommands.ElementCommandBase = ElementCommandBase;
})(ElementCommands || (ElementCommands = {}));
/// <reference path = "ELCommandBase.ts" />
var ElementCommands;
(function (ElementCommands) {
    var ShowMessage = /** @class */ (function (_super) {
        __extends(ShowMessage, _super);
        function ShowMessage() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        ShowMessage.prototype.execute = function () {
            var _a, _b, _c;
            var _d = this.CommandParam, Center = _d.Center, Duration = _d.Duration, Message = _d.Message, Offset = _d.Offset, ShowClose = _d.ShowClose, Type = _d.Type;
            var duration = (_a = parseFloat(this.evaluateFormula(Duration))) !== null && _a !== void 0 ? _a : 0;
            var offset = (_b = this.evaluateFormula(Offset)) !== null && _b !== void 0 ? _b : 20;
            var type = this.evaluateFormula(Type);
            var message = (_c = this.evaluateFormula(Message)) !== null && _c !== void 0 ? _c : "";
            var center = !!Center;
            var showClose = !!ShowClose;
            window.ElementPlus.ElMessage({
                duration: duration,
                message: message,
                type: type,
                center: center,
                showClose: showClose,
                offset: Number(offset),
            });
        };
        return ShowMessage;
    }(ElementCommands.ElementCommandBase));
    ElementCommands.ShowMessage = ShowMessage;
})(ElementCommands || (ElementCommands = {}));
Forguncy.Plugin.CommandFactory.registerCommand("ElementUI.Commands.ShowMessage, ElementUI", ElementCommands.ShowMessage);
/// <reference path = "ELCommandBase.ts" />
var ElementCommands;
(function (ElementCommands) {
    var ShowMessBoxInputType;
    (function (ShowMessBoxInputType) {
        ShowMessBoxInputType[ShowMessBoxInputType["text"] = 0] = "text";
        ShowMessBoxInputType[ShowMessBoxInputType["textarea"] = 1] = "textarea";
        ShowMessBoxInputType[ShowMessBoxInputType["password"] = 2] = "password";
    })(ShowMessBoxInputType || (ShowMessBoxInputType = {}));
    var ShowMessageBox = /** @class */ (function (_super) {
        __extends(ShowMessageBox, _super);
        function ShowMessageBox() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        ShowMessageBox.prototype.execute = function () {
            var _this = this;
            var _a, _b;
            var _c = this.CommandParam, Title = _c.Title, Message = _c.Message, ShowClose = _c.ShowClose, Type = _c.Type, ShowConfirmButton = _c.ShowConfirmButton, ConfirmButtonText = _c.ConfirmButtonText, ShowCancelButton = _c.ShowCancelButton, CancelButtonText = _c.CancelButtonText, DialogResult = _c.DialogResult, _d = _c.AdvancedSettings, CloseOnClickModal = _d.CloseOnClickModal, CloseOnPressEscape = _d.CloseOnPressEscape, ShowInput = _d.ShowInput, InputPlaceholder = _d.InputPlaceholder, InputType = _d.InputType, Center = _d.Center, RoundButton = _d.RoundButton, InputBoxResult = _d.InputBoxResult, DistinguishCancelAndClose = _d.DistinguishCancelAndClose;
            var title = this.evaluateFormula(Title);
            var message = (_b = (_a = this.evaluateFormula(Message)) === null || _a === void 0 ? void 0 : _a.toString()) !== null && _b !== void 0 ? _b : "";
            var type = this.evaluateFormula(Type);
            var showConfirmButton = !!ShowConfirmButton;
            var confirmButtonText = this.evaluateFormula(ConfirmButtonText);
            var showCancelButton = !!ShowCancelButton;
            var cancelButtonText = this.evaluateFormula(CancelButtonText);
            var showClose = !!ShowClose;
            var closeOnClickModal = !!CloseOnClickModal;
            var closeOnPressEscape = !!CloseOnPressEscape;
            var showInput = !!ShowInput;
            var inputPlaceholder = this.evaluateFormula(InputPlaceholder);
            var inputType = ShowMessBoxInputType[InputType];
            var center = !!Center;
            var roundButton = !!RoundButton;
            var distinguishCancelAndClose = !!DistinguishCancelAndClose;
            var callback = function (parameter) {
                if (typeof parameter === "string") {
                    Forguncy.CommandHelper.setVariableValue(DialogResult, parameter);
                }
                else {
                    Forguncy.CommandHelper.setVariableValue(DialogResult, parameter.action);
                    Forguncy.CommandHelper.setVariableValue(InputBoxResult, parameter.value);
                }
                _this.CommandExecutingInfo.suspend = false;
            };
            Forguncy.PageBuilder.hidePageLoadingCover();
            window.ElementPlus.ElMessageBox({
                title: title,
                message: message.split('\n').join('<br>'),
                type: type,
                showClose: showClose,
                showConfirmButton: showConfirmButton,
                confirmButtonText: confirmButtonText,
                showCancelButton: showCancelButton,
                cancelButtonText: cancelButtonText,
                closeOnClickModal: closeOnClickModal,
                closeOnPressEscape: closeOnPressEscape,
                showInput: showInput,
                inputPlaceholder: inputPlaceholder,
                inputType: inputType,
                center: center,
                roundButton: roundButton,
                dangerouslyUseHTMLString: true,
                distinguishCancelAndClose: distinguishCancelAndClose,
                customClass: "fgc-el-message-box"
            }).then(callback).catch(callback);
            this.CommandExecutingInfo.suspend = true;
        };
        return ShowMessageBox;
    }(ElementCommands.ElementCommandBase));
    ElementCommands.ShowMessageBox = ShowMessageBox;
    window.addEventListener("popstate", function () { return $(".fgc-el-message-box").parents(".el-overlay.is-message-box").remove(); });
})(ElementCommands || (ElementCommands = {}));
Forguncy.Plugin.CommandFactory.registerCommand("ElementUI.Commands.ShowMessageBox, ElementUI", ElementCommands.ShowMessageBox);
/// <reference path = "ELCommandBase.ts" />
var ElementCommands;
(function (ElementCommands) {
    var ShowNotification = /** @class */ (function (_super) {
        __extends(ShowNotification, _super);
        function ShowNotification() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        ShowNotification.prototype.execute = function () {
            var _this = this;
            var _a, _b, _c, _d;
            var _e = this.CommandParam, Title = _e.Title, Duration = _e.Duration, Message = _e.Message, Context = _e.Context, Position = _e.Position, ShowClose = _e.ShowClose, Type = _e.Type, Offset = _e.Offset, Command = _e.Command;
            var duration = (_a = this.evaluateFormula(Duration)) !== null && _a !== void 0 ? _a : 0;
            var title = this.evaluateFormula(Title);
            var offset = (_b = Number(this.evaluateFormula(Offset))) !== null && _b !== void 0 ? _b : 0;
            var type = this.evaluateFormula(Type);
            var message = (_c = this.evaluateFormula(Message)) !== null && _c !== void 0 ? _c : "";
            var context = this.evaluateFormula(Context);
            var position = (_d = this.evaluateFormula(Position)) !== null && _d !== void 0 ? _d : "top-right";
            var clickCommands = Command;
            var showClose = !!ShowClose;
            var onClick = null;
            var customClass;
            var noticy = null;
            if ((clickCommands === null || clickCommands === void 0 ? void 0 : clickCommands.Commands) && clickCommands.Commands.length > 0) {
                onClick = function () {
                    var param = {};
                    param[clickCommands.ParamProperties["title"]] = title;
                    param[clickCommands.ParamProperties["message"]] = message;
                    param[clickCommands.ParamProperties["context"]] = context;
                    _this.executeCustomCommandObject(clickCommands, param, "Notice");
                    noticy.close();
                };
                customClass = "fgc-notice-element-clickable";
            }
            noticy = window.ElementPlus.ElNotification({
                title: title,
                message: message,
                type: type,
                duration: duration,
                position: position,
                showClose: showClose,
                offset: offset,
                onClick: onClick,
                customClass: customClass
            });
        };
        return ShowNotification;
    }(ElementCommands.ElementCommandBase));
    ElementCommands.ShowNotification = ShowNotification;
})(ElementCommands || (ElementCommands = {}));
Forguncy.Plugin.CommandFactory.registerCommand("ElementUI.Commands.ShowNotification, ElementUI", ElementCommands.ShowNotification);
var ElementCellTypes;
(function (ElementCellTypes) {
    var DateUtil = /** @class */ (function () {
        function DateUtil() {
        }
        DateUtil.isInvalidDate = function (date) {
            return !date || !date.getTime();
        };
        DateUtil.InteralConvertToDate = function (value) {
            if (!value) {
                return null;
            }
            if (value instanceof Date) {
                return value;
            }
            var numerValue = Number(value);
            var isOADate = !isNaN(numerValue);
            if (isOADate) {
                return Forguncy.ConvertOADateToDate(numerValue);
            }
            return new Date(value);
        };
        /**
         * 将时间转为日期
         * @param value
         */
        DateUtil.InteralConvertTimeToDate = function (value) {
            var date = DateUtil.InteralConvertToDate(value);
            return this.isInvalidDate(date) ? new Date("1970/1/1 ".concat(value)) : date;
        };
        /**
         * 将一个值转为一个日期
         * @param value
         * @param effectiveValue    转换失败时返回的值，默认是 Invalid Date
         */
        DateUtil.ConvertToDate = function (value, effectiveValue) {
            if (effectiveValue === void 0) { effectiveValue = "Invalid Date"; }
            var date = DateUtil.InteralConvertToDate(value);
            return this.isInvalidDate(date) ? effectiveValue : date;
        };
        /**
         * 将一个时间转为一个Date
         * @param value             时间字符串
         * @param options           传入年月日，默认是1970年1月1号
         * @param effectiveValue    转换失败时返回的值，默认是 Invalid Date
         */
        DateUtil.ConverTimeToDate = function (value, options, effectiveValue) {
            if (effectiveValue === void 0) { effectiveValue = "Invalid Date"; }
            var date = DateUtil.InteralConvertTimeToDate(value);
            if (this.isInvalidDate(date)) {
                return effectiveValue;
            }
            if (options.year) {
                date.setFullYear(options.year);
            }
            if (options.month || options.month === 0) {
                date.setMonth(options.month);
            }
            if (options.day) {
                date.setDate(options.day);
            }
            return date;
        };
        return DateUtil;
    }());
    ElementCellTypes.DateUtil = DateUtil;
})(ElementCellTypes || (ElementCellTypes = {}));
var ElementUtils;
(function (ElementUtils) {
    var dayjs = window.ElementPlus.dayjs;
    var Dayjs = /** @class */ (function () {
        function Dayjs() {
        }
        Dayjs._createLocale = function (options) {
            var _a;
            var localeName = (++Dayjs._localeIndex).toString();
            var locale = __assign(__assign({ name: (_a = options.name) !== null && _a !== void 0 ? _a : localeName }, dayjs[Dayjs._defaultLocaleName]), options);
            dayjs.locale(locale, null, true);
            Dayjs._localeCache.set(JSON.stringify(options), localeName);
            return localeName;
        };
        Dayjs._delayResetLocale = function () {
            setTimeout(function () { return dayjs.locale(Dayjs._defaultLocaleName); });
        };
        Dayjs.toggleLocale = function (options) {
            var _a;
            var localeName = (_a = Dayjs._localeCache.get(JSON.stringify(options))) !== null && _a !== void 0 ? _a : Dayjs._createLocale(options);
            dayjs.locale(localeName);
            Dayjs._delayResetLocale();
        };
        Dayjs._localeIndex = 0;
        Dayjs._localeCache = new Map();
        Dayjs._defaultLocaleName = dayjs.locale();
        return Dayjs;
    }());
    ElementUtils.Dayjs = Dayjs;
})(ElementUtils || (ElementUtils = {}));
var ElementCellTypes;
(function (ElementCellTypes) {
    ElementCellTypes.ElementIconMap = new Map();
    ElementCellTypes.ElementIconMap.set("plus", "<svg class=\"icon\" width=\"200\" height=\"200\" viewBox=\"0 0 1024 1024\" xmlns=\"http://www.w3.org/2000/svg\" data-v-042ca774=\"\"><path fill=\"currentColor\" d=\"M480 480V128a32 32 0 0164 0v352h352a32 32 0 110 64H544v352a32 32 0 11-64 0V544H128a32 32 0 010-64h352z\"></path></svg>");
})(ElementCellTypes || (ElementCellTypes = {}));
//# sourceMappingURL=dist.js.map